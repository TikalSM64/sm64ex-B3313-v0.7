smlua_text_utils_course_acts_replace(COURSE_BOB, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_WF, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_JRB, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_CCM, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_BBH, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_HMC, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_LLL, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_SSL, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_DDD, ("The Internal Plexus"),	("^"),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_SL, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_WDW, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_TTM, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_THI, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_TTC, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_course_acts_replace(COURSE_RR, ("The Internal Plexus"),	(""),	(""),	(""),	(""),	(""),	(""))

smlua_text_utils_secret_star_replace(15 + 1, (""))
smlua_text_utils_secret_star_replace(16 + 1, (""))
smlua_text_utils_secret_star_replace(17 + 1, (""))
smlua_text_utils_secret_star_replace(18 + 1, (""))
smlua_text_utils_secret_star_replace(19 + 1, (""))
smlua_text_utils_secret_star_replace(20 + 1, (""))
smlua_text_utils_secret_star_replace(21 + 1, (""))
smlua_text_utils_secret_star_replace(22 + 1, (""))
smlua_text_utils_secret_star_replace(23 + 1, (""))
smlua_text_utils_secret_star_replace(24 + 1, (""))
smlua_text_utils_castle_secret_stars_replace(("   PLEXUS SECRET STARS"))
smlua_text_utils_extra_text_replace(0,("ONE OF THE PLEXUS'S SECRET STARS!"))
smlua_text_utils_extra_text_replace(1,(""))
smlua_text_utils_extra_text_replace(2,(""))
smlua_text_utils_extra_text_replace(3,(""))
smlua_text_utils_extra_text_replace(4,(""))
smlua_text_utils_extra_text_replace(5,(""))
smlua_text_utils_extra_text_replace(6,(""))
