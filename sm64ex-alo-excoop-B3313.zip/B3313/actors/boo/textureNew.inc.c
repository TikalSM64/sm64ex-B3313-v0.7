ALIGNED8 u8 boo_geo__texture_0500AB40[] = {
#include "actors/boo/boo_geo_0x500ab40_custom.rgba16.inc.c"
};
ALIGNED8 u8 boo_geo__texture_05009B40[] = {
#include "actors/boo/boo_geo_0x5009b40_custom.rgba16.inc.c"
};
