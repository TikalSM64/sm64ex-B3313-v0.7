ALIGNED8 u8 white_particle_dl__texture_0302C6A0[] = {
#include "actors/white_particle/white_particle_dl_0x302c6a0_custom.rgba16.inc.c"
};
