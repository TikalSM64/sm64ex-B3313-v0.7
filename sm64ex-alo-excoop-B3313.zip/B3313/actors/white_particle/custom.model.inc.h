#ifndef white_particle_white_particle_model_HEADER_H
#define white_particle_white_particle_model_HEADER_H
#include "types.h"
extern Vtx VB_white_particle_geo_0x302c660[];
extern u8 white_particle_dl__texture_0302C6A0[];
extern Gfx DL_white_particle_dl_0x302c8a0[];
#endif