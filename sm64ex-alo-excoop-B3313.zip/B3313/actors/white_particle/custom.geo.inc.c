#include "custom.model.inc.h"
const GeoLayout white_particle_geo[]= {
GEO_SHADOW(1,180,50),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_white_particle_geo_0x302c8a0),
GEO_CLOSE_NODE(),
GEO_END(),
};
