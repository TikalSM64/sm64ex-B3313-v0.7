#ifndef number_number_model_HEADER_H
#define number_number_model_HEADER_H
#include "types.h"
#endif