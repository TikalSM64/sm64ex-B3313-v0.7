ALIGNED8 u8 cannon_base_geo__texture_080049B8[] = {
#include "actors/cannon_base/cannon_base_geo_0x80049b8_custom.rgba16.inc.c"
};
