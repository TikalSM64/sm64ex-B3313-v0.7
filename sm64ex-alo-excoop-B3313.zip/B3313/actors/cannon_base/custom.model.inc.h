#ifndef cannon_base_cannon_base_model_HEADER_H
#define cannon_base_cannon_base_model_HEADER_H
#include "types.h"
extern Vtx VB_cannon_base_geo_0x80051b8[];
extern Vtx VB_cannon_base_geo_0x8005278[];
extern Vtx VB_cannon_base_geo_0x8005378[];
extern Vtx VB_cannon_base_geo_0x8005468[];
extern Vtx VB_cannon_base_geo_0x8005558[];
extern u8 cannon_base_geo__texture_080049B8[];
extern Light_t Light_cannon_base_geo_0x8004990;
extern Light_t Light_cannon_base_geo_0x80049a8;
extern Ambient_t Light_cannon_base_geo_0x8004988;
extern Ambient_t Light_cannon_base_geo_0x80049a0;
extern Gfx DL_cannon_base_geo_0x80057f8[];
extern Gfx DL_cannon_base_geo_0x8005658[];
extern Gfx DL_cannon_base_geo_0x80056d0[];
#endif