ALIGNED8 u8 fish_geo__texture_0301B5E0[] = {
#include "actors/blue_fish/fish_geo_0x301b5e0_custom.rgba16.inc.c"
};
