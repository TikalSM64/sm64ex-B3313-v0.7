#include "custom.model.inc.h"
const GeoLayout castle_geo_001530[]= {
GEO_CULLING_RADIUS(300),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_castle_geo_001530_0x7058950),
GEO_CLOSE_NODE(),
GEO_END(),
};
