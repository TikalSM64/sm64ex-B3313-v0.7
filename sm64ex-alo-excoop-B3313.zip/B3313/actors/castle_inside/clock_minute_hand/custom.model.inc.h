#ifndef castle_inside_clock_minute_hand_model_HEADER_H
#define castle_inside_clock_minute_hand_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_geo_001530_0x7058008[];
extern Vtx VB_castle_geo_001530_0x7058108[];
extern Vtx VB_castle_geo_001530_0x70581f8[];
extern Vtx VB_castle_geo_001530_0x70582f8[];
extern Vtx VB_castle_geo_001530_0x70583e8[];
extern Vtx VB_castle_geo_001530_0x70584e8[];
extern Vtx VB_castle_geo_001530_0x70585a8[];
extern Vtx VB_castle_geo_001530_0x7058698[];
extern u8 castle_geo_001530__texture_09004800[];
extern Light_t Light_castle_geo_001530_0x7057fe0;
extern Light_t Light_castle_geo_001530_0x7057ff8;
extern Ambient_t Light_castle_geo_001530_0x7057fd8;
extern Ambient_t Light_castle_geo_001530_0x7057ff0;
extern Gfx DL_castle_geo_001530_0x7058950[];
extern Gfx DL_castle_geo_001530_0x7058718[];
#endif