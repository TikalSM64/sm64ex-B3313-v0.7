ALIGNED8 u8 castle_geo_001518__texture_09007000[] = {
#include "actors/castle_inside/areas/2/pendulum/castle_geo_001518_0x9007000_custom.rgba16.inc.c"
};
