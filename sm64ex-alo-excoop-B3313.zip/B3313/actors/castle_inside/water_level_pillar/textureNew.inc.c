ALIGNED8 u8 castle_geo_001940__texture_0900B000[] = {
#include "actors/castle_inside/water_level_pillar/castle_geo_001940_0x900b000_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_geo_001940__texture_09003000[] = {
#include "actors/castle_inside/water_level_pillar/castle_geo_001940_0x9003000_custom.rgba16.inc.c"
};
