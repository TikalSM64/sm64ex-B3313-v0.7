#ifndef castle_inside_star_door_model_HEADER_H
#define castle_inside_star_door_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_geo_000F00_0x703bd40[];
extern Vtx VB_castle_geo_000F00_0x703be40[];
extern Vtx VB_castle_geo_000F00_0x703be80[];
extern u8 castle_geo_000F00__texture_07005800[];
extern u8 castle_geo_000F00__texture_07003800[];
extern u8 castle_geo_000F00__texture_07004800[];
extern Light_t Light_castle_geo_000F00_0x703bd30;
extern Ambient_t Light_castle_geo_000F00_0x703bd28;
extern Gfx DL_castle_geo_000F00_0x703bfa8[];
extern Gfx DL_castle_geo_000F00_0x703bec0[];
extern Gfx DL_castle_geo_000F00_0x703bf38[];
extern Gfx DL_castle_geo_000F00_0x703bf70[];
#endif