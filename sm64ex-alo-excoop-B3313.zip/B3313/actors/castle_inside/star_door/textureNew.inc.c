ALIGNED8 u8 castle_geo_000F00__texture_07005800[] = {
#include "actors/castle_inside/star_door/castle_geo_000F00_0x7005800_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_geo_000F00__texture_07003800[] = {
#include "actors/castle_inside/star_door/castle_geo_000F00_0x7003800_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_geo_000F00__texture_07004800[] = {
#include "actors/castle_inside/star_door/castle_geo_000F00_0x7004800_custom.rgba16.inc.c"
};
