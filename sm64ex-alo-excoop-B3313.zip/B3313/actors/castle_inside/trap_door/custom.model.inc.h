#ifndef castle_inside_trap_door_model_HEADER_H
#define castle_inside_trap_door_model_HEADER_H
#include "types.h"
extern Vtx VB_castle_geo_000F18_0x703bac8[];
extern Vtx VB_castle_geo_000F18_0x703bbb8[];
extern u8 castle_geo_000F18__texture_09005000[];
extern Light_t Light_castle_geo_000F18_0x703bab8;
extern Ambient_t Light_castle_geo_000F18_0x703bab0;
extern Gfx DL_castle_geo_000F18_0x703bcb8[];
extern Gfx DL_castle_geo_000F18_0x703bc28[];
#endif