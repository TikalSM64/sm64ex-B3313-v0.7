ALIGNED8 u8 castle_geo_001548__texture_09004800[] = {
#include "actors/castle_inside/clock_hour_hand/castle_geo_001548_0x9004800_custom.rgba16.inc.c"
};
