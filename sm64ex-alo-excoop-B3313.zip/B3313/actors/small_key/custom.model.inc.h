#ifndef small_key_small_key_model_HEADER_H
#define small_key_small_key_model_HEADER_H
#include "types.h"
extern Vtx VB_small_key_geo_0x5005800[];
extern Vtx VB_small_key_geo_0x50058f0[];
extern Vtx VB_small_key_geo_0x50059e0[];
extern Vtx VB_small_key_geo_0x5005ad0[];
extern Vtx VB_small_key_geo_0x5005bc0[];
extern Vtx VB_small_key_geo_0x5005cb0[];
extern Vtx VB_small_key_geo_0x5005da0[];
extern Vtx VB_small_key_geo_0x5005e90[];
extern Vtx VB_small_key_geo_0x5005f80[];
extern Vtx VB_small_key_geo_0x5006070[];
extern Vtx VB_small_key_geo_0x5006160[];
extern Vtx VB_small_key_geo_0x5006250[];
extern Vtx VB_small_key_geo_0x5006340[];
extern Vtx VB_small_key_geo_0x5006430[];
extern Vtx VB_small_key_geo_0x5006520[];
extern Vtx VB_small_key_geo_0x5006610[];
extern Light_t Light_small_key_geo_0x50057e8;
extern Ambient_t Light_small_key_geo_0x50057e0;
extern Gfx DL_small_key_geo_0x5006a68[];
extern Gfx DL_small_key_geo_0x5006700[];
#endif