#include "custom.model.inc.h"
Vtx VB_haunted_chair_geo_0x5004c78[] = {
	{{{ 334, -20, 1 }, 0, { 474, -182 }, { 119, 0, 214, 255}}},
	{{{ 287, -20, -132 }, 0, { 1212, 58 }, { 119, 0, 214, 255}}},
	{{{ 334, 25, 1 }, 0, { 474, -182 }, { 119, 0, 214, 255}}},
	{{{ 334, 25, 1 }, 0, { 474, -182 }, { 119, 0, 42, 255}}},
	{{{ 287, 25, 134 }, 0, { -262, 58 }, { 119, 0, 42, 255}}},
	{{{ 334, -20, 1 }, 0, { 474, -182 }, { 119, 0, 42, 255}}},
	{{{ 287, -20, 134 }, 0, { -262, 58 }, { 119, 0, 42, 255}}},
	{{{ 287, -20, -132 }, 0, { 1212, 58 }, { 0, 129, 0, 255}}},
	{{{ 334, -20, 1 }, 0, { 474, -182 }, { 0, 129, 0, 255}}},
	{{{ 287, -20, 134 }, 0, { -262, 58 }, { 0, 129, 0, 255}}},
	{{{ -7, -20, -91 }, 0, { 986, 1536 }, { 239, 0, 131, 255}}},
	{{{ -7, 25, -91 }, 0, { 986, 1536 }, { 239, 0, 131, 255}}},
	{{{ 287, -20, -132 }, 0, { 1212, 58 }, { 239, 0, 131, 255}}},
	{{{ 287, 25, -132 }, 0, { 1212, 58 }, { 239, 0, 131, 255}}},
	{{{ 287, 25, -132 }, 0, { 1212, 58 }, { 119, 0, 214, 255}}},
	{{{ -7, -20, -91 }, 0, { 986, 1536 }, { 0, 129, 0, 255}}},
};

Vtx VB_haunted_chair_geo_0x5004d78[] = {
	{{{ 287, 25, 134 }, 0, { -262, 58 }, { 0, 127, 0, 255}}},
	{{{ 334, 25, 1 }, 0, { 474, -182 }, { 0, 127, 0, 255}}},
	{{{ 287, 25, -132 }, 0, { 1212, 58 }, { 0, 127, 0, 255}}},
	{{{ -7, 25, -91 }, 0, { 986, 1536 }, { 0, 127, 0, 255}}},
	{{{ -7, 25, 93 }, 0, { -34, 1536 }, { 0, 127, 0, 255}}},
	{{{ -7, -20, 93 }, 0, { -34, 1536 }, { 239, 0, 125, 255}}},
	{{{ 287, -20, 134 }, 0, { -262, 58 }, { 239, 0, 125, 255}}},
	{{{ 287, 25, 134 }, 0, { -262, 58 }, { 239, 0, 125, 255}}},
	{{{ -7, 25, 93 }, 0, { -34, 1536 }, { 239, 0, 125, 255}}},
	{{{ -7, -20, 93 }, 0, { -34, 1536 }, { 0, 129, 0, 255}}},
	{{{ -7, -20, -91 }, 0, { 986, 1536 }, { 0, 129, 0, 255}}},
	{{{ 287, -20, 134 }, 0, { -262, 58 }, { 0, 129, 0, 255}}},
};

Vtx VB_haunted_chair_geo_0x5004f70[] = {
	{{{ 208, -20, -125 }, 0, { 1934, 0 }, { 0, 0, 129, 255}}},
	{{{ -38, 24, -125 }, 0, { 1935, 990 }, { 0, 0, 129, 255}}},
	{{{ 208, 24, -125 }, 0, { 1934, 0 }, { 0, 0, 129, 255}}},
	{{{ 208, 24, -125 }, 0, { 1934, 0 }, { 0, 127, 0, 255}}},
	{{{ -38, 24, 127 }, 0, { -20, 990 }, { 0, 127, 0, 255}}},
	{{{ 208, 24, 127 }, 0, { -21, 0 }, { 0, 127, 0, 255}}},
	{{{ -38, 24, -125 }, 0, { 1935, 990 }, { 0, 127, 0, 255}}},
	{{{ 208, -20, 127 }, 0, { -21, 0 }, { 127, 0, 0, 255}}},
	{{{ 208, 24, -125 }, 0, { 1934, 0 }, { 127, 0, 0, 255}}},
	{{{ 208, 24, 127 }, 0, { -21, 0 }, { 127, 0, 0, 255}}},
	{{{ 208, -20, -125 }, 0, { 1934, 0 }, { 127, 0, 0, 255}}},
	{{{ -38, -20, -125 }, 0, { 1935, 990 }, { 129, 0, 0, 255}}},
	{{{ -38, 24, 127 }, 0, { -20, 990 }, { 129, 0, 0, 255}}},
	{{{ -38, 24, -125 }, 0, { 1935, 990 }, { 129, 0, 0, 255}}},
	{{{ -38, -20, 127 }, 0, { -20, 990 }, { 129, 0, 0, 255}}},
	{{{ -38, -20, -125 }, 0, { 1935, 990 }, { 0, 0, 129, 255}}},
};

Vtx VB_haunted_chair_geo_0x5005070[] = {
	{{{ 208, -20, 127 }, 0, { -21, 0 }, { 0, 129, 0, 255}}},
	{{{ -38, -20, -125 }, 0, { 1935, 990 }, { 0, 129, 0, 255}}},
	{{{ 208, -20, -125 }, 0, { 1934, 0 }, { 0, 129, 0, 255}}},
	{{{ -38, -20, 127 }, 0, { -20, 990 }, { 0, 129, 0, 255}}},
	{{{ -38, -20, 127 }, 0, { 577, 990 }, { 0, 0, 127, 255}}},
	{{{ 208, -20, 127 }, 0, { 511, 0 }, { 0, 0, 127, 255}}},
	{{{ 208, 24, 127 }, 0, { 511, 0 }, { 0, 0, 127, 255}}},
	{{{ -38, 24, 127 }, 0, { 577, 990 }, { 0, 0, 127, 255}}},
};

Vtx VB_haunted_chair_geo_0x5005218[] = {
	{{{ 146, -22, 104 }, 0, { 998, 990 }, { 239, 0, 125, 255}}},
	{{{ 146, 26, 104 }, 0, { 998, 990 }, { 239, 0, 125, 255}}},
	{{{ -8, 26, 82 }, 0, { 886, -24 }, { 239, 0, 125, 255}}},
	{{{ 146, 26, 104 }, 0, { 998, 990 }, { 127, 0, 0, 255}}},
	{{{ 146, -22, -102 }, 0, { 0, 990 }, { 127, 0, 0, 255}}},
	{{{ 146, 26, -102 }, 0, { 0, 990 }, { 127, 0, 0, 255}}},
	{{{ 146, -22, 104 }, 0, { 998, 990 }, { 127, 0, 0, 255}}},
	{{{ 146, 26, 104 }, 0, { 998, 990 }, { 0, 127, 0, 255}}},
	{{{ -8, 26, -79 }, 0, { 78, -24 }, { 0, 127, 0, 255}}},
	{{{ -8, 26, 82 }, 0, { 886, -24 }, { 0, 127, 0, 255}}},
	{{{ 146, 26, -102 }, 0, { 0, 990 }, { 0, 127, 0, 255}}},
	{{{ 146, -22, -102 }, 0, { 0, 990 }, { 0, 129, 0, 255}}},
	{{{ -8, -22, 82 }, 0, { 886, -24 }, { 0, 129, 0, 255}}},
	{{{ -8, -22, -79 }, 0, { 78, -24 }, { 0, 129, 0, 255}}},
	{{{ 146, -22, 104 }, 0, { 998, 990 }, { 0, 129, 0, 255}}},
};

Vtx VB_haunted_chair_geo_0x5005308[] = {
	{{{ 146, 26, -102 }, 0, { 0, 990 }, { 238, 0, 131, 255}}},
	{{{ 146, -22, -102 }, 0, { 0, 990 }, { 238, 0, 131, 255}}},
	{{{ -8, -22, -79 }, 0, { 78, -24 }, { 238, 0, 131, 255}}},
	{{{ -8, 26, -79 }, 0, { 78, -24 }, { 238, 0, 131, 255}}},
	{{{ 146, -22, 104 }, 0, { 998, 990 }, { 239, 0, 125, 255}}},
	{{{ -8, 26, 82 }, 0, { 886, -24 }, { 239, 0, 125, 255}}},
	{{{ -8, -22, 82 }, 0, { 886, -24 }, { 239, 0, 125, 255}}},
};

Vtx VB_haunted_chair_geo_0x5005490[] = {
	{{{ 146, -19, 104 }, 0, { 998, 990 }, { 239, 0, 125, 255}}},
	{{{ 146, 29, 104 }, 0, { 998, 990 }, { 239, 0, 125, 255}}},
	{{{ -8, 29, 82 }, 0, { 886, -40 }, { 239, 0, 125, 255}}},
	{{{ 146, 29, 104 }, 0, { 998, 990 }, { 127, 0, 0, 255}}},
	{{{ 146, -19, -102 }, 0, { 0, 990 }, { 127, 0, 0, 255}}},
	{{{ 146, 29, -102 }, 0, { 0, 990 }, { 127, 0, 0, 255}}},
	{{{ 146, -19, 104 }, 0, { 998, 990 }, { 127, 0, 0, 255}}},
	{{{ 146, 29, 104 }, 0, { 998, 990 }, { 0, 127, 0, 255}}},
	{{{ -8, 29, -79 }, 0, { 78, -40 }, { 0, 127, 0, 255}}},
	{{{ -8, 29, 82 }, 0, { 886, -40 }, { 0, 127, 0, 255}}},
	{{{ 146, 29, -102 }, 0, { 0, 990 }, { 0, 127, 0, 255}}},
	{{{ 146, -19, -102 }, 0, { 0, 990 }, { 0, 129, 0, 255}}},
	{{{ -8, -19, 82 }, 0, { 886, -40 }, { 0, 129, 0, 255}}},
	{{{ -8, -19, -79 }, 0, { 78, -40 }, { 0, 129, 0, 255}}},
	{{{ 146, -19, 104 }, 0, { 998, 990 }, { 0, 129, 0, 255}}},
};

Vtx VB_haunted_chair_geo_0x5005580[] = {
	{{{ 146, 29, -102 }, 0, { 0, 990 }, { 238, 0, 131, 255}}},
	{{{ 146, -19, -102 }, 0, { 0, 990 }, { 238, 0, 131, 255}}},
	{{{ -8, -19, -79 }, 0, { 78, -40 }, { 238, 0, 131, 255}}},
	{{{ -8, 29, -79 }, 0, { 78, -40 }, { 238, 0, 131, 255}}},
	{{{ 146, -19, 104 }, 0, { 998, 990 }, { 239, 0, 125, 255}}},
	{{{ -8, 29, 82 }, 0, { 886, -40 }, { 239, 0, 125, 255}}},
	{{{ -8, -19, 82 }, 0, { 886, -40 }, { 239, 0, 125, 255}}},
};

Light_t Light_haunted_chair_geo_0x5004f60 = {
	{ 178, 178, 178}, 0, { 178, 178, 178}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_haunted_chair_geo_0x5004f58 = {
	{71, 71, 71}, 0, {71, 71, 71}, 0
};

Gfx DL_haunted_chair_geo_0x5005190[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsSPGeometryMode(G_SHADING_SMOOTH, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 4, 0, 0, 0, 0, 5, 0, 0, 4, 0),
	gsDPSetTileSize(0, 0, 0, 60, 124),
	gsSPDisplayList(DL_haunted_chair_geo_0x50050f0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_SHADING_SMOOTH),
	gsSPEndDisplayList(),
};

Gfx DL_haunted_chair_geo_0x50050f0[] = {
	gsDPSetTextureImage(0, 2, 1, haunted_chair_geo__texture_05004060),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsSPLight(&Light_haunted_chair_geo_0x5004f60.col, 1),
	gsSPLight(&Light_haunted_chair_geo_0x5004f58.col, 2),
	gsSPVertex(VB_haunted_chair_geo_0x5004f70, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 6, 4, 0, 7, 8, 9, 0),
	gsSP2Triangles(7, 10, 8, 0, 11, 12, 13, 0),
	gsSP2Triangles(11, 14, 12, 0, 0, 15, 1, 0),
	gsSPVertex(VB_haunted_chair_geo_0x5005070, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Light_t Light_haunted_chair_geo_0x5005480 = {
	{ 178, 178, 178}, 0, { 178, 178, 178}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_haunted_chair_geo_0x5005478 = {
	{71, 71, 71}, 0, {71, 71, 71}, 0
};

Gfx DL_haunted_chair_geo_0x5005680[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsSPGeometryMode(G_SHADING_SMOOTH, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_haunted_chair_geo_0x50055f0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_SHADING_SMOOTH),
	gsSPEndDisplayList(),
};

Gfx DL_haunted_chair_geo_0x50055f0[] = {
	gsDPSetTextureImage(0, 2, 1, haunted_chair_geo__texture_05003860),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_haunted_chair_geo_0x5005480.col, 1),
	gsSPLight(&Light_haunted_chair_geo_0x5005478.col, 2),
	gsSPVertex(VB_haunted_chair_geo_0x5005490, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 6, 4, 0, 7, 8, 9, 0),
	gsSP2Triangles(7, 10, 8, 0, 11, 12, 13, 0),
	gsSP1Triangle(11, 14, 12, 0),
	gsSPVertex(VB_haunted_chair_geo_0x5005580, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSPEndDisplayList(),
};

Light_t Light_haunted_chair_geo_0x5005208 = {
	{ 178, 178, 178}, 0, { 178, 178, 178}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_haunted_chair_geo_0x5005200 = {
	{71, 71, 71}, 0, {71, 71, 71}, 0
};

Gfx DL_haunted_chair_geo_0x5005408[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsSPGeometryMode(G_SHADING_SMOOTH, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_haunted_chair_geo_0x5005378),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_SHADING_SMOOTH),
	gsSPEndDisplayList(),
};

Gfx DL_haunted_chair_geo_0x5005378[] = {
	gsDPSetTextureImage(0, 2, 1, haunted_chair_geo__texture_05003860),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_haunted_chair_geo_0x5005208.col, 1),
	gsSPLight(&Light_haunted_chair_geo_0x5005200.col, 2),
	gsSPVertex(VB_haunted_chair_geo_0x5005218, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 6, 4, 0, 7, 8, 9, 0),
	gsSP2Triangles(7, 10, 8, 0, 11, 12, 13, 0),
	gsSP1Triangle(11, 14, 12, 0),
	gsSPVertex(VB_haunted_chair_geo_0x5005308, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP1Triangle(4, 5, 6, 0),
	gsSPEndDisplayList(),
};

Light_t Light_haunted_chair_geo_0x5004c68 = {
	{ 178, 178, 178}, 0, { 178, 178, 178}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_haunted_chair_geo_0x5004c60 = {
	{71, 71, 71}, 0, {71, 71, 71}, 0
};

Gfx DL_haunted_chair_geo_0x5004ee8[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsSPGeometryMode(G_SHADING_SMOOTH, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_haunted_chair_geo_0x5004e38),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_SHADING_SMOOTH),
	gsSPEndDisplayList(),
};

Gfx DL_haunted_chair_geo_0x5004e38[] = {
	gsDPSetTextureImage(0, 2, 1, haunted_chair_geo__texture_05003060),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_haunted_chair_geo_0x5004c68.col, 1),
	gsSPLight(&Light_haunted_chair_geo_0x5004c60.col, 2),
	gsSPVertex(VB_haunted_chair_geo_0x5004c78, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(4, 6, 5, 0, 7, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 11, 13, 12, 0),
	gsSP2Triangles(1, 14, 2, 0, 15, 7, 9, 0),
	gsSPVertex(VB_haunted_chair_geo_0x5004d78, 12, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 2, 0),
	gsSP2Triangles(4, 0, 2, 0, 5, 6, 7, 0),
	gsSP2Triangles(8, 5, 7, 0, 9, 10, 11, 0),
	gsSPEndDisplayList(),
};

