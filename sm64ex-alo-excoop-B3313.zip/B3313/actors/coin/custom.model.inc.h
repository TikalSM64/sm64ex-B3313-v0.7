#ifndef coin_coin_model_HEADER_H
#define coin_coin_model_HEADER_H
#include "types.h"
extern Vtx VB_red_coin_no_shadow_geo_0x30056c0[];
extern Vtx VB_red_coin_no_shadow_geo_0x3005700[];
extern Vtx VB_red_coin_no_shadow_geo_0x3005740[];
extern u8 yellow_coin_geo__texture_03005780[];
extern Gfx DL_yellow_coin_geo_0x3007800[];
extern Gfx DL_yellow_coin_geo_0x3007780[];
extern Gfx DL_yellow_coin_geo_0x30077d0[];
extern u8 yellow_coin_geo__texture_03005F80[];
extern Gfx DL_yellow_coin_geo_0x3007828[];
extern u8 yellow_coin_geo__texture_03006780[];
extern Gfx DL_yellow_coin_geo_0x3007850[];
extern u8 yellow_coin_geo__texture_03006F80[];
extern Gfx DL_yellow_coin_geo_0x3007878[];
extern Gfx DL_blue_coin_geo_0x30078a0[];
extern Gfx DL_blue_coin_geo_0x30078c8[];
extern Gfx DL_blue_coin_geo_0x30078f0[];
extern Gfx DL_blue_coin_geo_0x3007918[];
extern Gfx DL_red_coin_geo_0x3007940[];
extern Gfx DL_red_coin_geo_0x3007968[];
extern Gfx DL_red_coin_geo_0x3007990[];
extern Gfx DL_red_coin_geo_0x30079b8[];
#endif