ALIGNED8 u8 cannon_lid_seg8_dl_080048E0__texture_08004058[] = {
#include "actors/cannon_lid/cannon_lid_seg8_dl_080048E0_0x8004058_custom.rgba16.inc.c"
};
