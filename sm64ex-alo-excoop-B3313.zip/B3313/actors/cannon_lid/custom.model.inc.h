#ifndef cannon_lid_cannon_lid_model_HEADER_H
#define cannon_lid_cannon_lid_model_HEADER_H
#include "types.h"
extern Vtx VB_cannon_lid_seg8_dl_080048E0_0x8004858[];
extern u8 cannon_lid_seg8_dl_080048E0__texture_08004058[];
extern Light_t Light_cannon_lid_seg8_dl_080048E0_0x8004048;
extern Ambient_t Light_cannon_lid_seg8_dl_080048E0_0x8004040;
extern Gfx DL_cannon_lid_seg8_dl_080048E0_0x80048e0[];
extern Gfx DL_cannon_lid_seg8_dl_080048E0_0x8004898[];
#endif