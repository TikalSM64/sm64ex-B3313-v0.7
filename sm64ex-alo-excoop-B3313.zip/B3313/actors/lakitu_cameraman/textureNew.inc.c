ALIGNED8 u8 lakitu_geo__texture_06002800[] = {
#include "actors/lakitu_cameraman/lakitu_geo_0x6002800_custom.rgba16.inc.c"
};
ALIGNED8 u8 lakitu_geo__texture_06003000[] = {
#include "actors/lakitu_cameraman/lakitu_geo_0x6003000_custom.rgba16.inc.c"
};
ALIGNED8 u8 lakitu_geo__texture_06000800[] = {
#include "actors/lakitu_cameraman/lakitu_geo_0x6000800_custom.rgba16.inc.c"
};
ALIGNED8 u8 lakitu_geo__texture_06001800[] = {
#include "actors/lakitu_cameraman/lakitu_geo_0x6001800_custom.rgba16.inc.c"
};
ALIGNED8 u8 lakitu_geo__texture_06003800[] = {
#include "actors/lakitu_cameraman/lakitu_geo_0x6003800_custom.rgba16.inc.c"
};
