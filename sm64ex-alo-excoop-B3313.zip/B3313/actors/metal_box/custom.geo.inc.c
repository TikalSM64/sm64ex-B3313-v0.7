#include "custom.model.inc.h"
const GeoLayout metal_box_geo[]= {
GEO_CULLING_RADIUS(500),
GEO_OPEN_NODE(),
GEO_SHADOW(10,180,70),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_metal_box_geo_0x8024bb8),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
