#ifndef metal_box_metal_box_model_HEADER_H
#define metal_box_metal_box_model_HEADER_H
#include "types.h"
extern Vtx VB_metal_box_dl_0x8024998[];
extern Vtx VB_metal_box_dl_0x8024a98[];
extern u8 metal_box_geo__texture_08023998[];
extern Light_t Light_metal_box_geo_0x8023988;
extern Ambient_t Light_metal_box_geo_0x8023980;
extern Gfx DL_metal_box_geo_0x8024bb8[];
extern Gfx DL_metal_box_geo_0x8024b18[];
#endif