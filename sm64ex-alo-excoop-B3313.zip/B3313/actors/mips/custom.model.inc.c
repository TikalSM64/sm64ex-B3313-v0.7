#include "custom.model.inc.h"
Vtx VB_mips_geo_0x60104a0[] = {
	{{{ 60, 25, -62 }, 0, { -146, -1034 }, { 29, 33, 138, 255}}},
	{{{ 102, 15, -32 }, 0, { 144, -1598 }, { 101, 13, 181, 255}}},
	{{{ 46, -61, -46 }, 0, { 8, -848 }, { 35, 154, 191, 255}}},
	{{{ 4, -54, -41 }, 0, { 56, -296 }, { 178, 191, 181, 255}}},
	{{{ 100, -30, 0 }, 0, { 458, -1572 }, { 107, 189, 0, 255}}},
	{{{ 4, -54, 42 }, 0, { 858, -296 }, { 185, 172, 62, 255}}},
	{{{ 46, -61, 48 }, 0, { 906, -848 }, { 47, 168, 77, 255}}},
	{{{ 60, 25, 64 }, 0, { 1062, -1034 }, { 28, 33, 119, 255}}},
	{{{ -7, 16, 0 }, 0, { 458, -128 }, { 132, 23, 0, 255}}},
	{{{ 2, 8, 67 }, 0, { 1094, -262 }, { 174, 22, 93, 255}}},
	{{{ 2, 8, -66 }, 0, { -178, -262 }, { 175, 24, 163, 255}}},
	{{{ 102, 15, 33 }, 0, { 770, -1598 }, { 102, 13, 74, 255}}},
	{{{ 115, 13, 0 }, 0, { 458, -1770 }, { 116, 49, 0, 255}}},
	{{{ 16, 44, 47 }, 0, { 902, -454 }, { 208, 93, 71, 255}}},
	{{{ 16, 44, -45 }, 0, { 14, -454 }, { 209, 92, 184, 255}}},
	{{{ 9, 60, 0 }, 0, { 458, -352 }, { 162, 84, 0, 255}}},
};

Vtx VB_mips_geo_0x60105a0[] = {
	{{{ 115, 13, 0 }, 0, { 468, 0 }, { 116, 49, 0, 255}}},
	{{{ 64, 56, -13 }, 0, { 308, 632 }, { 69, 89, 198, 255}}},
	{{{ 64, 56, 15 }, 0, { 632, 632 }, { 68, 90, 56, 255}}},
	{{{ 102, 15, -32 }, 0, { 104, 80 }, { 101, 13, 181, 255}}},
	{{{ 102, 15, 33 }, 0, { 834, 80 }, { 102, 13, 74, 255}}},
	{{{ 16, 44, -45 }, 0, { -46, 922 }, { 209, 92, 184, 255}}},
	{{{ 45, 77, 0 }, 0, { 468, 910 }, { 251, 126, 254, 255}}},
	{{{ 60, 25, -62 }, 0, { -236, 468 }, { 29, 33, 138, 255}}},
	{{{ 9, 60, 0 }, 0, { 468, 1082 }, { 162, 84, 0, 255}}},
	{{{ 16, 44, 47 }, 0, { 988, 922 }, { 208, 93, 71, 255}}},
	{{{ 60, 25, 64 }, 0, { 1176, 468 }, { 28, 33, 119, 255}}},
	{{{ 2, 8, -66 }, 0, { -272, 800 }, { 175, 24, 163, 255}}},
	{{{ 2, 8, 67 }, 0, { 1212, 800 }, { 174, 22, 93, 255}}},
};

Vtx VB_mips_geo_0x6010670[] = {
	{{{ 45, 77, 0 }, 0, { 0, 0 }, { 251, 126, 254, 255}}},
	{{{ 64, 56, 15 }, 0, { 0, 0 }, { 68, 90, 56, 255}}},
	{{{ 64, 76, 0 }, 0, { 0, 0 }, { 86, 93, 253, 255}}},
	{{{ 64, 56, -13 }, 0, { 0, 0 }, { 69, 89, 198, 255}}},
};

Vtx VB_mips_geo_0x60106b0[] = {
	{{{ -9, 52, -5 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ 11, 50, -12 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ 11, 50, 13 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ -9, 52, 6 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_mips_geo_0x6010928[] = {
	{{{ -23, -21, -59 }, 0, { -1764, 666 }, { 222, 211, 143, 255}}},
	{{{ -48, -27, -16 }, 0, { -2202, 640 }, { 148, 10, 191, 255}}},
	{{{ -16, 41, -55 }, 0, { -1306, -124 }, { 229, 75, 158, 255}}},
	{{{ -47, 37, 22 }, 0, { -1840, -188 }, { 144, 50, 28, 255}}},
	{{{ -47, 37, -21 }, 0, { -1840, -188 }, { 152, 62, 220, 255}}},
	{{{ -34, -55, 0 }, 0, { -2112, 1046 }, { 34, 134, 0, 255}}},
	{{{ -48, -27, 18 }, 0, { -2202, 640 }, { 159, 38, 71, 255}}},
	{{{ -75, -36, -40 }, 0, { -2688, 648 }, { 222, 48, 144, 255}}},
	{{{ -16, 41, 56 }, 0, { -1306, -124 }, { 228, 74, 98, 255}}},
	{{{ -23, -21, 60 }, 0, { -1764, 666 }, { 222, 210, 112, 255}}},
	{{{ -75, -36, 42 }, 0, { -2688, 648 }, { 237, 251, 125, 255}}},
	{{{ -15, 60, 0 }, 0, { -1198, -360 }, { 251, 126, 0, 255}}},
	{{{ 12, -27, 49 }, 0, { -1206, 880 }, { 56, 182, 85, 255}}},
	{{{ 17, 16, 52 }, 0, { -886, 330 }, { 57, 30, 108, 255}}},
	{{{ 65, 12, 15 }, 0, { -142, 578 }, { 106, 28, 63, 255}}},
};

Vtx VB_mips_geo_0x6010a18[] = {
	{{{ 12, -27, 49 }, 0, { -1206, 880 }, { 56, 182, 85, 255}}},
	{{{ 33, -39, 0 }, 0, { -928, 1112 }, { 56, 143, 0, 255}}},
	{{{ 64, -13, 0 }, 0, { -292, 902 }, { 107, 189, 0, 255}}},
	{{{ -34, -55, 0 }, 0, { -2112, 1046 }, { 34, 134, 0, 255}}},
	{{{ 65, 12, 15 }, 0, { -142, 578 }, { 106, 28, 63, 255}}},
	{{{ 31, 35, 19 }, 0, { -564, 142 }, { 66, 103, 31, 255}}},
	{{{ 17, 16, 52 }, 0, { -886, 330 }, { 57, 30, 108, 255}}},
	{{{ -16, 41, 56 }, 0, { -1306, -124 }, { 228, 74, 98, 255}}},
	{{{ 18, 18, -49 }, 0, { -870, 316 }, { 58, 33, 149, 255}}},
	{{{ 31, 34, -18 }, 0, { -570, 156 }, { 64, 102, 218, 255}}},
	{{{ 65, 12, -14 }, 0, { -142, 578 }, { 104, 48, 203, 255}}},
	{{{ -23, -21, -59 }, 0, { -1764, 666 }, { 222, 211, 143, 255}}},
	{{{ -16, 41, -55 }, 0, { -1306, -124 }, { 229, 75, 158, 255}}},
	{{{ 12, -27, -48 }, 0, { -1206, 882 }, { 56, 184, 169, 255}}},
	{{{ -15, 60, 0 }, 0, { -1198, -360 }, { 251, 126, 0, 255}}},
};

Vtx VB_mips_geo_0x6010b08[] = {
	{{{ -34, -55, 0 }, 0, { -2112, 1046 }, { 34, 134, 0, 255}}},
	{{{ -53, -82, 0 }, 0, { -2566, 1322 }, { 31, 134, 255, 255}}},
	{{{ -75, -36, -40 }, 0, { -2688, 648 }, { 222, 48, 144, 255}}},
	{{{ -75, -36, 42 }, 0, { -2688, 648 }, { 237, 251, 125, 255}}},
	{{{ -15, 60, 0 }, 0, { -1198, -360 }, { 251, 126, 0, 255}}},
	{{{ 31, 35, 19 }, 0, { -564, 142 }, { 66, 103, 31, 255}}},
	{{{ 31, 34, -18 }, 0, { -570, 156 }, { 64, 102, 218, 255}}},
	{{{ -82, -71, 0 }, 0, { -2974, 1062 }, { 158, 177, 255, 255}}},
};

Vtx VB_mips_geo_0x6010dc0[] = {
	{{{ 0, 0, -26 }, 0, { -1052, 990 }, { 199, 93, 193, 255}}},
	{{{ 76, 0, 41 }, 0, { -290, 990 }, { 24, 66, 105, 255}}},
	{{{ 76, 0, -39 }, 0, { -290, 990 }, { 28, 18, 134, 255}}},
	{{{ 103, 1, 1 }, 0, { -24, 1000 }, { 126, 11, 0, 255}}},
	{{{ 0, 0, 28 }, 0, { -1052, 990 }, { 179, 60, 81, 255}}},
	{{{ -19, -8, 0 }, 0, { -1254, 902 }, { 132, 25, 255, 255}}},
};

Vtx VB_mips_geo_0x6010e20[] = {
	{{{ -11, -30, 0 }, 0, { -1168, 680 }, { 188, 150, 254, 255}}},
	{{{ 0, 0, -26 }, 0, { -1052, 990 }, { 199, 93, 193, 255}}},
	{{{ 76, 0, -39 }, 0, { -290, 990 }, { 28, 18, 134, 255}}},
	{{{ -19, -8, 0 }, 0, { -1254, 902 }, { 132, 25, 255, 255}}},
	{{{ 76, -46, 0 }, 0, { -290, 516 }, { 64, 147, 255, 255}}},
	{{{ 76, 0, 41 }, 0, { -290, 990 }, { 24, 66, 105, 255}}},
	{{{ 0, 0, 28 }, 0, { -1052, 990 }, { 179, 60, 81, 255}}},
	{{{ 103, 1, 1 }, 0, { -24, 1000 }, { 126, 11, 0, 255}}},
};

Vtx VB_mips_geo_0x6010ff8[] = {
	{{{ 1, 0, -13 }, 0, { -52, 2012 }, { 190, 95, 207, 255}}},
	{{{ 1, 0, 15 }, 0, { -52, 2012 }, { 160, 47, 67, 255}}},
	{{{ 80, 0, 28 }, 0, { 702, 2122 }, { 53, 45, 105, 255}}},
	{{{ 80, 0, -26 }, 0, { 702, 2122 }, { 57, 2, 143, 255}}},
	{{{ 94, -14, 1 }, 0, { 848, 1676 }, { 125, 235, 0, 255}}},
};

Vtx VB_mips_geo_0x6011048[] = {
	{{{ -2, -19, 0 }, 0, { -72, 1382 }, { 188, 150, 254, 255}}},
	{{{ 1, 0, 15 }, 0, { -52, 2012 }, { 160, 47, 67, 255}}},
	{{{ 1, 0, -13 }, 0, { -52, 2012 }, { 190, 95, 207, 255}}},
};

Vtx VB_mips_geo_0x6011078[] = {
	{{{ -2, -19, 0 }, 0, { -72, 1382 }, { 188, 150, 254, 255}}},
	{{{ 80, 0, -26 }, 0, { 702, 2122 }, { 57, 2, 143, 255}}},
	{{{ 79, -32, 0 }, 0, { 714, 1108 }, { 51, 141, 255, 255}}},
	{{{ 80, 0, 28 }, 0, { 702, 2122 }, { 53, 45, 105, 255}}},
	{{{ 94, -14, 1 }, 0, { 848, 1676 }, { 125, 235, 0, 255}}},
	{{{ 1, 0, -13 }, 0, { -52, 2012 }, { 190, 95, 207, 255}}},
	{{{ 1, 0, 15 }, 0, { -52, 2012 }, { 160, 47, 67, 255}}},
};

Vtx VB_mips_geo_0x6011230[] = {
	{{{ 87, 0, 55 }, 0, { 732, 2272 }, { 45, 70, 95, 255}}},
	{{{ 126, 0, 1 }, 0, { 1082, 2254 }, { 124, 231, 0, 255}}},
	{{{ 87, 0, -52 }, 0, { 732, 2272 }, { 30, 102, 188, 255}}},
	{{{ 0, 0, 41 }, 0, { -58, 2302 }, { 189, 63, 86, 255}}},
	{{{ 0, 0, -35 }, 0, { -58, 2302 }, { 184, 23, 155, 255}}},
	{{{ -19, -20, -3 }, 0, { -238, 1860 }, { 131, 240, 251, 255}}},
};

Vtx VB_mips_geo_0x6011290[] = {
	{{{ -19, -20, -3 }, 0, { -238, 1860 }, { 131, 240, 251, 255}}},
	{{{ 0, -38, 28 }, 0, { -54, 1464 }, { 204, 151, 46, 255}}},
	{{{ 0, 0, 41 }, 0, { -58, 2302 }, { 189, 63, 86, 255}}},
	{{{ 0, -38, -22 }, 0, { -54, 1464 }, { 196, 164, 194, 255}}},
	{{{ 0, 0, -35 }, 0, { -58, 2302 }, { 184, 23, 155, 255}}},
	{{{ 89, -42, -18 }, 0, { 750, 1340 }, { 33, 150, 197, 255}}},
	{{{ 89, -42, 21 }, 0, { 750, 1340 }, { 43, 161, 71, 255}}},
	{{{ 87, 0, 55 }, 0, { 732, 2272 }, { 45, 70, 95, 255}}},
	{{{ 87, 0, -52 }, 0, { 732, 2272 }, { 30, 102, 188, 255}}},
	{{{ 126, 0, 1 }, 0, { 1082, 2254 }, { 124, 231, 0, 255}}},
};

Vtx VB_mips_geo_0x6011490[] = {
	{{{ 54, 0, -35 }, 0, { -112, 464 }, { 94, 247, 172, 255}}},
	{{{ 54, 0, 41 }, 0, { -112, 464 }, { 104, 24, 67, 255}}},
	{{{ 49, -37, 3 }, 0, { -288, 54 }, { 64, 147, 0, 255}}},
	{{{ -2, 52, -19 }, 0, { -756, 1148 }, { 224, 80, 164, 255}}},
	{{{ -2, 52, 24 }, 0, { -756, 1148 }, { 182, 42, 94, 255}}},
};

Vtx VB_mips_geo_0x60114e0[] = {
	{{{ -2, 52, 24 }, 0, { -756, 1148 }, { 182, 42, 94, 255}}},
	{{{ -2, 52, -19 }, 0, { -756, 1148 }, { 224, 80, 164, 255}}},
	{{{ -14, 13, 2 }, 0, { -1032, 740 }, { 134, 223, 0, 255}}},
	{{{ 27, -28, -22 }, 0, { -560, 194 }, { 202, 170, 181, 255}}},
	{{{ 27, -28, 28 }, 0, { -560, 194 }, { 200, 170, 74, 255}}},
	{{{ 54, 0, -35 }, 0, { -112, 464 }, { 94, 247, 172, 255}}},
	{{{ 49, -37, 3 }, 0, { -288, 54 }, { 64, 147, 0, 255}}},
	{{{ 54, 0, 41 }, 0, { -112, 464 }, { 104, 24, 67, 255}}},
};

Vtx VB_mips_geo_0x60116a0[] = {
	{{{ 87, 0, -54 }, 0, { 1972, 878 }, { 45, 70, 161, 255}}},
	{{{ 0, 0, -40 }, 0, { 3460, 788 }, { 189, 63, 170, 255}}},
	{{{ 87, 0, 53 }, 0, { 1972, 878 }, { 30, 102, 68, 255}}},
	{{{ 0, 0, 36 }, 0, { 3460, 788 }, { 184, 23, 101, 255}}},
	{{{ -19, -20, 4 }, 0, { 3784, 484 }, { 131, 240, 5, 255}}},
	{{{ 126, 0, 0 }, 0, { 1316, 914 }, { 124, 231, 0, 255}}},
};

Vtx VB_mips_geo_0x6011700[] = {
	{{{ 0, 0, -40 }, 0, { 3460, 788 }, { 189, 63, 170, 255}}},
	{{{ 87, 0, -54 }, 0, { 1972, 878 }, { 45, 70, 161, 255}}},
	{{{ 89, -42, -20 }, 0, { 1906, 290 }, { 43, 161, 185, 255}}},
	{{{ 0, -38, -27 }, 0, { 3426, 260 }, { 204, 151, 210, 255}}},
	{{{ -19, -20, 4 }, 0, { 3784, 484 }, { 131, 240, 5, 255}}},
	{{{ 89, -42, 19 }, 0, { 1906, 290 }, { 33, 150, 59, 255}}},
	{{{ 0, -38, 23 }, 0, { 3426, 260 }, { 196, 164, 62, 255}}},
	{{{ 0, 0, 36 }, 0, { 3460, 788 }, { 184, 23, 101, 255}}},
	{{{ 87, 0, 53 }, 0, { 1972, 878 }, { 30, 102, 68, 255}}},
	{{{ 126, 0, 0 }, 0, { 1316, 914 }, { 124, 231, 0, 255}}},
};

Vtx VB_mips_geo_0x6011900[] = {
	{{{ 49, -37, -2 }, 0, { -516, -60 }, { 64, 147, 0, 255}}},
	{{{ 54, 0, -40 }, 0, { -564, -446 }, { 104, 24, 189, 255}}},
	{{{ 54, 0, 36 }, 0, { -564, 330 }, { 94, 247, 84, 255}}},
	{{{ -2, 52, 20 }, 0, { 2, 164 }, { 224, 80, 92, 255}}},
	{{{ -2, 52, -23 }, 0, { 2, -268 }, { 182, 42, 162, 255}}},
};

Vtx VB_mips_geo_0x6011950[] = {
	{{{ -14, 13, -1 }, 0, { 120, -56 }, { 134, 223, 0, 255}}},
	{{{ -2, 52, 20 }, 0, { 2, 164 }, { 224, 80, 92, 255}}},
	{{{ -2, 52, -23 }, 0, { 2, -268 }, { 182, 42, 162, 255}}},
	{{{ 49, -37, -2 }, 0, { -516, -60 }, { 64, 147, 0, 255}}},
	{{{ 54, 0, 36 }, 0, { -564, 330 }, { 94, 247, 84, 255}}},
	{{{ 27, -28, 23 }, 0, { -302, 200 }, { 202, 170, 75, 255}}},
	{{{ 27, -28, -27 }, 0, { -302, -312 }, { 200, 170, 182, 255}}},
	{{{ 54, 0, -40 }, 0, { -564, -446 }, { 104, 24, 189, 255}}},
};

Vtx VB_mips_geo_0x6011b10[] = {
	{{{ 76, 0, 40 }, 0, { -628, 934 }, { 28, 17, 122, 255}}},
	{{{ 76, 0, -40 }, 0, { -628, 934 }, { 24, 66, 151, 255}}},
	{{{ 0, 0, 27 }, 0, { -1998, 894 }, { 198, 93, 63, 255}}},
	{{{ 103, 1, 0 }, 0, { -142, 966 }, { 126, 11, 0, 255}}},
	{{{ 0, 0, -27 }, 0, { -1998, 894 }, { 181, 60, 175, 255}}},
	{{{ -19, -8, 0 }, 0, { -2378, 732 }, { 132, 25, 0, 255}}},
};

Vtx VB_mips_geo_0x6011b70[] = {
	{{{ -19, -8, 0 }, 0, { -2378, 732 }, { 132, 25, 0, 255}}},
	{{{ -11, -30, 0 }, 0, { -2264, 358 }, { 188, 149, 0, 255}}},
	{{{ 0, 0, 27 }, 0, { -1998, 894 }, { 198, 93, 63, 255}}},
	{{{ 0, 0, -27 }, 0, { -1998, 894 }, { 181, 60, 175, 255}}},
	{{{ 76, -46, 0 }, 0, { -708, 126 }, { 64, 147, 0, 255}}},
	{{{ 76, 0, 40 }, 0, { -628, 934 }, { 28, 17, 122, 255}}},
	{{{ 76, 0, -40 }, 0, { -628, 934 }, { 24, 66, 151, 255}}},
	{{{ 103, 1, 0 }, 0, { -142, 966 }, { 126, 11, 0, 255}}},
};

Vtx VB_mips_geo_0x6011d30[] = {
	{{{ 94, -14, 0 }, 0, { -84, 658 }, { 125, 235, 0, 255}}},
	{{{ 80, 0, -27 }, 0, { -338, 952 }, { 53, 47, 151, 255}}},
	{{{ 80, 0, 27 }, 0, { -338, 952 }, { 57, 255, 113, 255}}},
	{{{ 1, 0, 14 }, 0, { -1644, 926 }, { 189, 95, 48, 255}}},
	{{{ 1, 0, -14 }, 0, { -1644, 926 }, { 162, 49, 188, 255}}},
	{{{ -2, -19, 0 }, 0, { -1674, 522 }, { 188, 150, 0, 255}}},
};

Vtx VB_mips_geo_0x6011d90[] = {
	{{{ 94, -14, 0 }, 0, { -84, 658 }, { 125, 235, 0, 255}}},
	{{{ 79, -32, 0 }, 0, { -312, 302 }, { 51, 141, 0, 255}}},
	{{{ 80, 0, -27 }, 0, { -338, 952 }, { 53, 47, 151, 255}}},
	{{{ 80, 0, 27 }, 0, { -338, 952 }, { 57, 255, 113, 255}}},
	{{{ 1, 0, 14 }, 0, { -1644, 926 }, { 189, 95, 48, 255}}},
	{{{ -2, -19, 0 }, 0, { -1674, 522 }, { 188, 150, 0, 255}}},
	{{{ 1, 0, -14 }, 0, { -1644, 926 }, { 162, 49, 188, 255}}},
};

Vtx VB_mips_geo_0x6011f18[] = {
	{{{ 51, -16, -11 }, 0, { 0, 0 }, { 241, 181, 155, 255}}},
	{{{ 51, -16, 13 }, 0, { 0, 0 }, { 242, 147, 62, 255}}},
	{{{ 0, -12, -6 }, 0, { 0, 0 }, { 242, 181, 156, 255}}},
	{{{ 0, -12, 8 }, 0, { 0, 0 }, { 242, 235, 124, 255}}},
	{{{ 53, 21, 0 }, 0, { 0, 0 }, { 230, 124, 252, 255}}},
	{{{ 0, 10, 0 }, 0, { 0, 0 }, { 231, 124, 251, 255}}},
};

Vtx VB_mips_geo_0x6012000[] = {
	{{{ 0, -12, -7 }, 0, { 0, 0 }, { 243, 232, 133, 255}}},
	{{{ 0, 10, 0 }, 0, { 0, 0 }, { 231, 124, 0, 255}}},
	{{{ 53, 21, 0 }, 0, { 0, 0 }, { 230, 124, 0, 255}}},
	{{{ 51, -16, -12 }, 0, { 0, 0 }, { 242, 147, 195, 255}}},
	{{{ 0, -12, 7 }, 0, { 0, 0 }, { 241, 182, 101, 255}}},
	{{{ 51, -16, 12 }, 0, { 0, 0 }, { 241, 183, 102, 255}}},
};

Light_t Light_mips_geo_0x6010918 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6010910 = {
	{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_mips_geo_0x6010d30[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_mips_geo_0x6010b88),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x6010b88[] = {
	gsDPSetTextureImage(0, 2, 1, mips_geo__texture_0600FC70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_mips_geo_0x6010918.col, 1),
	gsSPLight(&Light_mips_geo_0x6010910.col, 2),
	gsSPVertex(VB_mips_geo_0x6010928, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 4, 0),
	gsSP2Triangles(0, 5, 1, 0, 1, 6, 3, 0),
	gsSP2Triangles(1, 4, 2, 0, 7, 1, 5, 0),
	gsSP2Triangles(6, 1, 7, 0, 8, 6, 9, 0),
	gsSP2Triangles(5, 9, 6, 0, 8, 3, 6, 0),
	gsSP2Triangles(7, 10, 6, 0, 5, 6, 10, 0),
	gsSP2Triangles(8, 11, 3, 0, 11, 4, 3, 0),
	gsSP2Triangles(9, 5, 12, 0, 8, 9, 13, 0),
	gsSP2Triangles(9, 12, 13, 0, 11, 2, 4, 0),
	gsSP1Triangle(12, 14, 13, 0),
	gsSPVertex(VB_mips_geo_0x6010a18, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
	gsSP2Triangles(0, 2, 4, 0, 4, 5, 6, 0),
	gsSP2Triangles(7, 6, 5, 0, 8, 9, 10, 0),
	gsSP2Triangles(11, 12, 8, 0, 9, 8, 12, 0),
	gsSP2Triangles(8, 13, 11, 0, 13, 8, 10, 0),
	gsSP2Triangles(13, 1, 3, 0, 10, 2, 13, 0),
	gsSP2Triangles(3, 11, 13, 0, 2, 1, 13, 0),
	gsSP2Triangles(10, 9, 5, 0, 5, 4, 10, 0),
	gsSP2Triangles(10, 4, 2, 0, 5, 14, 7, 0),
	gsSP1Triangle(12, 14, 9, 0),
	gsSPVertex(VB_mips_geo_0x6010b08, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
	gsSP2Triangles(4, 5, 6, 0, 2, 7, 3, 0),
	gsSP2Triangles(1, 7, 2, 0, 3, 7, 1, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x6010478 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Light_t Light_mips_geo_0x6010490 = {
	{ 39, 33, 11}, 0, { 39, 33, 11}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6010470 = {
	{102, 102, 102}, 0, {102, 102, 102}, 0
};

Ambient_t Light_mips_geo_0x6010488 = {
	{15, 13, 4}, 0, {15, 13, 4}, 0
};

Gfx DL_mips_geo_0x60108a8[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_mips_geo_0x60106f0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPDisplayList(DL_mips_geo_0x6010838),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x60106f0[] = {
	gsDPSetTextureImage(0, 2, 1, mips_geo__texture_0600FC70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_mips_geo_0x6010478.col, 1),
	gsSPLight(&Light_mips_geo_0x6010470.col, 2),
	gsSPVertex(VB_mips_geo_0x60104a0, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(2, 1, 4, 0, 2, 5, 3, 0),
	gsSP2Triangles(2, 6, 5, 0, 2, 4, 6, 0),
	gsSP2Triangles(5, 6, 7, 0, 8, 3, 5, 0),
	gsSP2Triangles(5, 9, 8, 0, 9, 5, 7, 0),
	gsSP2Triangles(3, 10, 0, 0, 8, 10, 3, 0),
	gsSP2Triangles(6, 11, 7, 0, 4, 11, 6, 0),
	gsSP2Triangles(12, 11, 4, 0, 4, 1, 12, 0),
	gsSP2Triangles(8, 9, 13, 0, 14, 10, 8, 0),
	gsSP2Triangles(8, 15, 14, 0, 13, 15, 8, 0),
	gsSPVertex(VB_mips_geo_0x60105a0, 13, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
	gsSP2Triangles(2, 4, 0, 0, 5, 6, 1, 0),
	gsSP2Triangles(5, 1, 7, 0, 7, 1, 3, 0),
	gsSP2Triangles(5, 8, 6, 0, 6, 9, 2, 0),
	gsSP2Triangles(2, 9, 10, 0, 2, 10, 4, 0),
	gsSP2Triangles(11, 5, 7, 0, 9, 12, 10, 0),
	gsSP1Triangle(6, 8, 9, 0),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x6010838[] = {
	gsSPLight(&Light_mips_geo_0x6010490.col, 1),
	gsSPLight(&Light_mips_geo_0x6010488.col, 2),
	gsSPVertex(VB_mips_geo_0x6010670, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP1Triangle(3, 2, 1, 0),
	gsSPLight(&Light_mips_geo_0x6010478.col, 1),
	gsSPLight(&Light_mips_geo_0x6010470.col, 2),
	gsSPVertex(VB_mips_geo_0x60106b0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(3, 2, 0, 0, 2, 1, 0, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x6011d08 = {
	{ 150, 150, 0}, 0, { 150, 150, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_mips_geo_0x6011d20 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6011d00 = {
	{60, 60, 0}, 0, {60, 60, 0}, 0
};

Ambient_t Light_mips_geo_0x6011d18 = {
	{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_mips_geo_0x6011ea0[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_mips_geo_0x6011e00),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x6011e00[] = {
	gsDPSetTextureImage(0, 2, 1, mips_geo__texture_0600FC70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_mips_geo_0x6011d08.col, 1),
	gsSPLight(&Light_mips_geo_0x6011d00.col, 2),
	gsSPVertex(VB_mips_geo_0x6011d30, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSP2Triangles(1, 4, 3, 0, 3, 4, 5, 0),
	gsSPLight(&Light_mips_geo_0x6011d20.col, 1),
	gsSPLight(&Light_mips_geo_0x6011d18.col, 2),
	gsSPVertex(VB_mips_geo_0x6011d90, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(3, 4, 5, 0, 1, 3, 5, 0),
	gsSP2Triangles(2, 1, 5, 0, 5, 6, 2, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x6011ae8 = {
	{ 150, 150, 0}, 0, { 150, 150, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_mips_geo_0x6011b00 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6011ae0 = {
	{60, 60, 0}, 0, {60, 60, 0}, 0
};

Ambient_t Light_mips_geo_0x6011af8 = {
	{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_mips_geo_0x6011ca0[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_mips_geo_0x6011bf0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x6011bf0[] = {
	gsDPSetTextureImage(0, 2, 1, mips_geo__texture_0600FC70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_mips_geo_0x6011ae8.col, 1),
	gsSPLight(&Light_mips_geo_0x6011ae0.col, 2),
	gsSPVertex(VB_mips_geo_0x6011b10, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(1, 4, 2, 0, 5, 2, 4, 0),
	gsSPLight(&Light_mips_geo_0x6011b00.col, 1),
	gsSPLight(&Light_mips_geo_0x6011af8.col, 2),
	gsSPVertex(VB_mips_geo_0x6011b70, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 1, 0, 1, 3, 6, 0),
	gsSP2Triangles(5, 2, 1, 0, 6, 4, 1, 0),
	gsSP2Triangles(4, 7, 5, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x6010fb8 = {
	{ 150, 150, 0}, 0, { 150, 150, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_mips_geo_0x6010fd0 = {
	{ 133, 142, 0}, 0, { 133, 142, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_mips_geo_0x6010fe8 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6010fb0 = {
	{60, 60, 0}, 0, {60, 60, 0}, 0
};

Ambient_t Light_mips_geo_0x6010fc8 = {
	{53, 56, 0}, 0, {53, 56, 0}, 0
};

Ambient_t Light_mips_geo_0x6010fe0 = {
	{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_mips_geo_0x60111a0[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_mips_geo_0x60110e8),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x60110e8[] = {
	gsDPSetTextureImage(0, 2, 1, mips_geo__texture_0600FC70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_mips_geo_0x6010fb8.col, 1),
	gsSPLight(&Light_mips_geo_0x6010fb0.col, 2),
	gsSPVertex(VB_mips_geo_0x6010ff8, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP1Triangle(3, 2, 4, 0),
	gsSPLight(&Light_mips_geo_0x6010fd0.col, 1),
	gsSPLight(&Light_mips_geo_0x6010fc8.col, 2),
	gsSPVertex(VB_mips_geo_0x6011048, 3, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSPLight(&Light_mips_geo_0x6010fe8.col, 1),
	gsSPLight(&Light_mips_geo_0x6010fe0.col, 2),
	gsSPVertex(VB_mips_geo_0x6011078, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(3, 2, 4, 0, 2, 1, 4, 0),
	gsSP2Triangles(0, 5, 1, 0, 3, 6, 0, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x6010d98 = {
	{ 150, 150, 0}, 0, { 150, 150, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_mips_geo_0x6010db0 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6010d90 = {
	{60, 60, 0}, 0, {60, 60, 0}, 0
};

Ambient_t Light_mips_geo_0x6010da8 = {
	{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_mips_geo_0x6010f50[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_mips_geo_0x6010ea0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x6010ea0[] = {
	gsDPSetTextureImage(0, 2, 1, mips_geo__texture_0600FC70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_mips_geo_0x6010d98.col, 1),
	gsSPLight(&Light_mips_geo_0x6010d90.col, 2),
	gsSPVertex(VB_mips_geo_0x6010dc0, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(0, 4, 1, 0, 4, 0, 5, 0),
	gsSPLight(&Light_mips_geo_0x6010db0.col, 1),
	gsSPLight(&Light_mips_geo_0x6010da8.col, 2),
	gsSPVertex(VB_mips_geo_0x6010e20, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(0, 2, 4, 0, 5, 6, 0, 0),
	gsSP2Triangles(0, 6, 3, 0, 0, 4, 5, 0),
	gsSP2Triangles(2, 7, 4, 0, 7, 5, 4, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x6011ff0 = {
	{ 130, 110, 38}, 0, { 130, 110, 38}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6011fe8 = {
	{52, 44, 15}, 0, {52, 44, 15}, 0
};

Gfx DL_mips_geo_0x60120b0[] = {
	gsDPPipeSync(),
	gsSPDisplayList(DL_mips_geo_0x6012060),
	gsDPPipeSync(),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x6012060[] = {
	gsSPLight(&Light_mips_geo_0x6011ff0.col, 1),
	gsSPLight(&Light_mips_geo_0x6011fe8.col, 2),
	gsSPVertex(VB_mips_geo_0x6012000, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 2, 0, 2, 1, 4, 0),
	gsSP2Triangles(4, 3, 5, 0, 4, 0, 3, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x60118d8 = {
	{ 150, 150, 0}, 0, { 150, 150, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_mips_geo_0x60118f0 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x60118d0 = {
	{60, 60, 0}, 0, {60, 60, 0}, 0
};

Ambient_t Light_mips_geo_0x60118e8 = {
	{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_mips_geo_0x6011a80[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_mips_geo_0x60119d0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x60119d0[] = {
	gsDPSetTextureImage(0, 2, 1, mips_geo__texture_0600FC70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_mips_geo_0x60118d8.col, 1),
	gsSPLight(&Light_mips_geo_0x60118d0.col, 2),
	gsSPVertex(VB_mips_geo_0x6011900, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
	gsSP1Triangle(1, 4, 3, 0),
	gsSPLight(&Light_mips_geo_0x60118f0.col, 1),
	gsSPLight(&Light_mips_geo_0x60118e8.col, 2),
	gsSPVertex(VB_mips_geo_0x6011950, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(5, 6, 3, 0, 6, 7, 3, 0),
	gsSP2Triangles(5, 4, 1, 0, 6, 5, 0, 0),
	gsSP2Triangles(1, 0, 5, 0, 2, 7, 6, 0),
	gsSP1Triangle(6, 0, 2, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x6011678 = {
	{ 150, 150, 0}, 0, { 150, 150, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_mips_geo_0x6011690 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6011670 = {
	{60, 60, 0}, 0, {60, 60, 0}, 0
};

Ambient_t Light_mips_geo_0x6011688 = {
	{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_mips_geo_0x6011870[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_mips_geo_0x60117a0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x60117a0[] = {
	gsDPSetTextureImage(0, 2, 1, mips_geo__texture_0600FC70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_mips_geo_0x6011678.col, 1),
	gsSPLight(&Light_mips_geo_0x6011670.col, 2),
	gsSPVertex(VB_mips_geo_0x60116a0, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(4, 3, 1, 0, 2, 5, 0, 0),
	gsSPLight(&Light_mips_geo_0x6011690.col, 1),
	gsSPLight(&Light_mips_geo_0x6011688.col, 2),
	gsSPVertex(VB_mips_geo_0x6011700, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 4, 0),
	gsSP2Triangles(2, 3, 0, 0, 3, 2, 5, 0),
	gsSP2Triangles(4, 3, 6, 0, 5, 6, 3, 0),
	gsSP2Triangles(6, 7, 4, 0, 7, 6, 5, 0),
	gsSP2Triangles(5, 8, 7, 0, 5, 9, 8, 0),
	gsSP2Triangles(5, 2, 9, 0, 2, 1, 9, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x6011f08 = {
	{ 130, 110, 38}, 0, { 130, 110, 38}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6011f00 = {
	{52, 44, 15}, 0, {52, 44, 15}, 0
};

Gfx DL_mips_geo_0x6011fc8[] = {
	gsDPPipeSync(),
	gsSPDisplayList(DL_mips_geo_0x6011f78),
	gsDPPipeSync(),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x6011f78[] = {
	gsSPLight(&Light_mips_geo_0x6011f08.col, 1),
	gsSPLight(&Light_mips_geo_0x6011f00.col, 2),
	gsSPVertex(VB_mips_geo_0x6011f18, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(4, 0, 2, 0, 2, 5, 4, 0),
	gsSP2Triangles(4, 5, 3, 0, 1, 4, 3, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x6011468 = {
	{ 150, 150, 0}, 0, { 150, 150, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_mips_geo_0x6011480 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6011460 = {
	{60, 60, 0}, 0, {60, 60, 0}, 0
};

Ambient_t Light_mips_geo_0x6011478 = {
	{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_mips_geo_0x6011610[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_mips_geo_0x6011560),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x6011560[] = {
	gsDPSetTextureImage(0, 2, 1, mips_geo__texture_0600FC70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_mips_geo_0x6011468.col, 1),
	gsSPLight(&Light_mips_geo_0x6011460.col, 2),
	gsSPVertex(VB_mips_geo_0x6011490, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP1Triangle(3, 4, 1, 0),
	gsSPLight(&Light_mips_geo_0x6011480.col, 1),
	gsSPLight(&Light_mips_geo_0x6011478.col, 2),
	gsSPVertex(VB_mips_geo_0x60114e0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
	gsSP2Triangles(3, 2, 1, 0, 3, 5, 6, 0),
	gsSP2Triangles(6, 4, 3, 0, 1, 5, 3, 0),
	gsSP2Triangles(6, 7, 4, 0, 4, 7, 0, 0),
	gsSP1Triangle(0, 2, 4, 0),
	gsSPEndDisplayList(),
};

Light_t Light_mips_geo_0x6011208 = {
	{ 150, 150, 0}, 0, { 150, 150, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_mips_geo_0x6011220 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_mips_geo_0x6011200 = {
	{60, 60, 0}, 0, {60, 60, 0}, 0
};

Ambient_t Light_mips_geo_0x6011218 = {
	{102, 102, 102}, 0, {102, 102, 102}, 0
};

Gfx DL_mips_geo_0x6011400[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_mips_geo_0x6011330),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_mips_geo_0x6011330[] = {
	gsDPSetTextureImage(0, 2, 1, mips_geo__texture_0600FC70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_mips_geo_0x6011208.col, 1),
	gsSPLight(&Light_mips_geo_0x6011200.col, 2),
	gsSPVertex(VB_mips_geo_0x6011230, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
	gsSP2Triangles(2, 4, 3, 0, 3, 4, 5, 0),
	gsSPLight(&Light_mips_geo_0x6011220.col, 1),
	gsSPLight(&Light_mips_geo_0x6011218.col, 2),
	gsSPVertex(VB_mips_geo_0x6011290, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
	gsSP2Triangles(0, 4, 3, 0, 5, 6, 1, 0),
	gsSP2Triangles(1, 3, 5, 0, 2, 1, 6, 0),
	gsSP2Triangles(6, 7, 2, 0, 5, 3, 4, 0),
	gsSP2Triangles(4, 8, 5, 0, 8, 9, 5, 0),
	gsSP2Triangles(9, 6, 5, 0, 9, 7, 6, 0),
	gsSPEndDisplayList(),
};

