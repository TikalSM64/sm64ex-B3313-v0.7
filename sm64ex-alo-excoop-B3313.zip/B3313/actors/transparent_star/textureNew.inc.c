ALIGNED8 u8 transparent_star_geo__texture_03037320[] = {
#include "actors/transparent_star/transparent_star_geo_0x3037320_custom.rgba16.inc.c"
};
