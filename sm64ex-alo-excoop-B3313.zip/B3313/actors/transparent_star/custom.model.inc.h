#ifndef transparent_star_transparent_star_model_HEADER_H
#define transparent_star_transparent_star_model_HEADER_H
#include "types.h"
extern Vtx VB_transparent_star_geo_0x3037b28[];
extern u8 transparent_star_geo__texture_03037320[];
extern Light_t Light_transparent_star_geo_0x3037310;
extern Ambient_t Light_transparent_star_geo_0x3037308;
extern Gfx DL_transparent_star_geo_0x3037b68[];
#endif