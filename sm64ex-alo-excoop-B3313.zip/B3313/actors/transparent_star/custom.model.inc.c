#include "custom.model.inc.h"
Vtx VB_transparent_star_geo_0x3037b28[] = {
	{{{ 350, 330, 0 }, 0, { 1000, -1041 }, { 0, 0, 127, 255}}},
	{{{ -345, -333, 0 }, 0, { 8, -94 }, { 0, 0, 127, 255}}},
	{{{ 350, -333, 0 }, 0, { 1000, -94 }, { 0, 0, 127, 255}}},
	{{{ -345, 330, 0 }, 0, { 8, -1041 }, { 0, 0, 127, 255}}},
};

Light_t Light_transparent_star_geo_0x3037310 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 73, 73, 73}, 0
};

Ambient_t Light_transparent_star_geo_0x3037308 = {
	{255, 255, 255}, 0, {255, 255, 255}, 0
};

Gfx DL_transparent_star_geo_0x3037b68[] = {
	gsDPPipeSync(),
	gsSPGeometryMode(0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPLoadSync(),
	gsSPLight(&Light_transparent_star_geo_0x3037308.col, 2),
	gsSPLight(&Light_transparent_star_geo_0x3037310.col, 1),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsDPSetTextureImage(0, 2, 1, transparent_star_geo__texture_03037320),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPPipeSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 0, 5, 0, 0, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPVertex(VB_transparent_star_geo_0x3037b28, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsSPEndDisplayList(),
};

