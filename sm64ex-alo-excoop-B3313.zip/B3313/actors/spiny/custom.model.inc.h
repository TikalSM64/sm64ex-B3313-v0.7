#ifndef spiny_spiny_model_HEADER_H
#define spiny_spiny_model_HEADER_H
#include "types.h"
extern Vtx VB_spiny_geo_0x5015888[];
extern Vtx VB_spiny_geo_0x5015958[];
extern Vtx VB_spiny_geo_0x50159b8[];
extern Vtx VB_spiny_geo_0x5015a88[];
extern Vtx VB_spiny_geo_0x5015ae8[];
extern Vtx VB_spiny_geo_0x5015bb8[];
extern Vtx VB_spiny_geo_0x5015c18[];
extern Vtx VB_spiny_geo_0x5015ce8[];
extern Vtx VB_spiny_geo_0x5015d48[];
extern Vtx VB_spiny_geo_0x5015e48[];
extern Vtx VB_spiny_geo_0x5015f48[];
extern Vtx VB_spiny_geo_0x5015fa8[];
extern Vtx VB_spiny_geo_0x50160a8[];
extern Vtx VB_spiny_geo_0x5016148[];
extern Vtx VB_spiny_geo_0x5016238[];
extern Vtx VB_spiny_geo_0x5016328[];
extern Gfx DL_spiny_geo_0x5016a48[];
extern Light_t Light_spiny_geo_0x5015830;
extern Light_t Light_spiny_geo_0x5015860;
extern Light_t Light_spiny_geo_0x5015848;
extern Light_t Light_spiny_geo_0x5015878;
extern Ambient_t Light_spiny_geo_0x5015828;
extern Ambient_t Light_spiny_geo_0x5015858;
extern Ambient_t Light_spiny_geo_0x5015840;
extern Ambient_t Light_spiny_geo_0x5015870;
extern Gfx DL_spiny_geo_0x5016738[];
extern Light_t Light_spiny_geo_0x5015800;
extern Light_t Light_spiny_geo_0x5015818;
extern Ambient_t Light_spiny_geo_0x50157f8;
extern Ambient_t Light_spiny_geo_0x5015810;
extern Gfx DL_spiny_geo_0x5016418[];
extern Gfx DL_spiny_geo_0x50164e0[];
extern Gfx DL_spiny_geo_0x50165a8[];
extern Gfx DL_spiny_geo_0x5016670[];
#endif