#ifndef white_particle_small_white_particle_small_model_HEADER_H
#define white_particle_small_white_particle_small_model_HEADER_H
#include "types.h"
extern Vtx VB_white_particle_small_dl_0x4032700[];
extern u8 white_particle_small_dl__texture_04032780[];
extern Gfx DL_white_particle_small_dl_0x4032a18[];
extern Gfx DL_white_particle_small_dl_0x4032980[];
extern Gfx DL_white_particle_small_dl_0x40329e0[];
#endif