ALIGNED8 u8 white_particle_small_dl__texture_04032780[] = {
#include "actors/white_particle_small/white_particle_small_dl_0x4032780_custom.rgba16.inc.c"
};
