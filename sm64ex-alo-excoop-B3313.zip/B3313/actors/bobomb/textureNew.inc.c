ALIGNED8 u8 black_bobomb_geo__texture_0801DA60[] = {
#include "actors/bobomb/black_bobomb_geo_0x801da60_custom.rgba16.inc.c"
};
ALIGNED8 u8 black_bobomb_geo__texture_0801EA60[] = {
#include "actors/bobomb/black_bobomb_geo_0x801ea60_custom.rgba16.inc.c"
};
ALIGNED8 u8 black_bobomb_geo__texture_08021A60[] = {
#include "actors/bobomb/black_bobomb_geo_0x8021a60_custom.rgba16.inc.c"
};
ALIGNED8 u8 black_bobomb_geo__texture_08022260[] = {
#include "actors/bobomb/black_bobomb_geo_0x8022260_custom.rgba16.inc.c"
};
ALIGNED8 u8 bobomb_buddy_geo__texture_0801FA60[] = {
#include "actors/bobomb/bobomb_buddy_geo_0x801fa60_custom.rgba16.inc.c"
};
ALIGNED8 u8 bobomb_buddy_geo__texture_08020A60[] = {
#include "actors/bobomb/bobomb_buddy_geo_0x8020a60_custom.rgba16.inc.c"
};
