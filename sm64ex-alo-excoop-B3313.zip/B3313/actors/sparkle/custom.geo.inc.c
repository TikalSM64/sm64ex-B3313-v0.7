#include "custom.model.inc.h"
const GeoLayout sparkles_geo[]= {
GEO_SWITCH_CASE(12, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a570),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a570),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a558),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a558),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a540),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a540),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a528),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a528),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a510),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a510),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a4f8),
GEO_DISPLAY_LIST(4,DL_sparkles_geo_0x402a4f8),
GEO_CLOSE_NODE(),
GEO_END(),
};
