ALIGNED8 u8 amp_geo__texture_08001318[] = {
#include "actors/amp/amp_geo_0x8001318_custom.rgba16.inc.c"
};
ALIGNED8 u8 amp_geo__texture_08000F18[] = {
#include "actors/amp/amp_geo_0x8000f18_custom.rgba16.inc.c"
};
ALIGNED8 u8 amp_geo__texture_08002318[] = {
#include "actors/amp/amp_geo_0x8002318_custom.rgba16.inc.c"
};
ALIGNED8 u8 amp_geo__texture_08001B18[] = {
#include "actors/amp/amp_geo_0x8001b18_custom.rgba16.inc.c"
};
