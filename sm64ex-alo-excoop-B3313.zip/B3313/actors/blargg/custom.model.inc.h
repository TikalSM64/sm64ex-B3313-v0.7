#ifndef blargg_blargg_model_HEADER_H
#define blargg_blargg_model_HEADER_H
#include "types.h"
extern Vtx VB_blargg_geo_0x50047a0[];
extern Vtx VB_blargg_geo_0x50048a0[];
extern Vtx VB_blargg_geo_0x50049a0[];
extern Vtx VB_blargg_geo_0x5004a20[];
extern Vtx VB_blargg_geo_0x5004b20[];
extern Vtx VB_blargg_geo_0x5004be0[];
extern Vtx VB_blargg_geo_0x5004ce0[];
extern Vtx VB_blargg_geo_0x5004de0[];
extern Vtx VB_blargg_geo_0x5004e60[];
extern Vtx VB_blargg_geo_0x5004f60[];
extern Vtx VB_blargg_geo_0x5005050[];
extern Vtx VB_blargg_geo_0x5005150[];
extern Vtx VB_blargg_geo_0x5005250[];
extern Vtx VB_blargg_geo_0x5005340[];
extern Vtx VB_blargg_geo_0x50053e0[];
extern Vtx VB_blargg_geo_0x50054e0[];
extern Vtx VB_blargg_geo_0x50055e0[];
extern Vtx VB_blargg_geo_0x50056e0[];
extern Vtx VB_blargg_geo_0x50057e0[];
extern Light_t Light_blargg_geo_0x5004790;
extern Ambient_t Light_blargg_geo_0x5004788;
extern Gfx DL_blargg_geo_0x5005d00[];
extern Light_t Light_blargg_geo_0x5004760;
extern Light_t Light_blargg_geo_0x5004778;
extern Ambient_t Light_blargg_geo_0x5004758;
extern Ambient_t Light_blargg_geo_0x5004770;
extern Gfx DL_blargg_geo_0x5005a60[];
extern Light_t Light_blargg_geo_0x5004748;
extern Ambient_t Light_blargg_geo_0x5004740;
extern Gfx DL_blargg_geo_0x50058d0[];
#endif