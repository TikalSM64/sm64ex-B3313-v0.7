ALIGNED8 u8 yoshi_geo__texture_0501C988[] = {
#include "actors/yoshi/yoshi_geo_0x501c988_custom.rgba16.inc.c"
};
ALIGNED8 u8 yoshi_geo__texture_0501C588[] = {
#include "actors/yoshi/yoshi_geo_0x501c588_custom.rgba16.inc.c"
};
ALIGNED8 u8 yoshi_geo__texture_0501C788[] = {
#include "actors/yoshi/yoshi_geo_0x501c788_custom.rgba16.inc.c"
};
