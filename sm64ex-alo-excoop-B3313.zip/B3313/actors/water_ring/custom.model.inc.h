#ifndef water_ring_water_ring_model_HEADER_H
#define water_ring_water_ring_model_HEADER_H
#include "types.h"
extern Vtx VB_water_ring_geo_0x6013380[];
extern Vtx VB_water_ring_geo_0x6013480[];
extern Vtx VB_water_ring_geo_0x6013580[];
extern Vtx VB_water_ring_geo_0x6013680[];
extern Vtx VB_water_ring_geo_0x6013780[];
extern Vtx VB_water_ring_geo_0x6013880[];
extern Vtx VB_water_ring_geo_0x6013980[];
extern Vtx VB_water_ring_geo_0x6013a80[];
extern u8 water_ring_geo__texture_06012380[];
extern Light_t Light_water_ring_geo_0x6012370;
extern Ambient_t Light_water_ring_geo_0x6012368;
extern Gfx DL_water_ring_geo_0x6013ac0[];
#endif