#include "custom.model.inc.h"
const GeoLayout water_ring_geo[]= {
GEO_SCALE(0,32768),
GEO_OPEN_NODE(),
GEO_ANIMATED_PART(1,0,0,0,0),
GEO_OPEN_NODE(),
GEO_ASM(0, geo_update_layer_transparency),
GEO_ANIMATED_PART(5,0,0,0,DL_water_ring_geo_0x6013ac0),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
