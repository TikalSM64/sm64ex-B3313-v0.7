ALIGNED8 u8 water_ring_geo__texture_06012380[] = {
#include "actors/water_ring/water_ring_geo_0x6012380_custom.rgba16.inc.c"
};
