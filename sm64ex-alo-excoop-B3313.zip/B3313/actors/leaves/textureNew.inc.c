ALIGNED8 u8 leaves_geo__texture_0301CBE0[] = {
#include "actors/leaves/leaves_geo_0x301cbe0_custom.rgba16.inc.c"
};
