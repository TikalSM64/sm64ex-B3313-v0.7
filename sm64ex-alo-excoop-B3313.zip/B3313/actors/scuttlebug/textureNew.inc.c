ALIGNED8 u8 scuttlebug_geo__texture_06013108[] = {
#include "actors/scuttlebug/scuttlebug_geo_0x6013108_custom.rgba16.inc.c"
};
ALIGNED8 u8 scuttlebug_geo__texture_06010908[] = {
#include "actors/scuttlebug/scuttlebug_geo_0x6010908_custom.rgba16.inc.c"
};
ALIGNED8 u8 scuttlebug_geo__texture_06011908[] = {
#include "actors/scuttlebug/scuttlebug_geo_0x6011908_custom.rgba16.inc.c"
};
ALIGNED8 u8 scuttlebug_geo__texture_06010108[] = {
#include "actors/scuttlebug/scuttlebug_geo_0x6010108_custom.rgba16.inc.c"
};
ALIGNED8 u8 scuttlebug_geo__texture_06012908[] = {
#include "actors/scuttlebug/scuttlebug_geo_0x6012908_custom.rgba16.inc.c"
};
