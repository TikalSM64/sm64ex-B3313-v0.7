#include "custom.model.inc.h"
Vtx VB_exclamation_box_outline_seg8_dl_08025F08_0x8024d18[] = {
	{{{ 26, 1, -25 }, 0, { 0, 0 }, { 127, 0, 0, 80}}},
	{{{ 26, 52, 26 }, 0, { 0, 0 }, { 127, 0, 0, 80}}},
	{{{ 26, 1, 26 }, 0, { 0, 0 }, { 127, 0, 0, 80}}},
	{{{ 26, 1, 26 }, 0, { 0, 0 }, { 0, 129, 0, 80}}},
	{{{ -25, 1, 26 }, 0, { 0, 0 }, { 0, 129, 0, 80}}},
	{{{ -25, 1, -25 }, 0, { 0, 0 }, { 0, 129, 0, 80}}},
	{{{ 26, 1, -25 }, 0, { 0, 0 }, { 0, 129, 0, 80}}},
	{{{ 26, 1, 26 }, 0, { 0, 0 }, { 0, 0, 127, 80}}},
	{{{ 26, 52, 26 }, 0, { 0, 0 }, { 0, 0, 127, 80}}},
	{{{ -25, 52, 26 }, 0, { 0, 0 }, { 0, 0, 127, 80}}},
	{{{ -25, 1, 26 }, 0, { 0, 0 }, { 0, 0, 127, 80}}},
	{{{ -25, 1, 26 }, 0, { 0, 0 }, { 129, 0, 0, 80}}},
	{{{ -25, 52, 26 }, 0, { 0, 0 }, { 129, 0, 0, 80}}},
	{{{ -25, 52, -25 }, 0, { 0, 0 }, { 129, 0, 0, 80}}},
	{{{ -25, 1, -25 }, 0, { 0, 0 }, { 129, 0, 0, 80}}},
};

Vtx VB_exclamation_box_outline_seg8_dl_08025F08_0x8024e08[] = {
	{{{ -25, 1, -25 }, 0, { 0, 0 }, { 0, 0, 129, 80}}},
	{{{ -25, 52, -25 }, 0, { 0, 0 }, { 0, 0, 129, 80}}},
	{{{ 26, 52, -25 }, 0, { 0, 0 }, { 0, 0, 129, 80}}},
	{{{ 26, 1, -25 }, 0, { 0, 0 }, { 0, 0, 129, 80}}},
	{{{ 26, 1, -25 }, 0, { 0, 0 }, { 127, 0, 0, 80}}},
	{{{ 26, 52, -25 }, 0, { 0, 0 }, { 127, 0, 0, 80}}},
	{{{ 26, 52, 26 }, 0, { 0, 0 }, { 127, 0, 0, 80}}},
	{{{ -25, 52, 26 }, 0, { 0, 0 }, { 0, 127, 0, 80}}},
	{{{ 26, 52, 26 }, 0, { 0, 0 }, { 0, 127, 0, 80}}},
	{{{ 26, 52, -25 }, 0, { 0, 0 }, { 0, 127, 0, 80}}},
	{{{ -25, 52, -25 }, 0, { 0, 0 }, { 0, 127, 0, 80}}},
};

Vtx VB_exclamation_box_outline_seg8_dl_08025F08_0x8025008[] = {
	{{{ -25, 52, 26 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
	{{{ 26, 52, 26 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ 26, 52, -25 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ -25, 52, -25 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 26, 1, 26 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
	{{{ -25, 52, 26 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ -25, 1, 26 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 26, 1, -25 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
	{{{ 26, 52, -25 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ 26, 52, 26 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ 26, 1, 26 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ -25, 1, -25 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 26, 1, -25 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ -25, 52, -25 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_exclamation_box_outline_seg8_dl_08025F08_0x80250e8[] = {
	{{{ -25, 1, 26 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
	{{{ -25, 52, 26 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ -25, 52, -25 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ -25, 1, -25 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ -25, 1, 26 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ -25, 1, -25 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
	{{{ 26, 1, -25 }, 0, { 996, 0 }, { 255, 255, 255, 255}}},
	{{{ 26, 1, 26 }, 0, { -26, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_exclamation_box_outline_seg8_dl_08025F08_0x8025e80[] = {
	{{{ -22, 49, 0 }, 0, { -157, 0 }, { 0, 0, 127, 255}}},
	{{{ -22, 4, 0 }, 0, { -157, 1048 }, { 0, 0, 127, 255}}},
	{{{ 23, 4, 0 }, 0, { 605, 1048 }, { 0, 0, 127, 255}}},
	{{{ 23, 49, 0 }, 0, { 605, 0 }, { 0, 0, 127, 255}}},
};

Light_t Light_exclamation_box_outline_geo_0x8024cc0 = {
	{ 255, 0, 0}, 0, { 255, 0, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_exclamation_box_outline_geo_0x8024cb8 = {
	{127, 0, 0}, 0, {127, 0, 0}, 0
};

Gfx DL_exclamation_box_outline_geo_0x8024f88[] = {
	gsSPDisplayList(DL_exclamation_box_outline_geo_0x8024f30),
	gsSPLight(&Light_exclamation_box_outline_geo_0x8024cc0.col, 1),
	gsSPLight(&Light_exclamation_box_outline_geo_0x8024cb8.col, 2),
	gsSPBranchList(DL_exclamation_box_outline_geo_0x8024f58),
};

Gfx DL_exclamation_box_outline_geo_0x8024f30[] = {
	gsDPPipeSync(),
	gsDPSetEnvColor(255, 255, 255, 80),
	gsSPGeometryMode(G_SHADING_SMOOTH, 0),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPEndDisplayList(),
};

Gfx DL_exclamation_box_outline_geo_0x8024f58[] = {
	gsSPDisplayList(DL_exclamation_box_outline_geo_0x8024eb8),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_SHADING_SMOOTH),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsSPEndDisplayList(),
};

Gfx DL_exclamation_box_outline_geo_0x8024eb8[] = {
	gsSPVertex(VB_exclamation_box_outline_geo_0x8024d18, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 5, 6, 0, 7, 8, 9, 0),
	gsSP2Triangles(7, 9, 10, 0, 11, 12, 13, 0),
	gsSP1Triangle(11, 13, 14, 0),
	gsSPVertex(VB_exclamation_box_outline_geo_0x8024e08, 11, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 7, 8, 9, 0),
	gsSP1Triangle(7, 9, 10, 0),
	gsSPEndDisplayList(),
};

Light_t Light_exclamation_box_outline_geo_0x8024cd8 = {
	{ 0, 255, 0}, 0, { 0, 255, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_exclamation_box_outline_geo_0x8024cd0 = {
	{0, 127, 0}, 0, {0, 127, 0}, 0
};

Gfx DL_exclamation_box_outline_geo_0x8024fa8[] = {
	gsSPDisplayList(DL_exclamation_box_outline_geo_0x8024f30),
	gsSPLight(&Light_exclamation_box_outline_geo_0x8024cd8.col, 1),
	gsSPLight(&Light_exclamation_box_outline_geo_0x8024cd0.col, 2),
	gsSPBranchList(DL_exclamation_box_outline_geo_0x8024f58),
};

Light_t Light_exclamation_box_outline_geo_0x8024cf0 = {
	{ 0, 0, 255}, 0, { 0, 0, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_exclamation_box_outline_geo_0x8024ce8 = {
	{0, 0, 127}, 0, {0, 0, 127}, 0
};

Gfx DL_exclamation_box_outline_geo_0x8024fc8[] = {
	gsSPDisplayList(DL_exclamation_box_outline_geo_0x8024f30),
	gsSPLight(&Light_exclamation_box_outline_geo_0x8024cf0.col, 1),
	gsSPLight(&Light_exclamation_box_outline_geo_0x8024ce8.col, 2),
	gsSPBranchList(DL_exclamation_box_outline_geo_0x8024f58),
};

Light_t Light_exclamation_box_outline_geo_0x8024d08 = {
	{ 255, 212, 0}, 0, { 255, 212, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_exclamation_box_outline_geo_0x8024d00 = {
	{127, 106, 0}, 0, {127, 106, 0}, 0
};

Gfx DL_exclamation_box_outline_geo_0x8024fe8[] = {
	gsSPDisplayList(DL_exclamation_box_outline_geo_0x8024f30),
	gsSPLight(&Light_exclamation_box_outline_geo_0x8024d08.col, 1),
	gsSPLight(&Light_exclamation_box_outline_geo_0x8024d00.col, 2),
	gsSPBranchList(DL_exclamation_box_outline_geo_0x8024f58),
};

Gfx DL_exclamation_box_outline_geo_0x80259f8[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_exclamation_box_outline_geo_0x8025968),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_exclamation_box_outline_geo_0x8025968[] = {
	gsDPSetTextureImage(0, 2, 1, exclamation_box_outline_geo__texture_08025168),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_exclamation_box_outline_geo_0x8025008, 14, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 1, 5, 0, 4, 5, 6, 0),
	gsSP2Triangles(7, 8, 9, 0, 7, 9, 10, 0),
	gsSP2Triangles(11, 8, 12, 0, 11, 13, 8, 0),
	gsSPVertex(VB_exclamation_box_outline_geo_0x80250e8, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Light_t Light_exclamation_box_outline_seg8_dl_08025F08_0x8025a70 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_exclamation_box_outline_seg8_dl_08025F08_0x8025a68 = {
	{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_exclamation_box_outline_seg8_dl_08025F08_0x8025f08[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
	gsSPGeometryMode(G_CULL_BACK|G_SHADING_SMOOTH, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 4, 0, 0, 0, 2, 5, 0, 2, 4, 0),
	gsDPSetTileSize(0, 0, 0, 60, 124),
	gsSPDisplayList(DL_exclamation_box_outline_seg8_dl_08025F08_0x8025ec0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_CULL_BACK|G_SHADING_SMOOTH),
	gsSPEndDisplayList(),
};

Gfx DL_exclamation_box_outline_seg8_dl_08025F08_0x8025ec0[] = {
	gsDPSetTextureImage(0, 2, 1, exclamation_box_outline_seg8_dl_08025F08__texture_08025A80),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsSPLight(&Light_exclamation_box_outline_seg8_dl_08025F08_0x8025a70.col, 1),
	gsSPLight(&Light_exclamation_box_outline_seg8_dl_08025F08_0x8025a68.col, 2),
	gsSPVertex(VB_exclamation_box_outline_seg8_dl_08025F08_0x8025e80, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

