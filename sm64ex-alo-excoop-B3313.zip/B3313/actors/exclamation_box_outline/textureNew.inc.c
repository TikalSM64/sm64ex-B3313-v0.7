ALIGNED8 u8 exclamation_box_outline_geo__texture_08025168[] = {
#include "actors/exclamation_box_outline/exclamation_box_outline_geo_0x8025168_custom.rgba16.inc.c"
};
ALIGNED8 u8 exclamation_box_outline_seg8_dl_08025F08__texture_08025A80[] = {
#include "actors/exclamation_box_outline/exclamation_box_outline_seg8_dl_08025F08_0x8025a80_custom.rgba16.inc.c"
};
