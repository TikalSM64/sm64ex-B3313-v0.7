#include "custom.model.inc.h"
Vtx VB_spindrift_geo_0x50000c0[] = {
	{{{ 34, 40, 30 }, 0, { 0, 0 }, { 123, 23, 17, 0}}},
	{{{ 34, -16, 46 }, 0, { 0, 0 }, { 123, 247, 28, 0}}},
	{{{ 46, 0, 0 }, 0, { 0, 0 }, { 127, 0, 0, 0}}},
	{{{ 34, -50, 0 }, 0, { 0, 0 }, { 123, 227, 0, 255}}},
	{{{ 34, -16, -46 }, 0, { 0, 0 }, { 123, 247, 227, 255}}},
	{{{ 34, 40, -28 }, 0, { 0, 0 }, { 123, 24, 238, 255}}},
};

Vtx VB_spindrift_geo_0x5000120[] = {
	{{{ 6, 0, 0 }, 0, { 0, 0 }, { 129, 0, 0, 0}}},
	{{{ 34, -16, -46 }, 0, { 0, 0 }, { 146, 238, 196, 0}}},
	{{{ 34, -50, 0 }, 0, { 0, 0 }, { 146, 194, 0, 0}}},
	{{{ 34, -16, 46 }, 0, { 0, 0 }, { 146, 236, 59, 255}}},
	{{{ 34, 40, -28 }, 0, { 0, 0 }, { 146, 50, 219, 255}}},
	{{{ 34, 40, 30 }, 0, { 0, 0 }, { 146, 49, 37, 255}}},
};

Vtx VB_spindrift_geo_0x5000180[] = {
	{{{ 70, 50, 0 }, 0, { 0, 0 }, { 203, 115, 0, 0}}},
	{{{ 24, -12, 56 }, 0, { 0, 0 }, { 169, 34, 84, 0}}},
	{{{ 128, -2, 94 }, 0, { 0, 0 }, { 218, 69, 99, 0}}},
	{{{ 0, -5, 0 }, 0, { 0, 0 }, { 142, 55, 0, 255}}},
	{{{ 24, -12, -56 }, 0, { 0, 0 }, { 168, 34, 172, 255}}},
	{{{ 0, -57, 0 }, 0, { 0, 0 }, { 135, 221, 0, 255}}},
	{{{ 55, -113, 57 }, 0, { 0, 0 }, { 165, 206, 72, 255}}},
	{{{ 128, -2, -94 }, 0, { 0, 0 }, { 218, 69, 157, 255}}},
	{{{ 55, -113, -57 }, 0, { 0, 0 }, { 165, 206, 184, 255}}},
};

Vtx VB_spindrift_geo_0x5000210[] = {
	{{{ 55, -113, -57 }, 0, { 0, 0 }, { 165, 206, 184, 0}}},
	{{{ 55, -113, 57 }, 0, { 0, 0 }, { 165, 206, 72, 0}}},
	{{{ 0, -57, 0 }, 0, { 0, 0 }, { 135, 221, 0, 0}}},
	{{{ 128, -2, -94 }, 0, { 0, 0 }, { 218, 69, 157, 255}}},
	{{{ 24, -12, -56 }, 0, { 0, 0 }, { 168, 34, 172, 255}}},
	{{{ 128, -2, 94 }, 0, { 0, 0 }, { 218, 69, 99, 255}}},
	{{{ 24, -12, 56 }, 0, { 0, 0 }, { 169, 34, 84, 255}}},
	{{{ 138, 66, 0 }, 0, { 0, 0 }, { 227, 123, 0, 255}}},
	{{{ 70, 50, 0 }, 0, { 0, 0 }, { 203, 115, 0, 255}}},
};

Vtx VB_spindrift_geo_0x50026d0[] = {
	{{{ -54, -54, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 56, 56, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ -54, 56, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ 56, -54, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_spindrift_geo_0x50027b8[] = {
	{{{ 27, -112, -47 }, 0, { -36, 520 }, { 255, 255, 255, 255}}},
	{{{ 27, -112, 48 }, 0, { 990, 520 }, { 255, 255, 255, 255}}},
	{{{ -32, -112, -47 }, 0, { -36, 0 }, { 255, 255, 255, 255}}},
	{{{ -32, -112, 48 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_spindrift_geo_0x50028a0[] = {
	{{{ 36, -109, -44 }, 0, { -30, 572 }, { 255, 255, 255, 255}}},
	{{{ 83, -79, 0 }, 0, { 480, 1092 }, { 255, 255, 255, 255}}},
	{{{ 36, -109, 45 }, 0, { 990, 572 }, { 255, 255, 255, 255}}},
};

Vtx VB_spindrift_geo_0x5002988[] = {
	{{{ 19, 22, 102 }, 0, { 196, 1200 }, { 144, 37, 46, 255}}},
	{{{ 13, -6, 4 }, 0, { 1032, 456 }, { 146, 62, 245, 255}}},
	{{{ -20, -53, 69 }, 0, { 250, -194 }, { 144, 37, 46, 255}}},
	{{{ 34, -56, 120 }, 0, { -62, 330 }, { 169, 4, 92, 255}}},
};

Vtx VB_spindrift_geo_0x5002a98[] = {
	{{{ 0, -33, -69 }, 0, { 514, 1102 }, { 160, 64, 205, 255}}},
	{{{ 13, -2, 0 }, 0, { 1070, 398 }, { 156, 76, 241, 255}}},
	{{{ 53, 33, -86 }, 0, { 138, -146 }, { 160, 64, 205, 255}}},
	{{{ 62, -15, -122 }, 0, { -146, 482 }, { 172, 46, 174, 255}}},
};

Vtx VB_spindrift_geo_0x5002ba8[] = {
	{{{ 28, -6, 21 }, 0, { 474, 1104 }, { 126, 253, 11, 255}}},
	{{{ 42, -20, -134 }, 0, { -192, 0 }, { 126, 253, 11, 255}}},
	{{{ 42, 98, -96 }, 0, { 1152, 0 }, { 126, 253, 11, 255}}},
	{{{ 28, -21, 0 }, 0, { 474, 1104 }, { 126, 244, 0, 255}}},
	{{{ 42, 122, -61 }, 0, { -192, 0 }, { 126, 244, 0, 255}}},
	{{{ 42, 122, 63 }, 0, { 1152, 0 }, { 126, 244, 0, 255}}},
	{{{ 28, -6, -20 }, 0, { 474, 1104 }, { 126, 253, 245, 255}}},
	{{{ 42, 97, 97 }, 0, { -192, 0 }, { 126, 253, 245, 255}}},
	{{{ 42, -21, 135 }, 0, { 1152, 0 }, { 126, 253, 245, 255}}},
	{{{ 28, 18, -12 }, 0, { 474, 1104 }, { 126, 9, 249, 255}}},
	{{{ 42, -61, 122 }, 0, { -192, 0 }, { 126, 9, 249, 255}}},
	{{{ 42, -135, 21 }, 0, { 1152, 0 }, { 126, 9, 249, 255}}},
	{{{ 28, 18, 13 }, 0, { 474, 1104 }, { 126, 10, 7, 255}}},
	{{{ 42, -134, -21 }, 0, { -192, 0 }, { 126, 10, 7, 255}}},
	{{{ 42, -61, -122 }, 0, { 1152, 0 }, { 126, 10, 7, 255}}},
};

Gfx DL_spindrift_geo_0x5002900[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_spindrift_geo_0x50028d0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_spindrift_geo_0x50028d0[] = {
	gsDPSetTextureImage(0, 2, 1, spindrift_geo__texture_050006D0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_spindrift_geo_0x50028a0, 3, 0),
	gsSP1Triangle(0, 1, 2, 0),
	gsSPEndDisplayList(),
};

Light_t Light_spindrift_geo_0x5000098 = {
	{ 0, 63, 0}, 0, { 0, 63, 0}, 0, { 40, 40, 40}, 0
};

Light_t Light_spindrift_geo_0x5000080 = {
	{ 255, 226, 0}, 0, { 255, 226, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_spindrift_geo_0x5000090 = {
	{0, 15, 0}, 0, {0, 15, 0}, 0
};

Ambient_t Light_spindrift_geo_0x5000078 = {
	{63, 56, 0}, 0, {63, 56, 0}, 0
};

Gfx DL_spindrift_geo_0x5000328[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPLight(&Light_spindrift_geo_0x5000098.col, 1),
	gsSPLight(&Light_spindrift_geo_0x5000090.col, 2),
	gsSPVertex(VB_spindrift_geo_0x5000180, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(0, 4, 3, 0, 1, 5, 6, 0),
	gsSP2Triangles(7, 4, 0, 0, 5, 4, 8, 0),
	gsSP2Triangles(5, 1, 3, 0, 4, 5, 3, 0),
	gsSPLight(&Light_spindrift_geo_0x5000080.col, 1),
	gsSPLight(&Light_spindrift_geo_0x5000078.col, 2),
	gsSPVertex(VB_spindrift_geo_0x5000210, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 4, 0),
	gsSP2Triangles(1, 5, 6, 0, 5, 7, 8, 0),
	gsSP1Triangle(8, 7, 3, 0),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Light_t Light_spindrift_geo_0x5002978 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_spindrift_geo_0x5002970 = {
	{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_spindrift_geo_0x5002a20[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_spindrift_geo_0x50029c8),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_spindrift_geo_0x50029c8[] = {
	gsDPSetTextureImage(0, 2, 1, spindrift_geo__texture_050016D0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPLight(&Light_spindrift_geo_0x5002978.col, 1),
	gsSPLight(&Light_spindrift_geo_0x5002970.col, 2),
	gsSPVertex(VB_spindrift_geo_0x5002988, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Light_t Light_spindrift_geo_0x5002a88 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_spindrift_geo_0x5002a80 = {
	{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_spindrift_geo_0x5002b30[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_spindrift_geo_0x5002ad8),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_spindrift_geo_0x5002ad8[] = {
	gsDPSetTextureImage(0, 2, 1, spindrift_geo__texture_050016D0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPLight(&Light_spindrift_geo_0x5002a88.col, 1),
	gsSPLight(&Light_spindrift_geo_0x5002a80.col, 2),
	gsSPVertex(VB_spindrift_geo_0x5002a98, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Light_t Light_spindrift_geo_0x5000050 = {
	{ 221, 255, 1}, 0, { 221, 255, 1}, 0, { 40, 40, 40}, 0
};

Light_t Light_spindrift_geo_0x5000038 = {
	{ 73, 178, 0}, 0, { 73, 178, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_spindrift_geo_0x5000048 = {
	{55, 63, 0}, 0, {55, 63, 0}, 0
};

Ambient_t Light_spindrift_geo_0x5000030 = {
	{18, 44, 0}, 0, {18, 44, 0}, 0
};

Gfx DL_spindrift_geo_0x50002a0[] = {
	gsSPLight(&Light_spindrift_geo_0x5000050.col, 1),
	gsSPLight(&Light_spindrift_geo_0x5000048.col, 2),
	gsSPVertex(VB_spindrift_geo_0x50000c0, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 2, 0),
	gsSP2Triangles(1, 3, 2, 0, 4, 5, 2, 0),
	gsSP1Triangle(5, 0, 2, 0),
	gsSPLight(&Light_spindrift_geo_0x5000038.col, 1),
	gsSPLight(&Light_spindrift_geo_0x5000030.col, 2),
	gsSPVertex(VB_spindrift_geo_0x5000120, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(1, 0, 4, 0, 4, 0, 5, 0),
	gsSP1Triangle(5, 0, 3, 0),
	gsSPEndDisplayList(),
};

Light_t Light_spindrift_geo_0x5002b98 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_spindrift_geo_0x5002b90 = {
	{127, 127, 127}, 0, {127, 127, 127}, 0
};

Gfx DL_spindrift_geo_0x5002d08[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_spindrift_geo_0x5002c98),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_spindrift_geo_0x5002c98[] = {
	gsDPSetTextureImage(0, 2, 1, spindrift_geo__texture_05000ED0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPLight(&Light_spindrift_geo_0x5002b98.col, 1),
	gsSPLight(&Light_spindrift_geo_0x5002b90.col, 2),
	gsSPVertex(VB_spindrift_geo_0x5002ba8, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP1Triangle(12, 13, 14, 0),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx DL_spindrift_geo_0x5002748[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_spindrift_geo_0x5002710),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_spindrift_geo_0x5002710[] = {
	gsDPSetTextureImage(0, 2, 1, spindrift_geo__texture_05001ED0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_spindrift_geo_0x50026d0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Gfx DL_spindrift_geo_0x5002830[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_spindrift_geo_0x50027f8),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_spindrift_geo_0x50027f8[] = {
	gsDPSetTextureImage(0, 2, 1, spindrift_geo__texture_050006D0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_spindrift_geo_0x50027b8, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSPEndDisplayList(),
};

