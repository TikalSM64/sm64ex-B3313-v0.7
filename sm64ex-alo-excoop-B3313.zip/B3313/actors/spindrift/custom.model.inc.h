#ifndef spindrift_spindrift_model_HEADER_H
#define spindrift_spindrift_model_HEADER_H
#include "types.h"
extern Vtx VB_spindrift_geo_0x50000c0[];
extern Vtx VB_spindrift_geo_0x5000120[];
extern Vtx VB_spindrift_geo_0x5000180[];
extern Vtx VB_spindrift_geo_0x5000210[];
extern Vtx VB_spindrift_geo_0x50026d0[];
extern Vtx VB_spindrift_geo_0x50027b8[];
extern Vtx VB_spindrift_geo_0x50028a0[];
extern Vtx VB_spindrift_geo_0x5002988[];
extern Vtx VB_spindrift_geo_0x5002a98[];
extern Vtx VB_spindrift_geo_0x5002ba8[];
extern u8 spindrift_geo__texture_050006D0[];
extern Gfx DL_spindrift_geo_0x5002900[];
extern Gfx DL_spindrift_geo_0x50028d0[];
extern Light_t Light_spindrift_geo_0x5000098;
extern Light_t Light_spindrift_geo_0x5000080;
extern Ambient_t Light_spindrift_geo_0x5000090;
extern Ambient_t Light_spindrift_geo_0x5000078;
extern Gfx DL_spindrift_geo_0x5000328[];
extern u8 spindrift_geo__texture_050016D0[];
extern Light_t Light_spindrift_geo_0x5002978;
extern Ambient_t Light_spindrift_geo_0x5002970;
extern Gfx DL_spindrift_geo_0x5002a20[];
extern Gfx DL_spindrift_geo_0x50029c8[];
extern Light_t Light_spindrift_geo_0x5002a88;
extern Ambient_t Light_spindrift_geo_0x5002a80;
extern Gfx DL_spindrift_geo_0x5002b30[];
extern Gfx DL_spindrift_geo_0x5002ad8[];
extern Light_t Light_spindrift_geo_0x5000050;
extern Light_t Light_spindrift_geo_0x5000038;
extern Ambient_t Light_spindrift_geo_0x5000048;
extern Ambient_t Light_spindrift_geo_0x5000030;
extern Gfx DL_spindrift_geo_0x50002a0[];
extern u8 spindrift_geo__texture_05000ED0[];
extern Light_t Light_spindrift_geo_0x5002b98;
extern Ambient_t Light_spindrift_geo_0x5002b90;
extern Gfx DL_spindrift_geo_0x5002d08[];
extern Gfx DL_spindrift_geo_0x5002c98[];
extern u8 spindrift_geo__texture_05001ED0[];
extern Gfx DL_spindrift_geo_0x5002748[];
extern Gfx DL_spindrift_geo_0x5002710[];
extern Gfx DL_spindrift_geo_0x5002830[];
extern Gfx DL_spindrift_geo_0x50027f8[];
#endif