ALIGNED8 u8 spindrift_geo__texture_050006D0[] = {
#include "actors/spindrift/spindrift_geo_0x50006d0_custom.rgba16.inc.c"
};
ALIGNED8 u8 spindrift_geo__texture_050016D0[] = {
#include "actors/spindrift/spindrift_geo_0x50016d0_custom.rgba16.inc.c"
};
ALIGNED8 u8 spindrift_geo__texture_05000ED0[] = {
#include "actors/spindrift/spindrift_geo_0x5000ed0_custom.rgba16.inc.c"
};
ALIGNED8 u8 spindrift_geo__texture_05001ED0[] = {
#include "actors/spindrift/spindrift_geo_0x5001ed0_custom.rgba16.inc.c"
};
