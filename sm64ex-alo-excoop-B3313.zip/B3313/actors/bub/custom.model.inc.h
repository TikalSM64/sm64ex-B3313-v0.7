#ifndef bub_bub_model_HEADER_H
#define bub_bub_model_HEADER_H
#include "types.h"
extern Vtx VB_bub_geo_0x60112a8[];
extern Vtx VB_bub_geo_0x6011388[];
extern Vtx VB_bub_geo_0x60113b8[];
extern Vtx VB_bub_geo_0x6011418[];
extern Vtx VB_bub_geo_0x6011488[];
extern Vtx VB_bub_geo_0x6011578[];
extern Vtx VB_bub_geo_0x6011658[];
extern Vtx VB_bub_geo_0x6011718[];
extern Vtx VB_bub_geo_0x60117d8[];
extern Vtx VB_bub_geo_0x6011bd8[];
extern Vtx VB_bub_geo_0x6011d50[];
extern Vtx VB_bub_geo_0x6011ea8[];
extern u8 bub_geo__texture_0600E2A8[];
extern u8 bub_geo__texture_0600EAA8[];
extern u8 bub_geo__texture_0600F2A8[];
extern u8 bub_geo__texture_060102A8[];
extern Light_t Light_bub_geo_0x600e280;
extern Light_t Light_bub_geo_0x600e298;
extern Ambient_t Light_bub_geo_0x600e278;
extern Ambient_t Light_bub_geo_0x600e290;
extern Gfx DL_bub_geo_0x6011b28[];
extern Gfx DL_bub_geo_0x6011848[];
extern Gfx DL_bub_geo_0x60118c0[];
extern Gfx DL_bub_geo_0x6011918[];
extern Gfx DL_bub_geo_0x6011968[];
extern Gfx DL_bub_geo_0x6011a50[];
extern Gfx DL_bub_geo_0x6011cf0[];
extern Gfx DL_bub_geo_0x6011c58[];
extern Gfx DL_bub_geo_0x6011e48[];
extern Gfx DL_bub_geo_0x6011dc0[];
extern Gfx DL_bub_geo_0x6011fa0[];
extern Gfx DL_bub_geo_0x6011f18[];
#endif