#ifndef wooden_signpost_wooden_signpost_model_HEADER_H
#define wooden_signpost_wooden_signpost_model_HEADER_H
#include "types.h"
extern Vtx VB_wooden_signpost_geo_0x302c958[];
extern Vtx VB_wooden_signpost_geo_0x302dac0[];
extern Vtx VB_wooden_signpost_geo_0x302dbc0[];
extern Vtx VB_wooden_signpost_geo_0x302dc00[];
extern u8 wooden_signpost_geo__texture_0302C9C8[];
extern Light_t Light_wooden_signpost_geo_0x302c948;
extern Ambient_t Light_wooden_signpost_geo_0x302c940;
extern Gfx DL_wooden_signpost_geo_0x302da48[];
extern Gfx DL_wooden_signpost_geo_0x302d9c8[];
extern u8 wooden_signpost_geo__texture_0302D1C8[];
extern Light_t Light_wooden_signpost_geo_0x302dab0;
extern Ambient_t Light_wooden_signpost_geo_0x302daa8;
extern Gfx DL_wooden_signpost_geo_0x302dd08[];
extern Gfx DL_wooden_signpost_geo_0x302dc40[];
extern Gfx DL_wooden_signpost_geo_0x302dcd0[];
#endif