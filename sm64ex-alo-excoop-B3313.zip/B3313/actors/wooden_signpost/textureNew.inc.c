ALIGNED8 u8 wooden_signpost_geo__texture_0302C9C8[] = {
#include "actors/wooden_signpost/wooden_signpost_geo_0x302c9c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 wooden_signpost_geo__texture_0302D1C8[] = {
#include "actors/wooden_signpost/wooden_signpost_geo_0x302d1c8_custom.rgba16.inc.c"
};
