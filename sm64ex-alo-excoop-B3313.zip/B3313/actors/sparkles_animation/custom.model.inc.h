#ifndef sparkles_animation_sparkles_animation_model_HEADER_H
#define sparkles_animation_sparkles_animation_model_HEADER_H
#include "types.h"
extern Vtx VB_sparkles_animation_geo_0x4032a48[];
extern u8 sparkles_animation_geo__texture_04032A88[];
extern Gfx DL_sparkles_animation_geo_0x4035300[];
extern Gfx DL_sparkles_animation_geo_0x4035288[];
extern u8 sparkles_animation_geo__texture_04033288[];
extern Gfx DL_sparkles_animation_geo_0x4035318[];
extern u8 sparkles_animation_geo__texture_04033A88[];
extern Gfx DL_sparkles_animation_geo_0x4035330[];
extern u8 sparkles_animation_geo__texture_04034288[];
extern Gfx DL_sparkles_animation_geo_0x4035348[];
extern u8 sparkles_animation_geo__texture_04034A88[];
extern Gfx DL_sparkles_animation_geo_0x4035360[];
#endif