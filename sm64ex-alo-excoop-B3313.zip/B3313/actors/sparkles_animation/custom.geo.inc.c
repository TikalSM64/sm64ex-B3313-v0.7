#include "custom.model.inc.h"
const GeoLayout sparkles_animation_geo[]= {
GEO_SWITCH_CASE(9, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_sparkles_animation_geo_0x4035300),
GEO_DISPLAY_LIST(5,DL_sparkles_animation_geo_0x4035318),
GEO_DISPLAY_LIST(5,DL_sparkles_animation_geo_0x4035330),
GEO_DISPLAY_LIST(5,DL_sparkles_animation_geo_0x4035348),
GEO_DISPLAY_LIST(5,DL_sparkles_animation_geo_0x4035360),
GEO_DISPLAY_LIST(5,DL_sparkles_animation_geo_0x4035348),
GEO_DISPLAY_LIST(5,DL_sparkles_animation_geo_0x4035330),
GEO_DISPLAY_LIST(5,DL_sparkles_animation_geo_0x4035318),
GEO_DISPLAY_LIST(5,DL_sparkles_animation_geo_0x4035300),
GEO_CLOSE_NODE(),
GEO_END(),
};
