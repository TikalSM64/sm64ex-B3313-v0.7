ALIGNED8 u8 sparkles_animation_geo__texture_04032A88[] = {
#include "actors/sparkles_animation/sparkles_animation_geo_0x4032a88_custom.ia16.inc.c"
};
ALIGNED8 u8 sparkles_animation_geo__texture_04033288[] = {
#include "actors/sparkles_animation/sparkles_animation_geo_0x4033288_custom.ia16.inc.c"
};
ALIGNED8 u8 sparkles_animation_geo__texture_04033A88[] = {
#include "actors/sparkles_animation/sparkles_animation_geo_0x4033a88_custom.ia16.inc.c"
};
ALIGNED8 u8 sparkles_animation_geo__texture_04034288[] = {
#include "actors/sparkles_animation/sparkles_animation_geo_0x4034288_custom.ia16.inc.c"
};
ALIGNED8 u8 sparkles_animation_geo__texture_04034A88[] = {
#include "actors/sparkles_animation/sparkles_animation_geo_0x4034a88_custom.ia16.inc.c"
};
