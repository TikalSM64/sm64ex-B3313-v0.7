#ifndef bowser_key_bowser_key_model_HEADER_H
#define bowser_key_bowser_key_model_HEADER_H
#include "types.h"
extern Vtx VB_bowser_key_geo_0x30156f8[];
extern Vtx VB_bowser_key_geo_0x30157f8[];
extern Vtx VB_bowser_key_geo_0x30158f8[];
extern Vtx VB_bowser_key_geo_0x30159f8[];
extern Vtx VB_bowser_key_geo_0x3015af8[];
extern Vtx VB_bowser_key_geo_0x3015bf8[];
extern Vtx VB_bowser_key_geo_0x3015cf8[];
extern Vtx VB_bowser_key_geo_0x3015dd8[];
extern Vtx VB_bowser_key_geo_0x3015ed8[];
extern Vtx VB_bowser_key_geo_0x3015fd8[];
extern Vtx VB_bowser_key_geo_0x30160b8[];
extern Vtx VB_bowser_key_geo_0x30161b8[];
extern Light_t Light_bowser_key_cutscene_geo_0x30156e8;
extern Ambient_t Light_bowser_key_cutscene_geo_0x30156e0;
extern Gfx DL_bowser_key_cutscene_geo_0x30161f8[];
#endif