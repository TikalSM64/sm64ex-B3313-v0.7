ALIGNED8 u8 bubble_geo__texture_0401CD60[] = {
#include "actors/bubble/bubble_geo_0x401cd60_custom.rgba16.inc.c"
};
ALIGNED8 u8 purple_marble_geo__texture_0401D560[] = {
#include "actors/bubble/purple_marble_geo_0x401d560_custom.rgba16.inc.c"
};
