#ifndef wdw_express_elevator_model_HEADER_H
#define wdw_express_elevator_model_HEADER_H
#include "types.h"
extern Vtx VB_wdw_geo_000610_0x7013518[];
extern Vtx VB_wdw_geo_000610_0x7013618[];
extern Vtx VB_wdw_geo_000610_0x7013708[];
extern Vtx VB_wdw_geo_000610_0x70137f8[];
extern Vtx VB_wdw_geo_000610_0x70138e8[];
extern u8 wdw_geo_000610__texture_09006800[];
extern u8 wdw_geo_000610__texture_07000800[];
extern Light_t Light_wdw_geo_000610_0x7013508;
extern Ambient_t Light_wdw_geo_000610_0x7013500;
extern Gfx DL_wdw_geo_000610_0x7013b70[];
extern Gfx DL_wdw_geo_000610_0x70139d8[];
extern Gfx DL_wdw_geo_000610_0x7013a50[];
#endif