#include "custom.model.inc.h"
const GeoLayout wdw_geo_000610[]= {
GEO_CULLING_RADIUS(800),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_wdw_geo_000610_0x7013b70),
GEO_CLOSE_NODE(),
GEO_END(),
};
