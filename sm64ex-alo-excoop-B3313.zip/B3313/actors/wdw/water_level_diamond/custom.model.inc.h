#ifndef wdw_water_level_diamond_model_HEADER_H
#define wdw_water_level_diamond_model_HEADER_H
#include "types.h"
extern Vtx VB_wdw_geo_0005C0_0x7012f78[];
extern Vtx VB_wdw_geo_0005C0_0x7012fd8[];
extern Vtx VB_wdw_geo_0005C0_0x7013038[];
extern Vtx VB_wdw_geo_0005C0_0x7013098[];
extern u8 wdw_geo_0005C0__texture_07001000[];
extern Light_t Light_wdw_geo_0005C0_0x7012f20;
extern Light_t Light_wdw_geo_0005C0_0x7012f38;
extern Light_t Light_wdw_geo_0005C0_0x7012f50;
extern Light_t Light_wdw_geo_0005C0_0x7012f68;
extern Ambient_t Light_wdw_geo_0005C0_0x7012f18;
extern Ambient_t Light_wdw_geo_0005C0_0x7012f30;
extern Ambient_t Light_wdw_geo_0005C0_0x7012f48;
extern Ambient_t Light_wdw_geo_0005C0_0x7012f60;
extern Gfx DL_wdw_geo_0005C0_0x70131b8[];
extern Gfx DL_wdw_geo_0005C0_0x70130f8[];
#endif