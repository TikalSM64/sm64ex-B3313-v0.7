#include "custom.model.inc.h"
const GeoLayout wdw_geo_0005C0[]= {
GEO_CULLING_RADIUS(200),
GEO_OPEN_NODE(),
GEO_SHADOW(11,150,90),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_wdw_geo_0005C0_0x70131b8),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
