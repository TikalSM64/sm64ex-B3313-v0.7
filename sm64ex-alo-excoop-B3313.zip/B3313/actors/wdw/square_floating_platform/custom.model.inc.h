#ifndef wdw_square_floating_platform_model_HEADER_H
#define wdw_square_floating_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_wdw_geo_000580_0x7012950[];
extern Vtx VB_wdw_geo_000580_0x7012a50[];
extern u8 wdw_geo_000580__texture_07000800[];
extern u8 wdw_geo_000580__texture_09006800[];
extern Light_t Light_wdw_geo_000580_0x7012940;
extern Ambient_t Light_wdw_geo_000580_0x7012938;
extern Gfx DL_wdw_geo_000580_0x7012b90[];
extern Gfx DL_wdw_geo_000580_0x7012ad0[];
extern Gfx DL_wdw_geo_000580_0x7012b48[];
#endif