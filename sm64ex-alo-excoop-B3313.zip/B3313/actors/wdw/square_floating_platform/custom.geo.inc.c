#include "custom.model.inc.h"
const GeoLayout wdw_geo_000580[]= {
GEO_CULLING_RADIUS(550),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_wdw_geo_000580_0x7012b90),
GEO_CLOSE_NODE(),
GEO_END(),
};
