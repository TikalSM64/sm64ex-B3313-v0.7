#ifndef wdw_arrow_lift_model_HEADER_H
#define wdw_arrow_lift_model_HEADER_H
#include "types.h"
extern Vtx VB_wdw_geo_000598_0x7012c20[];
extern Vtx VB_wdw_geo_000598_0x7012c60[];
extern Vtx VB_wdw_geo_000598_0x7012d50[];
extern u8 wdw_geo_000598__texture_07001800[];
extern u8 wdw_geo_000598__texture_09004000[];
extern Light_t Light_wdw_geo_000598_0x7012c10;
extern Ambient_t Light_wdw_geo_000598_0x7012c08;
extern Gfx DL_wdw_geo_000598_0x7012e88[];
extern Gfx DL_wdw_geo_000598_0x7012dc0[];
extern Gfx DL_wdw_geo_000598_0x7012e08[];
#endif