#include "custom.model.inc.h"
const GeoLayout wdw_geo_000598[]= {
GEO_CULLING_RADIUS(350),
GEO_OPEN_NODE(),
GEO_SHADOW(12,150,110),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_wdw_geo_000598_0x7012e88),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
