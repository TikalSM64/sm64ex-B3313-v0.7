#ifndef wdw_rotating_platform_model_HEADER_H
#define wdw_rotating_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_wdw_geo_000640_0x7013ed0[];
extern Vtx VB_wdw_geo_000640_0x7013fc0[];
extern u8 wdw_geo_000640__texture_09008000[];
extern Light_t Light_wdw_geo_000640_0x7013ec0;
extern Ambient_t Light_wdw_geo_000640_0x7013eb8;
extern Gfx DL_wdw_geo_000640_0x70140e0[];
extern Gfx DL_wdw_geo_000640_0x7014050[];
#endif