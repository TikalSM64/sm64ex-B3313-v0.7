#ifndef wdw_rectangular_floating_platform_model_HEADER_H
#define wdw_rectangular_floating_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_wdw_geo_000628_0x7013c00[];
extern Vtx VB_wdw_geo_000628_0x7013d00[];
extern u8 wdw_geo_000628__texture_07000800[];
extern u8 wdw_geo_000628__texture_09006800[];
extern Light_t Light_wdw_geo_000628_0x7013bf0;
extern Ambient_t Light_wdw_geo_000628_0x7013be8;
extern Gfx DL_wdw_geo_000628_0x7013e40[];
extern Gfx DL_wdw_geo_000628_0x7013d80[];
extern Gfx DL_wdw_geo_000628_0x7013df8[];
#endif