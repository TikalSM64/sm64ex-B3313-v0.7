#include "custom.model.inc.h"
const GeoLayout wdw_geo_000628[]= {
GEO_CULLING_RADIUS(900),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_wdw_geo_000628_0x7013e40),
GEO_CLOSE_NODE(),
GEO_END(),
};
