#include "custom.model.inc.h"
const GeoLayout wdw_geo_0005E8[]= {
GEO_CULLING_RADIUS(420),
GEO_OPEN_NODE(),
GEO_SHADOW(12,150,240),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_wdw_geo_0005E8_0x7013490),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
