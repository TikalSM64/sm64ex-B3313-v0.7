#ifndef wdw_hidden_platform_model_HEADER_H
#define wdw_hidden_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_wdw_geo_0005E8_0x7013250[];
extern Vtx VB_wdw_geo_0005E8_0x7013340[];
extern u8 wdw_geo_0005E8__texture_09006800[];
extern Light_t Light_wdw_geo_0005E8_0x7013240;
extern Ambient_t Light_wdw_geo_0005E8_0x7013238;
extern Gfx DL_wdw_geo_0005E8_0x7013490[];
extern Gfx DL_wdw_geo_0005E8_0x70133f0[];
#endif