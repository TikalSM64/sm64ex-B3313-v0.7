#include "custom.model.inc.h"
const GeoLayout heart_geo[]= {
GEO_SHADOW(1,100,100),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_heart_geo_0x800dfe0),
GEO_CLOSE_NODE(),
GEO_END(),
};
