ALIGNED8 u8 heart_geo__texture_0800D7E0[] = {
#include "actors/heart/heart_geo_0x800d7e0_custom.rgba16.inc.c"
};
