#ifndef heart_heart_model_HEADER_H
#define heart_heart_model_HEADER_H
#include "types.h"
extern Vtx VB_heart_geo_0x800d7a0[];
extern u8 heart_geo__texture_0800D7E0[];
extern Gfx DL_heart_geo_0x800dfe0[];
#endif