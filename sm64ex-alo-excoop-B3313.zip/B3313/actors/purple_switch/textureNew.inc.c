ALIGNED8 u8 purple_switch_geo__texture_0800C0A8[] = {
#include "actors/purple_switch/purple_switch_geo_0x800c0a8_custom.rgba16.inc.c"
};
ALIGNED8 u8 purple_switch_geo__texture_0800C128[] = {
#include "actors/purple_switch/purple_switch_geo_0x800c128_custom.rgba16.inc.c"
};
