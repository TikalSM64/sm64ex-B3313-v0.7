ALIGNED8 const u8 texture_mario_geo_0x4001090_custom[] = {
#include "actors/mario/mario_geo_0x4001090_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4001890_custom[] = {
#include "actors/mario/mario_geo_0x4001890_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4003090_custom[] = {
#include "actors/mario/mario_geo_0x4003090_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4002090_custom[] = {
#include "actors/mario/mario_geo_0x4002090_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4002890_custom[] = {
#include "actors/mario/mario_geo_0x4002890_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4003890_custom[] = {
#include "actors/mario/mario_geo_0x4003890_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4004090_custom[] = {
#include "actors/mario/mario_geo_0x4004090_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4005890_custom[] = {
#include "actors/mario/mario_geo_0x4005890_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4006090_custom[] = {
#include "actors/mario/mario_geo_0x4006090_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4006890_custom[] = {
#include "actors/mario/mario_geo_0x4006890_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4007090_custom[] = {
#include "actors/mario/mario_geo_0x4007090_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4007890_custom[] = {
#include "actors/mario/mario_geo_0x4007890_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4008090_custom[] = {
#include "actors/mario/mario_geo_0x4008090_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4009090_custom[] = {
#include "actors/mario/mario_geo_0x4009090_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x4000090_custom[] = {
#include "actors/mario/mario_geo_0x4000090_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x400a090_custom[] = {
#include "actors/mario/mario_geo_0x400a090_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_mario_geo_0x400b090_custom[] = {
#include "actors/mario/mario_geo_0x400b090_custom.rgba16.inc.c"
};
