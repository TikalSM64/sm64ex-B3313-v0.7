#ifndef breakable_box_small_breakable_box_small_model_HEADER_H
#define breakable_box_small_breakable_box_small_model_HEADER_H
#include "types.h"
extern Vtx VB_breakable_box_small_geo_0x8012a90[];
extern Vtx VB_breakable_box_small_geo_0x8012b80[];
extern u8 breakable_box_small_geo__texture_08011A90[];
extern Light_t Light_breakable_box_small_geo_0x8011a80;
extern Ambient_t Light_breakable_box_small_geo_0x8011a78;
extern Gfx DL_breakable_box_small_geo_0x8012d20[];
extern Gfx DL_breakable_box_small_geo_0x8012cd8[];
extern Gfx DL_breakable_box_small_geo_0x8012c30[];
extern u8 breakable_box_small_geo__texture_08012290[];
extern Gfx DL_breakable_box_small_geo_0x8012d48[];
#endif