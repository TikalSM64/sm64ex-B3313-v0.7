#ifndef snufit_snufit_model_HEADER_H
#define snufit_snufit_model_HEADER_H
#include "types.h"
extern Vtx VB_snufit_geo_0x6008d10[];
extern Vtx VB_snufit_geo_0x6008df0[];
extern Vtx VB_snufit_geo_0x6008eb0[];
extern Vtx VB_snufit_geo_0x6008f90[];
extern Vtx VB_snufit_geo_0x6009070[];
extern Vtx VB_snufit_geo_0x6009170[];
extern Vtx VB_snufit_geo_0x6009548[];
extern Vtx VB_snufit_geo_0x6009608[];
extern Vtx VB_snufit_geo_0x60097e0[];
extern Vtx VB_snufit_geo_0x6009998[];
extern Vtx VB_snufit_geo_0x6009a98[];
extern u8 snufit_geo__texture_060080E0[];
extern u8 snufit_geo__texture_060084E0[];
extern Light_t Light_snufit_geo_0x6009538;
extern Ambient_t Light_snufit_geo_0x6009530;
extern Gfx DL_snufit_geo_0x6009748[];
extern Gfx DL_snufit_geo_0x6009668[];
extern Gfx DL_snufit_geo_0x6009700[];
extern u8 snufit_geo__texture_060078E0[];
extern Light_t Light_snufit_geo_0x6008ce8;
extern Light_t Light_snufit_geo_0x6008d00;
extern Ambient_t Light_snufit_geo_0x6008ce0;
extern Ambient_t Light_snufit_geo_0x6008cf8;
extern Gfx DL_snufit_geo_0x6009498[];
extern Gfx DL_snufit_geo_0x60091e0[];
extern Gfx DL_snufit_geo_0x6009278[];
extern Gfx DL_snufit_geo_0x60092f0[];
extern Light_t Light_snufit_geo_0x60097d0;
extern Ambient_t Light_snufit_geo_0x60097c8;
extern Gfx DL_snufit_geo_0x6009938[];
extern Gfx DL_snufit_geo_0x60098a0[];
extern Light_t Light_snufit_geo_0x6009a88;
extern Ambient_t Light_snufit_geo_0x6009a80;
extern Gfx DL_snufit_geo_0x6009b68[];
extern Gfx DL_snufit_geo_0x6009b18[];
extern u8 snufit_geo__texture_060070E0[];
extern Gfx DL_snufit_geo_0x6009a10[];
extern Gfx DL_snufit_geo_0x60099d8[];
#endif