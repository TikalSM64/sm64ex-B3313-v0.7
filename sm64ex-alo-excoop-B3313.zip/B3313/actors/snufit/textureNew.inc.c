ALIGNED8 u8 snufit_geo__texture_060080E0[] = {
#include "actors/snufit/snufit_geo_0x60080e0_custom.rgba16.inc.c"
};
ALIGNED8 u8 snufit_geo__texture_060084E0[] = {
#include "actors/snufit/snufit_geo_0x60084e0_custom.rgba16.inc.c"
};
ALIGNED8 u8 snufit_geo__texture_060078E0[] = {
#include "actors/snufit/snufit_geo_0x60078e0_custom.rgba16.inc.c"
};
ALIGNED8 u8 snufit_geo__texture_060070E0[] = {
#include "actors/snufit/snufit_geo_0x60070e0_custom.rgba16.inc.c"
};
