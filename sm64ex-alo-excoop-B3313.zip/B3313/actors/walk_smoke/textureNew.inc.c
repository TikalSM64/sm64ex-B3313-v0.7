ALIGNED8 u8 smoke_geo__texture_0401DEA0[] = {
#include "actors/walk_smoke/smoke_geo_0x401dea0_custom.ia16.inc.c"
};
ALIGNED8 u8 smoke_geo__texture_0401E6A0[] = {
#include "actors/walk_smoke/smoke_geo_0x401e6a0_custom.ia16.inc.c"
};
ALIGNED8 u8 smoke_geo__texture_0401EEA0[] = {
#include "actors/walk_smoke/smoke_geo_0x401eea0_custom.ia16.inc.c"
};
ALIGNED8 u8 smoke_geo__texture_0401F6A0[] = {
#include "actors/walk_smoke/smoke_geo_0x401f6a0_custom.ia16.inc.c"
};
ALIGNED8 u8 smoke_geo__texture_0401FEA0[] = {
#include "actors/walk_smoke/smoke_geo_0x401fea0_custom.ia16.inc.c"
};
ALIGNED8 u8 smoke_geo__texture_040206A0[] = {
#include "actors/walk_smoke/smoke_geo_0x40206a0_custom.ia16.inc.c"
};
ALIGNED8 u8 smoke_geo__texture_04020EA0[] = {
#include "actors/walk_smoke/smoke_geo_0x4020ea0_custom.ia16.inc.c"
};
