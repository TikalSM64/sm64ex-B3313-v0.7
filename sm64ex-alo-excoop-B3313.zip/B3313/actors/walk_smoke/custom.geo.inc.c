#include "custom.model.inc.h"
const GeoLayout smoke_geo[]= {
GEO_SWITCH_CASE(7, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_smoke_geo_0x4021718),
GEO_DISPLAY_LIST(5,DL_smoke_geo_0x4021730),
GEO_DISPLAY_LIST(5,DL_smoke_geo_0x4021748),
GEO_DISPLAY_LIST(5,DL_smoke_geo_0x4021760),
GEO_DISPLAY_LIST(5,DL_smoke_geo_0x4021778),
GEO_DISPLAY_LIST(5,DL_smoke_geo_0x4021790),
GEO_DISPLAY_LIST(5,DL_smoke_geo_0x40217a8),
GEO_CLOSE_NODE(),
GEO_END(),
};
