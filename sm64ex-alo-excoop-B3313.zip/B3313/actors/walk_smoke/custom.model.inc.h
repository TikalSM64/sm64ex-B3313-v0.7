#ifndef walk_smoke_walk_smoke_model_HEADER_H
#define walk_smoke_walk_smoke_model_HEADER_H
#include "types.h"
extern Vtx VB_smoke_geo_0x401de60[];
extern u8 smoke_geo__texture_0401DEA0[];
extern Gfx DL_smoke_geo_0x4021718[];
extern Gfx DL_smoke_geo_0x40216a0[];
extern u8 smoke_geo__texture_0401E6A0[];
extern Gfx DL_smoke_geo_0x4021730[];
extern u8 smoke_geo__texture_0401EEA0[];
extern Gfx DL_smoke_geo_0x4021748[];
extern u8 smoke_geo__texture_0401F6A0[];
extern Gfx DL_smoke_geo_0x4021760[];
extern u8 smoke_geo__texture_0401FEA0[];
extern Gfx DL_smoke_geo_0x4021778[];
extern u8 smoke_geo__texture_040206A0[];
extern Gfx DL_smoke_geo_0x4021790[];
extern u8 smoke_geo__texture_04020EA0[];
extern Gfx DL_smoke_geo_0x40217a8[];
#endif