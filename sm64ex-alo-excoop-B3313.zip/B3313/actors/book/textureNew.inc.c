ALIGNED8 u8 bookend_geo__texture_05000C60[] = {
#include "actors/book/bookend_geo_0x5000c60_custom.rgba16.inc.c"
};
ALIGNED8 u8 bookend_geo__texture_05002570[] = {
#include "actors/book/bookend_geo_0x5002570_custom.rgba16.inc.c"
};
