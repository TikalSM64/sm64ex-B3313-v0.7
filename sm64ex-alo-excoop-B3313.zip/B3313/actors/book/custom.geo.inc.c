#include "custom.model.inc.h"
const GeoLayout bookend_geo[]= {
GEO_CULLING_RADIUS(300),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bookend_geo_0x5002fb0),
GEO_CLOSE_NODE(),
GEO_END(),
};
