#ifndef butterfly_butterfly_model_HEADER_H
#define butterfly_butterfly_model_HEADER_H
#include "types.h"
extern Vtx VB_butterfly_geo_0x3004348[];
extern Vtx VB_butterfly_geo_0x30053a8[];
extern u8 butterfly_geo__texture_030043A8[];
extern Gfx DL_butterfly_geo_0x3005408[];
extern Gfx DL_butterfly_geo_0x30054a0[];
#endif