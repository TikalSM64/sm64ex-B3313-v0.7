ALIGNED8 u8 white_puff_geo__texture_03000080[] = {
#include "actors/white_puff/white_puff_geo_0x3000080_custom.ia16.inc.c"
};
