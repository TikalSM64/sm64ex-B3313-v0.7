#ifndef white_puff_white_puff_model_HEADER_H
#define white_puff_white_puff_model_HEADER_H
#include "types.h"
extern Vtx VB_white_puff_geo_0x3000040[];
extern u8 white_puff_geo__texture_03000080[];
extern Gfx DL_white_puff_geo_0x3000920[];
#endif