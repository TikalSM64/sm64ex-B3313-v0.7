#ifndef bully_bully_model_HEADER_H
#define bully_bully_model_HEADER_H
#include "types.h"
extern Vtx VB_bully_boss_geo_0x5000000[];
extern Vtx VB_bully_boss_geo_0x5002c68[];
extern Vtx VB_bully_boss_geo_0x5002d48[];
extern Vtx VB_bully_boss_geo_0x5002d88[];
extern Vtx VB_bully_boss_geo_0x5002e68[];
extern Vtx VB_bully_boss_geo_0x5003c50[];
extern Vtx VB_bully_boss_geo_0x5003c90[];
extern Vtx VB_bully_boss_geo_0x5003db8[];
extern Vtx VB_bully_boss_geo_0x5003df8[];
extern Vtx VB_bully_boss_geo_0x5003f20[];
extern Light_t Light_bully_geo_0x5000410;
extern Ambient_t Light_bully_geo_0x5000408;
extern Gfx DL_bully_geo_0x5003708[];
extern Light_t Light_bully_geo_0x5000428;
extern Ambient_t Light_bully_geo_0x5000420;
extern Gfx DL_bully_geo_0x50037a0[];
extern u8 bully_geo__texture_05000468[];
extern u8 bully_geo__texture_05001468[];
extern Gfx DL_bully_geo_0x5003d40[];
extern Gfx DL_bully_geo_0x5003cd0[];
extern Gfx DL_bully_geo_0x5003d08[];
extern u8 bully_geo__texture_050000E0[];
extern Gfx DL_bully_geo_0x5000398[];
extern Gfx DL_bully_geo_0x50002e0[];
extern u8 bully_geo__texture_05002468[];
extern Gfx DL_bully_geo_0x5003fc8[];
extern Gfx DL_bully_geo_0x5003f80[];
extern Gfx DL_bully_boss_geo_0x5003ea8[];
extern Gfx DL_bully_boss_geo_0x5003e38[];
extern Gfx DL_bully_boss_geo_0x5003e70[];
#endif