ALIGNED8 const u8 texture_marios_winged_metal_cap_geo_0x301cf50_custom[] = {
#include "actors/mario_cap/marios_winged_metal_cap_geo_0x301cf50_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_marios_winged_metal_cap_geo_0x3020750_custom[] = {
#include "actors/mario_cap/marios_winged_metal_cap_geo_0x3020750_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_marios_winged_metal_cap_geo_0x3021750_custom[] = {
#include "actors/mario_cap/marios_winged_metal_cap_geo_0x3021750_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_marios_wing_cap_geo_0x301df50_custom[] = {
#include "actors/mario_cap/marios_wing_cap_geo_0x301df50_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_marios_wing_cap_geo_0x301e750_custom[] = {
#include "actors/mario_cap/marios_wing_cap_geo_0x301e750_custom.rgba16.inc.c"
};
ALIGNED8 const u8 texture_marios_wing_cap_geo_0x301f750_custom[] = {
#include "actors/mario_cap/marios_wing_cap_geo_0x301f750_custom.rgba16.inc.c"
};
