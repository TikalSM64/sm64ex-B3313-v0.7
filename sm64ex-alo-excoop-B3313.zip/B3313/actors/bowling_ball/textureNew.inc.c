ALIGNED8 u8 bowling_ball_geo__texture_0801DA60[] = {
#include "actors/bowling_ball/bowling_ball_geo_0x801da60_custom.rgba16.inc.c"
};
ALIGNED8 u8 bowling_ball_geo__texture_0801EA60[] = {
#include "actors/bowling_ball/bowling_ball_geo_0x801ea60_custom.rgba16.inc.c"
};
