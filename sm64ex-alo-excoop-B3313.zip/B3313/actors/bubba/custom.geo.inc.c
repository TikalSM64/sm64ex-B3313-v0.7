#include "custom.model.inc.h"
const GeoLayout bubba_geo[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_SWITCH_CASE(2, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_bubba_geo_0x5004e80),
GEO_DISPLAY_LIST(1,DL_bubba_geo_0x5005978),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
