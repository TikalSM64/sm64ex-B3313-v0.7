ALIGNED8 u8 bubba_geo__texture_05000008[] = {
#include "actors/bubba/bubba_geo_0x5000008_custom.rgba16.inc.c"
};
ALIGNED8 u8 bubba_geo__texture_05001408[] = {
#include "actors/bubba/bubba_geo_0x5001408_custom.rgba16.inc.c"
};
ALIGNED8 u8 bubba_geo__texture_05001C08[] = {
#include "actors/bubba/bubba_geo_0x5001c08_custom.rgba16.inc.c"
};
ALIGNED8 u8 bubba_geo__texture_05002408[] = {
#include "actors/bubba/bubba_geo_0x5002408_custom.rgba16.inc.c"
};
