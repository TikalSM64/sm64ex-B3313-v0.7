ALIGNED8 u8 bubbly_tree_geo__texture_0302DE28[] = {
#include "actors/tree/bubbly_tree_geo_0x302de28_custom.rgba16.inc.c"
};
ALIGNED8 u8 bubbly_tree_geo__texture_0302EE28[] = {
#include "actors/tree/bubbly_tree_geo_0x302ee28_custom.rgba16.inc.c"
};
ALIGNED8 u8 spiky_tree_geo__texture_0302FF60[] = {
#include "actors/tree/spiky_tree_geo_0x302ff60_custom.rgba16.inc.c"
};
ALIGNED8 u8 snow_tree_geo__texture_03031048[] = {
#include "actors/tree/snow_tree_geo_0x3031048_custom.rgba16.inc.c"
};
ALIGNED8 u8 palm_tree_geo__texture_03032218[] = {
#include "actors/tree/palm_tree_geo_0x3032218_custom.rgba16.inc.c"
};
