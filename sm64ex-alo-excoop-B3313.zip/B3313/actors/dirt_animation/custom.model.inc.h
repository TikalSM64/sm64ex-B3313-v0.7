#ifndef dirt_animation_dirt_animation_model_HEADER_H
#define dirt_animation_dirt_animation_model_HEADER_H
#include "types.h"
extern Vtx VB_dirt_animation_geo_0x302bdc8[];
extern Vtx VB_dirt_animation_geo_0x302c098[];
extern Vtx VB_dirt_animation_geo_0x302c0c8[];
extern Light_t Light_dirt_animation_geo_0x302bd70;
extern Ambient_t Light_dirt_animation_geo_0x302bd68;
extern Gfx DL_dirt_animation_geo_0x302c378[];
extern Light_t Light_dirt_animation_geo_0x302bd88;
extern Ambient_t Light_dirt_animation_geo_0x302bd80;
extern Gfx DL_dirt_animation_geo_0x302c3b0[];
extern Light_t Light_dirt_animation_geo_0x302bda0;
extern Ambient_t Light_dirt_animation_geo_0x302bd98;
extern Gfx DL_dirt_animation_geo_0x302c3e8[];
extern u8 dirt_animation_geo__texture_0302BDF8[];
extern Gfx DL_dirt_animation_geo_0x302c028[];
extern Gfx DL_dirt_animation_geo_0x302bff8[];
extern Light_t Light_dirt_animation_geo_0x302bdb8;
extern Ambient_t Light_dirt_animation_geo_0x302bdb0;
extern Gfx DL_dirt_animation_geo_0x302c420[];
extern Gfx DL_dirt_animation_geo_0x302c458[];
#endif