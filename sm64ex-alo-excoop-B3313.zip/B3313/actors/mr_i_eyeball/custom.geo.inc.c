#include "custom.model.inc.h"
const GeoLayout mr_i_geo[]= {
GEO_SHADOW(1,155,200),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_mr_i_geo_0x6002080),
GEO_CLOSE_NODE(),
GEO_END(),
};
