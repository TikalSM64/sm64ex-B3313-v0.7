ALIGNED8 u8 star_geo__texture_00408800[] = {
#include "actors/star/star_geo_0x408800_custom.rgba16.inc.c"
};
ALIGNED8 u8 star_geo__texture_00409000[] = {
#include "actors/star/star_geo_0x409000_custom.rgba16.inc.c"
};
ALIGNED8 u8 star_geo__texture_00409800[] = {
#include "actors/star/star_geo_0x409800_custom.rgba16.inc.c"
};
ALIGNED8 u8 star_geo__texture_0040A800[] = {
#include "actors/star/star_geo_0x40a800_custom.rgba16.inc.c"
};
ALIGNED8 u8 star_geo__texture_0040B000[] = {
#include "actors/star/star_geo_0x40b000_custom.rgba16.inc.c"
};
ALIGNED8 u8 star_geo__texture_0040B800[] = {
#include "actors/star/star_geo_0x40b800_custom.rgba16.inc.c"
};
ALIGNED8 u8 star_geo__texture_0040C000[] = {
#include "actors/star/star_geo_0x40c000_custom.rgba16.inc.c"
};
