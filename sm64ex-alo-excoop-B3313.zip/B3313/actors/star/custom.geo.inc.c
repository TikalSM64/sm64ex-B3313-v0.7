#include "custom.model.inc.h"
const GeoLayout star_geo[]= {
GEO_BRANCH(0,Geo_star_geo_0x1208000),
};
#include "custom.model.inc.h"
const GeoLayout Geo_star_geo_0x1208000[]= {
GEO_SHADOW(1,180,80),
GEO_OPEN_NODE(),
GEO_SWITCH_CASE(16, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407e00),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407e00),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407e28),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407e28),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407e50),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407e50),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407e28),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407e28),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407f00),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407f00),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407f28),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407f28),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407f50),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407f50),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407f78),
GEO_DISPLAY_LIST(4,DL_star_geo_0x407f78),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
