#include "custom.model.inc.h"
Vtx VB_star_geo_0x407c80[] = {
	{{{ -86, 0, 0 }, 0, { 0, 960 }, { 255, 255, 255, 255}}},
	{{{ 70, 0, 0 }, 0, { 960, 960 }, { 255, 255, 255, 255}}},
	{{{ 70, 140, 0 }, 0, { 960, 0 }, { 255, 255, 255, 255}}},
	{{{ -86, 140, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Gfx DL_star_geo_0x407e00[] = {
	gsDPPipeSync(),
	gsDPSetTextureImage(0, 2, 1, star_geo__texture_00408800),
	gsSPDisplayList(DL_star_geo_0x407d00),
	gsSPVertex(VB_star_geo_0x407c80, 4, 0),
	gsSPBranchList(DL_star_geo_0x30077d0),
};

Gfx DL_star_geo_0x407d00[] = {
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, SHADE, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 2, 5, 0, 2, 5, 0),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPPipeSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx DL_star_geo_0x30077d0[] = {
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPTexture(1, 1, 0, 0, 0),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_star_geo_0x407e28[] = {
	gsDPPipeSync(),
	gsDPSetTextureImage(0, 2, 1, star_geo__texture_00409000),
	gsSPDisplayList(DL_star_geo_0x407d00),
	gsSPVertex(VB_star_geo_0x407c80, 4, 0),
	gsSPBranchList(DL_star_geo_0x30077d0),
};

Gfx DL_star_geo_0x407e50[] = {
	gsDPPipeSync(),
	gsDPSetTextureImage(0, 2, 1, star_geo__texture_00409800),
	gsSPDisplayList(DL_star_geo_0x407d00),
	gsSPVertex(VB_star_geo_0x407c80, 4, 0),
	gsSPBranchList(DL_star_geo_0x30077d0),
};

Gfx DL_star_geo_0x407f00[] = {
	gsDPPipeSync(),
	gsDPSetTextureImage(0, 2, 1, star_geo__texture_0040A800),
	gsSPDisplayList(DL_star_geo_0x407d00),
	gsSPVertex(VB_star_geo_0x407c80, 4, 0),
	gsSPBranchList(DL_star_geo_0x30077d0),
};

Gfx DL_star_geo_0x407f28[] = {
	gsDPPipeSync(),
	gsDPSetTextureImage(0, 2, 1, star_geo__texture_0040B000),
	gsSPDisplayList(DL_star_geo_0x407d00),
	gsSPVertex(VB_star_geo_0x407c80, 4, 0),
	gsSPBranchList(DL_star_geo_0x30077d0),
};

Gfx DL_star_geo_0x407f50[] = {
	gsDPPipeSync(),
	gsDPSetTextureImage(0, 2, 1, star_geo__texture_0040B800),
	gsSPDisplayList(DL_star_geo_0x407d00),
	gsSPVertex(VB_star_geo_0x407c80, 4, 0),
	gsSPBranchList(DL_star_geo_0x30077d0),
};

Gfx DL_star_geo_0x407f78[] = {
	gsDPPipeSync(),
	gsDPSetTextureImage(0, 2, 1, star_geo__texture_0040C000),
	gsSPDisplayList(DL_star_geo_0x407d00),
	gsSPVertex(VB_star_geo_0x407c80, 4, 0),
	gsSPBranchList(DL_star_geo_0x30077d0),
};

