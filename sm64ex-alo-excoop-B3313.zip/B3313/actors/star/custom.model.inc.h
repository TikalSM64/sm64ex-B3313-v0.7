#ifndef star_star_model_HEADER_H
#define star_star_model_HEADER_H
#include "types.h"
extern Vtx VB_star_geo_0x407c80[];
extern u8 star_geo__texture_00408800[];
extern Gfx DL_star_geo_0x407e00[];
extern Gfx DL_star_geo_0x407d00[];
extern Gfx DL_star_geo_0x30077d0[];
extern u8 star_geo__texture_00409000[];
extern Gfx DL_star_geo_0x407e28[];
extern u8 star_geo__texture_00409800[];
extern Gfx DL_star_geo_0x407e50[];
extern u8 star_geo__texture_0040A800[];
extern Gfx DL_star_geo_0x407f00[];
extern u8 star_geo__texture_0040B000[];
extern Gfx DL_star_geo_0x407f28[];
extern u8 star_geo__texture_0040B800[];
extern Gfx DL_star_geo_0x407f50[];
extern u8 star_geo__texture_0040C000[];
extern Gfx DL_star_geo_0x407f78[];
#endif