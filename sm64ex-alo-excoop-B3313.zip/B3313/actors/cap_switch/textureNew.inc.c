ALIGNED8 u8 cap_switch_geo__texture_05001C48[] = {
#include "actors/cap_switch/cap_switch_geo_0x5001c48_custom.ia16.inc.c"
};
