#ifndef cap_switch_cap_switch_model_HEADER_H
#define cap_switch_cap_switch_model_HEADER_H
#include "types.h"
extern Vtx VB_cap_switch_geo_0x5002cc8[];
extern Vtx VB_cap_switch_geo_0x5003180[];
extern u8 cap_switch_geo__texture_05001C48[];
extern Light_t Light_cap_switch_geo_0x5001bc0;
extern Ambient_t Light_cap_switch_geo_0x5001bb8;
extern Gfx DL_cap_switch_geo_0x5002e00[];
extern Gfx DL_cap_switch_geo_0x5002d88[];
extern Light_t Light_cap_switch_geo_0x5001bf0;
extern Ambient_t Light_cap_switch_geo_0x5001be8;
extern Gfx DL_cap_switch_geo_0x5003350[];
extern Gfx DL_cap_switch_geo_0x5003280[];
extern Light_t Light_cap_switch_geo_0x5001c08;
extern Ambient_t Light_cap_switch_geo_0x5001c00;
extern Gfx DL_cap_switch_geo_0x5003370[];
extern Light_t Light_cap_switch_geo_0x5001c20;
extern Ambient_t Light_cap_switch_geo_0x5001c18;
extern Gfx DL_cap_switch_geo_0x5003390[];
extern Light_t Light_cap_switch_geo_0x5001c38;
extern Ambient_t Light_cap_switch_geo_0x5001c30;
extern Gfx DL_cap_switch_geo_0x50033b0[];
#endif