#ifndef spiny_egg_spiny_egg_model_HEADER_H
#define spiny_egg_spiny_egg_model_HEADER_H
#include "types.h"
extern Vtx VB_spiny_ball_geo_0x5014528[];
extern Vtx VB_spiny_ball_geo_0x50145b8[];
extern Vtx VB_spiny_ball_geo_0x5014648[];
extern Vtx VB_spiny_ball_geo_0x50146d8[];
extern Vtx VB_spiny_ball_geo_0x5014768[];
extern Vtx VB_spiny_ball_geo_0x50147f8[];
extern Vtx VB_spiny_ball_geo_0x5014888[];
extern Vtx VB_spiny_ball_geo_0x5014918[];
extern Vtx VB_spiny_ball_geo_0x50149a8[];
extern Vtx VB_spiny_ball_geo_0x5014aa8[];
extern Vtx VB_spiny_ball_geo_0x5014ba8[];
extern Vtx VB_spiny_ball_geo_0x5014ca8[];
extern Vtx VB_spiny_ball_geo_0x5014da8[];
extern Vtx VB_spiny_ball_geo_0x5014ea8[];
extern Vtx VB_spiny_ball_geo_0x5014fa8[];
extern Vtx VB_spiny_ball_geo_0x50150a8[];
extern Light_t Light_spiny_ball_geo_0x5014518;
extern Ambient_t Light_spiny_ball_geo_0x5014510;
extern Gfx DL_spiny_ball_geo_0x5015368[];
extern Light_t Light_spiny_ball_geo_0x5014500;
extern Ambient_t Light_spiny_ball_geo_0x50144f8;
extern Gfx DL_spiny_ball_geo_0x5015330[];
extern Gfx DL_spiny_ball_geo_0x50152f8[];
extern Gfx DL_spiny_ball_geo_0x50152c0[];
extern Gfx DL_spiny_ball_geo_0x5015288[];
extern Gfx DL_spiny_ball_geo_0x5015250[];
extern Gfx DL_spiny_ball_geo_0x5015218[];
extern Gfx DL_spiny_ball_geo_0x50151e0[];
extern Gfx DL_spiny_ball_geo_0x50151a8[];
#endif