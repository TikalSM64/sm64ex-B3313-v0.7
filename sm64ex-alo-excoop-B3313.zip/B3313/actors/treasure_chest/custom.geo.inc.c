#include "custom.model.inc.h"
const GeoLayout treasure_chest_base_geo[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_treasure_chest_base_geo_0x6016f90),
GEO_CLOSE_NODE(),
GEO_END(),
};
#include "custom.model.inc.h"
const GeoLayout treasure_chest_lid_geo[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_treasure_chest_lid_geo_0x60178c0),
GEO_CLOSE_NODE(),
GEO_END(),
};
