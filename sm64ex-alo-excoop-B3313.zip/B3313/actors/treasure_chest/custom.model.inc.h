#ifndef treasure_chest_treasure_chest_model_HEADER_H
#define treasure_chest_treasure_chest_model_HEADER_H
#include "types.h"
extern Vtx VB_treasure_chest_lid_geo_0x60167a8[];
extern Vtx VB_treasure_chest_lid_geo_0x60167e8[];
extern Vtx VB_treasure_chest_lid_geo_0x60168e8[];
extern Vtx VB_treasure_chest_lid_geo_0x6016918[];
extern Vtx VB_treasure_chest_lid_geo_0x6016a08[];
extern Vtx VB_treasure_chest_lid_geo_0x6016af8[];
extern Vtx VB_treasure_chest_lid_geo_0x6016b78[];
extern Vtx VB_treasure_chest_lid_geo_0x6016c78[];
extern Vtx VB_treasure_chest_lid_geo_0x6017030[];
extern Vtx VB_treasure_chest_lid_geo_0x6017110[];
extern Vtx VB_treasure_chest_lid_geo_0x6017200[];
extern Vtx VB_treasure_chest_lid_geo_0x60172f0[];
extern Vtx VB_treasure_chest_lid_geo_0x6017330[];
extern Vtx VB_treasure_chest_lid_geo_0x6017420[];
extern Vtx VB_treasure_chest_lid_geo_0x6017490[];
extern Vtx VB_treasure_chest_lid_geo_0x6017590[];
extern u8 treasure_chest_base_geo__texture_06013FA8[];
extern u8 treasure_chest_base_geo__texture_06014FA8[];
extern u8 treasure_chest_base_geo__texture_060147A8[];
extern u8 treasure_chest_base_geo__texture_060157A8[];
extern Light_t Light_treasure_chest_base_geo_0x6013f98;
extern Ambient_t Light_treasure_chest_base_geo_0x6013f90;
extern Gfx DL_treasure_chest_base_geo_0x6016f90[];
extern Gfx DL_treasure_chest_base_geo_0x6016d58[];
extern Gfx DL_treasure_chest_base_geo_0x6016da0[];
extern Gfx DL_treasure_chest_base_geo_0x6016e18[];
extern Gfx DL_treasure_chest_base_geo_0x6016ee0[];
extern Gfx DL_treasure_chest_lid_geo_0x60178c0[];
extern Gfx DL_treasure_chest_lid_geo_0x6017680[];
extern Gfx DL_treasure_chest_lid_geo_0x6017790[];
extern Gfx DL_treasure_chest_lid_geo_0x6017810[];
#endif