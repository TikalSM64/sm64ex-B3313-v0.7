ALIGNED8 u8 treasure_chest_base_geo__texture_06013FA8[] = {
#include "actors/treasure_chest/treasure_chest_base_geo_0x6013fa8_custom.rgba16.inc.c"
};
ALIGNED8 u8 treasure_chest_base_geo__texture_06014FA8[] = {
#include "actors/treasure_chest/treasure_chest_base_geo_0x6014fa8_custom.rgba16.inc.c"
};
ALIGNED8 u8 treasure_chest_base_geo__texture_060147A8[] = {
#include "actors/treasure_chest/treasure_chest_base_geo_0x60147a8_custom.rgba16.inc.c"
};
ALIGNED8 u8 treasure_chest_base_geo__texture_060157A8[] = {
#include "actors/treasure_chest/treasure_chest_base_geo_0x60157a8_custom.rgba16.inc.c"
};
