#include "custom.model.inc.h"
const GeoLayout haunted_cage_geo[]= {
GEO_CULLING_RADIUS(300),
GEO_OPEN_NODE(),
GEO_SHADOW(0,150,100),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_haunted_cage_geo_0x500f7d8),
GEO_DISPLAY_LIST(1,DL_haunted_cage_geo_0x500fc28),
GEO_DISPLAY_LIST(4,DL_haunted_cage_geo_0x5010100),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
