ALIGNED8 u8 haunted_cage_geo__texture_0500D288[] = {
#include "actors/haunted_cage/haunted_cage_geo_0x500d288_custom.rgba16.inc.c"
};
ALIGNED8 u8 haunted_cage_geo__texture_0500CA88[] = {
#include "actors/haunted_cage/haunted_cage_geo_0x500ca88_custom.rgba16.inc.c"
};
ALIGNED8 u8 haunted_cage_geo__texture_0500C288[] = {
#include "actors/haunted_cage/haunted_cage_geo_0x500c288_custom.rgba16.inc.c"
};
ALIGNED8 u8 haunted_cage_geo__texture_0500D688[] = {
#include "actors/haunted_cage/haunted_cage_geo_0x500d688_custom.rgba16.inc.c"
};
ALIGNED8 u8 haunted_cage_geo__texture_0500DA88[] = {
#include "actors/haunted_cage/haunted_cage_geo_0x500da88_custom.rgba16.inc.c"
};
