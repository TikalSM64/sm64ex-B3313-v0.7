ALIGNED8 u8 koopa_shell_geo__texture_08027CA0[] = {
#include "actors/koopa_shell/koopa_shell_geo_0x8027ca0_custom.rgba16.inc.c"
};
ALIGNED8 u8 koopa_shell_geo__texture_080274A0[] = {
#include "actors/koopa_shell/koopa_shell_geo_0x80274a0_custom.rgba16.inc.c"
};
