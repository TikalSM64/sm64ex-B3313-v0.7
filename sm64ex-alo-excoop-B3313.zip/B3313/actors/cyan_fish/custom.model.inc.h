#ifndef cyan_fish_cyan_fish_model_HEADER_H
#define cyan_fish_cyan_fish_model_HEADER_H
#include "types.h"
extern Vtx VB_cyan_fish_geo_0x600dc80[];
extern Vtx VB_cyan_fish_geo_0x600de50[];
extern Vtx VB_cyan_fish_geo_0x600df60[];
extern u8 cyan_fish_geo__texture_0600D468[];
extern Light_t Light_cyan_fish_geo_0x600dc70;
extern Ambient_t Light_cyan_fish_geo_0x600dc68;
extern Gfx DL_cyan_fish_geo_0x600ddd8[];
extern Gfx DL_cyan_fish_geo_0x600dd20[];
extern Light_t Light_cyan_fish_geo_0x600df50;
extern Ambient_t Light_cyan_fish_geo_0x600df48;
extern Gfx DL_cyan_fish_geo_0x600e038[];
extern Gfx DL_cyan_fish_geo_0x600dfc0[];
extern Light_t Light_cyan_fish_geo_0x600de40;
extern Ambient_t Light_cyan_fish_geo_0x600de38;
extern Gfx DL_cyan_fish_geo_0x600ded8[];
extern Gfx DL_cyan_fish_geo_0x600de90[];
#endif