#ifndef goomba_goomba_model_HEADER_H
#define goomba_goomba_model_HEADER_H
#include "types.h"
extern Vtx VB_goomba_geo_0x801ad48[];
extern Vtx VB_goomba_geo_0x801ae38[];
extern Vtx VB_goomba_geo_0x801af38[];
extern Vtx VB_goomba_geo_0x801b038[];
extern Vtx VB_goomba_geo_0x801b138[];
extern Vtx VB_goomba_geo_0x801b238[];
extern Vtx VB_goomba_geo_0x801b618[];
extern Vtx VB_goomba_geo_0x801b700[];
extern Vtx VB_goomba_geo_0x801b800[];
extern Vtx VB_goomba_geo_0x801b8f0[];
extern Vtx VB_goomba_geo_0x801b9d0[];
extern Vtx VB_goomba_geo_0x801ba50[];
extern Vtx VB_goomba_geo_0x801bb40[];
extern Vtx VB_goomba_geo_0x801bc40[];
extern Vtx VB_goomba_geo_0x801bd40[];
extern Gfx DL_goomba_geo_0x801d760[];
extern u8 goomba_geo__texture_08019530[];
extern Gfx DL_goomba_geo_0x801b690[];
extern Gfx DL_goomba_geo_0x801b658[];
extern u8 goomba_geo__texture_08019D30[];
extern Light_t Light_goomba_geo_0x801ad38;
extern Ambient_t Light_goomba_geo_0x801ad30;
extern Gfx DL_goomba_geo_0x801b5c8[];
extern Gfx DL_goomba_geo_0x801b560[];
extern Gfx DL_goomba_geo_0x801b5a0[];
extern Gfx DL_goomba_geo_0x801b2e8[];
extern u8 goomba_geo__texture_0801A530[];
extern Gfx DL_goomba_geo_0x801b5f0[];
extern Light_t Light_goomba_geo_0x80194d8;
extern Ambient_t Light_goomba_geo_0x80194d0;
extern Gfx DL_goomba_geo_0x801ce20[];
extern Light_t Light_goomba_geo_0x80194f0;
extern Ambient_t Light_goomba_geo_0x80194e8;
extern Gfx DL_goomba_geo_0x801cf78[];
#endif