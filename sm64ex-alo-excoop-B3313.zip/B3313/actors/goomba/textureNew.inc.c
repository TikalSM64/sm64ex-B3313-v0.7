ALIGNED8 u8 goomba_geo__texture_08019530[] = {
#include "actors/goomba/goomba_geo_0x8019530_custom.rgba16.inc.c"
};
ALIGNED8 u8 goomba_geo__texture_08019D30[] = {
#include "actors/goomba/goomba_geo_0x8019d30_custom.rgba16.inc.c"
};
ALIGNED8 u8 goomba_geo__texture_0801A530[] = {
#include "actors/goomba/goomba_geo_0x801a530_custom.rgba16.inc.c"
};
