#ifndef lakitu_enemy_lakitu_enemy_model_HEADER_H
#define lakitu_enemy_lakitu_enemy_model_HEADER_H
#include "types.h"
extern Vtx VB_enemy_lakitu_geo_0x5012510[];
extern Vtx VB_enemy_lakitu_geo_0x5012610[];
extern Vtx VB_enemy_lakitu_geo_0x50126b0[];
extern Vtx VB_enemy_lakitu_geo_0x5012990[];
extern Vtx VB_enemy_lakitu_geo_0x5012a90[];
extern Vtx VB_enemy_lakitu_geo_0x5012b80[];
extern Vtx VB_enemy_lakitu_geo_0x5012c80[];
extern Vtx VB_enemy_lakitu_geo_0x5012d70[];
extern Vtx VB_enemy_lakitu_geo_0x5012e70[];
extern Vtx VB_enemy_lakitu_geo_0x50131d8[];
extern Vtx VB_enemy_lakitu_geo_0x50133b8[];
extern Vtx VB_enemy_lakitu_geo_0x50135b0[];
extern Gfx DL_enemy_lakitu_geo_0x50138b0[];
extern u8 enemy_lakitu_geo__texture_050114E0[];
extern Light_t Light_enemy_lakitu_geo_0x50124e8;
extern Light_t Light_enemy_lakitu_geo_0x5012500;
extern Ambient_t Light_enemy_lakitu_geo_0x50124e0;
extern Ambient_t Light_enemy_lakitu_geo_0x50124f8;
extern Gfx DL_enemy_lakitu_geo_0x5012910[];
extern Gfx DL_enemy_lakitu_geo_0x5012760[];
extern Gfx DL_enemy_lakitu_geo_0x5012890[];
extern u8 enemy_lakitu_geo__texture_05011CE0[];
extern Light_t Light_enemy_lakitu_geo_0x5012980;
extern Ambient_t Light_enemy_lakitu_geo_0x5012978;
extern Gfx DL_enemy_lakitu_geo_0x5013160[];
extern Gfx DL_enemy_lakitu_geo_0x5012ef0[];
extern u8 enemy_lakitu_geo__texture_0500F4E0[];
extern Light_t Light_enemy_lakitu_geo_0x50131c8;
extern Ambient_t Light_enemy_lakitu_geo_0x50131c0;
extern Gfx DL_enemy_lakitu_geo_0x5013350[];
extern Gfx DL_enemy_lakitu_geo_0x50132d8[];
extern Gfx DL_enemy_lakitu_geo_0x5013320[];
extern Gfx DL_enemy_lakitu_geo_0x5013298[];
extern u8 enemy_lakitu_geo__texture_050104E0[];
extern Gfx DL_enemy_lakitu_geo_0x5013378[];
extern Light_t Light_enemy_lakitu_geo_0x50135a0;
extern Ambient_t Light_enemy_lakitu_geo_0x5013598;
extern Gfx DL_enemy_lakitu_geo_0x50136a0[];
extern Light_t Light_enemy_lakitu_geo_0x50133a8;
extern Ambient_t Light_enemy_lakitu_geo_0x50133a0;
extern Gfx DL_enemy_lakitu_geo_0x50134a8[];
#endif