#include "custom.model.inc.h"
const GeoLayout mushroom_1up_geo[]= {
GEO_SHADOW(1,180,80),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_mushroom_1up_geo_0x302a660),
GEO_CLOSE_NODE(),
GEO_END(),
};
