#ifndef mushroom_1up_mushroom_1up_model_HEADER_H
#define mushroom_1up_mushroom_1up_model_HEADER_H
#include "types.h"
extern Vtx VB_mushroom_1up_geo_0x30295e8[];
extern u8 mushroom_1up_geo__texture_03029628[];
extern Gfx DL_mushroom_1up_geo_0x302a660[];
extern Gfx DL_mushroom_1up_geo_0x302a628[];
#endif