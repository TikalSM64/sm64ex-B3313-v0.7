#ifndef flyguy_flyguy_model_HEADER_H
#define flyguy_flyguy_model_HEADER_H
#include "types.h"
extern Vtx VB_flyguy_geo_0x8010130[];
extern Vtx VB_flyguy_geo_0x8010230[];
extern Vtx VB_flyguy_geo_0x8010330[];
extern Vtx VB_flyguy_geo_0x8010430[];
extern Vtx VB_flyguy_geo_0x8010460[];
extern Vtx VB_flyguy_geo_0x8010560[];
extern Vtx VB_flyguy_geo_0x8010640[];
extern Vtx VB_flyguy_geo_0x8010740[];
extern Vtx VB_flyguy_geo_0x8010af8[];
extern Vtx VB_flyguy_geo_0x8010c38[];
extern Vtx VB_flyguy_geo_0x8010cc8[];
extern Vtx VB_flyguy_geo_0x8010d28[];
extern Vtx VB_flyguy_geo_0x8010e08[];
extern Vtx VB_flyguy_geo_0x8010f08[];
extern Vtx VB_flyguy_geo_0x8011008[];
extern Vtx VB_flyguy_geo_0x80110f8[];
extern Vtx VB_flyguy_geo_0x80111f8[];
extern Vtx VB_flyguy_geo_0x80112d8[];
extern Vtx VB_flyguy_geo_0x8011348[];
extern u8 flyguy_geo__texture_0800F088[];
extern u8 flyguy_geo__texture_0800E088[];
extern Light_t Light_flyguy_geo_0x8010bf8;
extern Light_t Light_flyguy_geo_0x8010c10;
extern Light_t Light_flyguy_geo_0x8010c28;
extern Ambient_t Light_flyguy_geo_0x8010bf0;
extern Ambient_t Light_flyguy_geo_0x8010c08;
extern Ambient_t Light_flyguy_geo_0x8010c20;
extern Gfx DL_flyguy_geo_0x8011710[];
extern Gfx DL_flyguy_geo_0x80113a8[];
extern Gfx DL_flyguy_geo_0x8011420[];
extern Gfx DL_flyguy_geo_0x80116d0[];
extern Light_t Light_flyguy_geo_0x80100a8;
extern Ambient_t Light_flyguy_geo_0x80100a0;
extern Gfx DL_flyguy_geo_0x8010840[];
extern Gfx DL_flyguy_geo_0x8010968[];
extern u8 flyguy_geo__texture_0800F888[];
extern Light_t Light_flyguy_geo_0x8010ae8;
extern Ambient_t Light_flyguy_geo_0x8010ae0;
extern Gfx DL_flyguy_geo_0x8010b80[];
extern Gfx DL_flyguy_geo_0x8010b38[];
#endif