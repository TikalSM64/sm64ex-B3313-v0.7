ALIGNED8 u8 small_water_splash_geo__texture_04022148[] = {
#include "actors/stomp_smoke/small_water_splash_geo_0x4022148_custom.ia16.inc.c"
};
ALIGNED8 u8 small_water_splash_geo__texture_04022948[] = {
#include "actors/stomp_smoke/small_water_splash_geo_0x4022948_custom.ia16.inc.c"
};
ALIGNED8 u8 small_water_splash_geo__texture_04023148[] = {
#include "actors/stomp_smoke/small_water_splash_geo_0x4023148_custom.ia16.inc.c"
};
ALIGNED8 u8 small_water_splash_geo__texture_04023948[] = {
#include "actors/stomp_smoke/small_water_splash_geo_0x4023948_custom.ia16.inc.c"
};
ALIGNED8 u8 small_water_splash_geo__texture_04024148[] = {
#include "actors/stomp_smoke/small_water_splash_geo_0x4024148_custom.ia16.inc.c"
};
ALIGNED8 u8 small_water_splash_geo__texture_04024948[] = {
#include "actors/stomp_smoke/small_water_splash_geo_0x4024948_custom.ia16.inc.c"
};
