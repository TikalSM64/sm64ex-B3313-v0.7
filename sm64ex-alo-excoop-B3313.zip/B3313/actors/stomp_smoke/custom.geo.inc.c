#include "custom.model.inc.h"
const GeoLayout small_water_splash_geo[]= {
GEO_SWITCH_CASE(6, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_small_water_splash_geo_0x40251f8),
GEO_DISPLAY_LIST(5,DL_small_water_splash_geo_0x4025210),
GEO_DISPLAY_LIST(5,DL_small_water_splash_geo_0x4025228),
GEO_DISPLAY_LIST(5,DL_small_water_splash_geo_0x4025240),
GEO_DISPLAY_LIST(5,DL_small_water_splash_geo_0x4025258),
GEO_DISPLAY_LIST(5,DL_small_water_splash_geo_0x4025270),
GEO_CLOSE_NODE(),
GEO_END(),
};
