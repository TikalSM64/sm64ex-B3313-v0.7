#ifndef stomp_smoke_stomp_smoke_model_HEADER_H
#define stomp_smoke_stomp_smoke_model_HEADER_H
#include "types.h"
extern Vtx VB_small_water_splash_geo_0x40220c8[];
extern u8 small_water_splash_geo__texture_04022148[];
extern Gfx DL_small_water_splash_geo_0x40251f8[];
extern Gfx DL_small_water_splash_geo_0x40251c8[];
extern Gfx DL_small_water_splash_geo_0x4025148[];
extern Gfx DL_small_water_splash_geo_0x4025190[];
extern u8 small_water_splash_geo__texture_04022948[];
extern Gfx DL_small_water_splash_geo_0x4025210[];
extern u8 small_water_splash_geo__texture_04023148[];
extern Gfx DL_small_water_splash_geo_0x4025228[];
extern u8 small_water_splash_geo__texture_04023948[];
extern Gfx DL_small_water_splash_geo_0x4025240[];
extern u8 small_water_splash_geo__texture_04024148[];
extern Gfx DL_small_water_splash_geo_0x4025258[];
extern u8 small_water_splash_geo__texture_04024948[];
extern Gfx DL_small_water_splash_geo_0x4025270[];
#endif