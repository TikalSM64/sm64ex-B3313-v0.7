#ifndef water_mine_water_mine_model_HEADER_H
#define water_mine_water_mine_model_HEADER_H
#include "types.h"
extern Vtx VB_water_mine_geo_0x600ccf8[];
extern Vtx VB_water_mine_geo_0x600cd38[];
extern Vtx VB_water_mine_geo_0x600cd78[];
extern Vtx VB_water_mine_geo_0x600ce68[];
extern Vtx VB_water_mine_geo_0x600cf58[];
extern Vtx VB_water_mine_geo_0x600d048[];
extern Vtx VB_water_mine_geo_0x600d138[];
extern u8 water_mine_geo__texture_0600C4F8[];
extern Light_t Light_water_mine_geo_0x600a4e8;
extern Ambient_t Light_water_mine_geo_0x600a4e0;
extern Gfx DL_water_mine_geo_0x600d3f8[];
extern Gfx DL_water_mine_geo_0x600d2e0[];
extern u8 water_mine_geo__texture_0600A4F8[];
extern u8 water_mine_geo__texture_0600B4F8[];
extern Gfx DL_water_mine_geo_0x600d268[];
extern Gfx DL_water_mine_geo_0x600d1f8[];
extern Gfx DL_water_mine_geo_0x600d230[];
#endif