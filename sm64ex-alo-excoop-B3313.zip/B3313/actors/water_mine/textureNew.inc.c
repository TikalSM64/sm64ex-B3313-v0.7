ALIGNED8 u8 water_mine_geo__texture_0600C4F8[] = {
#include "actors/water_mine/water_mine_geo_0x600c4f8_custom.rgba16.inc.c"
};
ALIGNED8 u8 water_mine_geo__texture_0600A4F8[] = {
#include "actors/water_mine/water_mine_geo_0x600a4f8_custom.rgba16.inc.c"
};
ALIGNED8 u8 water_mine_geo__texture_0600B4F8[] = {
#include "actors/water_mine/water_mine_geo_0x600b4f8_custom.rgba16.inc.c"
};
