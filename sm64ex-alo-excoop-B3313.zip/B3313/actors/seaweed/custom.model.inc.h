#ifndef seaweed_seaweed_model_HEADER_H
#define seaweed_seaweed_model_HEADER_H
#include "types.h"
extern Vtx VB_seaweed_geo_0x6009e10[];
extern Vtx VB_seaweed_geo_0x6009f08[];
extern Vtx VB_seaweed_geo_0x600a000[];
extern Vtx VB_seaweed_geo_0x600a0f8[];
extern u8 seaweed_geo__texture_06009610[];
extern Light_t Light_seaweed_geo_0x6007e00;
extern Ambient_t Light_seaweed_geo_0x6007df8;
extern Gfx DL_seaweed_geo_0x600a180[];
extern Gfx DL_seaweed_geo_0x600a138[];
extern u8 seaweed_geo__texture_06008E10[];
extern Gfx DL_seaweed_geo_0x600a088[];
extern Gfx DL_seaweed_geo_0x600a040[];
extern u8 seaweed_geo__texture_06008610[];
extern Gfx DL_seaweed_geo_0x6009f90[];
extern Gfx DL_seaweed_geo_0x6009f48[];
extern u8 seaweed_geo__texture_06007E10[];
extern Gfx DL_seaweed_geo_0x6009e98[];
extern Gfx DL_seaweed_geo_0x6009e50[];
#endif