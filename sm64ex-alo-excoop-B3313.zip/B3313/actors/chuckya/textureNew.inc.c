ALIGNED8 u8 chuckya_geo__texture_08007778[] = {
#include "actors/chuckya/chuckya_geo_0x8007778_custom.rgba16.inc.c"
};
ALIGNED8 u8 chuckya_geo__texture_08006778[] = {
#include "actors/chuckya/chuckya_geo_0x8006778_custom.rgba16.inc.c"
};
ALIGNED8 u8 chuckya_geo__texture_08007F78[] = {
#include "actors/chuckya/chuckya_geo_0x8007f78_custom.rgba16.inc.c"
};
ALIGNED8 u8 chuckya_geo__texture_08008F78[] = {
#include "actors/chuckya/chuckya_geo_0x8008f78_custom.rgba16.inc.c"
};
