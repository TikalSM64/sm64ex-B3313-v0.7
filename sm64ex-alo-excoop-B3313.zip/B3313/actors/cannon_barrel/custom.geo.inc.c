#include "custom.model.inc.h"
const GeoLayout cannon_barrel_geo[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_cannon_barrel_geo_0x8006660),
GEO_CLOSE_NODE(),
GEO_END(),
};
