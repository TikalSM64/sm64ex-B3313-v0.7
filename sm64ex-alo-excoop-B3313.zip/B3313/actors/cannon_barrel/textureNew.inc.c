ALIGNED8 u8 cannon_barrel_geo__texture_080058A8[] = {
#include "actors/cannon_barrel/cannon_barrel_geo_0x80058a8_custom.rgba16.inc.c"
};
