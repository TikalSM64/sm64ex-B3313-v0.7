#ifndef cannon_barrel_cannon_barrel_model_HEADER_H
#define cannon_barrel_cannon_barrel_model_HEADER_H
#include "types.h"
extern Vtx VB_cannon_barrel_geo_0x80060a8[];
extern Vtx VB_cannon_barrel_geo_0x80061a8[];
extern Vtx VB_cannon_barrel_geo_0x80062a8[];
extern Vtx VB_cannon_barrel_geo_0x80063a8[];
extern u8 cannon_barrel_geo__texture_080058A8[];
extern Light_t Light_cannon_barrel_geo_0x8005880;
extern Light_t Light_cannon_barrel_geo_0x8005898;
extern Ambient_t Light_cannon_barrel_geo_0x8005878;
extern Ambient_t Light_cannon_barrel_geo_0x8005890;
extern Gfx DL_cannon_barrel_geo_0x8006660[];
extern Gfx DL_cannon_barrel_geo_0x8006408[];
extern Gfx DL_cannon_barrel_geo_0x80064c0[];
#endif