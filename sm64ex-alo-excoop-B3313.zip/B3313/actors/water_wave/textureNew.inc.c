ALIGNED8 u8 wave_trail_geo__texture_04025358[] = {
#include "actors/water_wave/wave_trail_geo_0x4025358_custom.ia16.inc.c"
};
ALIGNED8 u8 wave_trail_geo__texture_04025B58[] = {
#include "actors/water_wave/wave_trail_geo_0x4025b58_custom.ia16.inc.c"
};
ALIGNED8 u8 wave_trail_geo__texture_04026358[] = {
#include "actors/water_wave/wave_trail_geo_0x4026358_custom.ia16.inc.c"
};
ALIGNED8 u8 wave_trail_geo__texture_04026B58[] = {
#include "actors/water_wave/wave_trail_geo_0x4026b58_custom.ia16.inc.c"
};
