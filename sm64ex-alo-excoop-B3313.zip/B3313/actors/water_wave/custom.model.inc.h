#ifndef water_wave_water_wave_model_HEADER_H
#define water_wave_water_wave_model_HEADER_H
#include "types.h"
extern Vtx VB_idle_water_wave_geo_0x4025318[];
extern u8 wave_trail_geo__texture_04025358[];
extern Gfx DL_wave_trail_geo_0x40273f0[];
extern Gfx DL_wave_trail_geo_0x40273d8[];
extern Gfx DL_wave_trail_geo_0x4027358[];
extern Gfx DL_wave_trail_geo_0x40273a0[];
extern u8 wave_trail_geo__texture_04025B58[];
extern Gfx DL_wave_trail_geo_0x4027408[];
extern u8 wave_trail_geo__texture_04026358[];
extern Gfx DL_wave_trail_geo_0x4027420[];
extern u8 wave_trail_geo__texture_04026B58[];
extern Gfx DL_wave_trail_geo_0x4027438[];
#endif