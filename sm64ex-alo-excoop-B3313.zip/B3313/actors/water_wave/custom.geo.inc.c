#include "custom.model.inc.h"
const GeoLayout wave_trail_geo[]= {
GEO_SWITCH_CASE(8, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x40273f0),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027408),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027420),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027438),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027438),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027438),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027438),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027438),
GEO_CLOSE_NODE(),
GEO_END(),
};
#include "custom.model.inc.h"
const GeoLayout idle_water_wave_geo[]= {
GEO_SWITCH_CASE(8, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x40273f0),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027408),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027420),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027438),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027420),
GEO_DISPLAY_LIST(5,DL_wave_trail_geo_0x4027408),
GEO_CLOSE_NODE(),
GEO_END(),
};
