ALIGNED8 u8 wiggler_head_geo__texture_05005A30[] = {
#include "actors/wiggler_head/wiggler_head_geo_0x5005a30_custom.rgba16.inc.c"
};
ALIGNED8 u8 wiggler_head_geo__texture_05006A30[] = {
#include "actors/wiggler_head/wiggler_head_geo_0x5006a30_custom.rgba16.inc.c"
};
ALIGNED8 u8 wiggler_head_geo__texture_05009230[] = {
#include "actors/wiggler_head/wiggler_head_geo_0x5009230_custom.rgba16.inc.c"
};
ALIGNED8 u8 wiggler_head_geo__texture_0500A230[] = {
#include "actors/wiggler_head/wiggler_head_geo_0x500a230_custom.rgba16.inc.c"
};
ALIGNED8 u8 wiggler_head_geo__texture_05008230[] = {
#include "actors/wiggler_head/wiggler_head_geo_0x5008230_custom.rgba16.inc.c"
};
ALIGNED8 u8 wiggler_head_geo__texture_05007A30[] = {
#include "actors/wiggler_head/wiggler_head_geo_0x5007a30_custom.rgba16.inc.c"
};
ALIGNED8 u8 wiggler_head_geo__texture_05008A30[] = {
#include "actors/wiggler_head/wiggler_head_geo_0x5008a30_custom.rgba16.inc.c"
};
