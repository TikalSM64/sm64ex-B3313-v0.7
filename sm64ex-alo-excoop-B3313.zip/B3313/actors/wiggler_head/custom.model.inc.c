#include "custom.model.inc.h"
Vtx VB_wiggler_head_geo_0x500c188[] = {
	{{{ 0, 21, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ -20, -20, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
	{{{ 0, -20, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
	{{{ -20, 21, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_wiggler_head_geo_0x500c1c8[] = {
	{{{ 21, 21, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ 0, 21, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ 0, -20, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
	{{{ 21, -20, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
};

Vtx VB_wiggler_head_geo_0x500c8d8[] = {
	{{{ 19, 5, -31 }, 0, { 0, 0 }, { 64, 43, 157, 0}}},
	{{{ 20, -37, -43 }, 0, { 0, 0 }, { 72, 235, 154, 0}}},
	{{{ -5, -36, -43 }, 0, { 0, 0 }, { 189, 228, 153, 0}}},
	{{{ -2, 5, -31 }, 0, { 0, 0 }, { 202, 50, 154, 255}}},
	{{{ 20, -66, -21 }, 0, { 0, 0 }, { 66, 161, 206, 255}}},
	{{{ 20, -66, 21 }, 0, { 0, 0 }, { 66, 161, 50, 255}}},
	{{{ 0, -59, 21 }, 0, { 0, 0 }, { 183, 161, 39, 255}}},
	{{{ 0, -59, -21 }, 0, { 0, 0 }, { 183, 161, 217, 255}}},
	{{{ 20, -37, 43 }, 0, { 0, 0 }, { 72, 235, 102, 255}}},
	{{{ 19, 5, 31 }, 0, { 0, 0 }, { 64, 43, 99, 255}}},
	{{{ -2, 5, 31 }, 0, { 0, 0 }, { 202, 50, 102, 255}}},
	{{{ -5, -36, 43 }, 0, { 0, 0 }, { 189, 228, 103, 255}}},
	{{{ 18, 34, 15 }, 0, { 0, 0 }, { 65, 91, 58, 255}}},
	{{{ 18, 34, -15 }, 0, { 0, 0 }, { 65, 91, 198, 255}}},
	{{{ 0, 28, -15 }, 0, { 0, 0 }, { 186, 91, 204, 255}}},
	{{{ 0, 28, 15 }, 0, { 0, 0 }, { 186, 91, 52, 255}}},
};

Vtx VB_wiggler_head_geo_0x500c9d8[] = {
	{{{ 0, -59, 21 }, 0, { 0, 0 }, { 183, 161, 39, 255}}},
	{{{ -5, -36, 43 }, 0, { 0, 0 }, { 189, 228, 103, 0}}},
	{{{ -17, -33, 21 }, 0, { 0, 0 }, { 137, 227, 31, 0}}},
	{{{ -2, 5, 31 }, 0, { 0, 0 }, { 202, 50, 102, 255}}},
	{{{ 0, 28, 15 }, 0, { 0, 0 }, { 186, 91, 52, 255}}},
	{{{ -15, 5, 15 }, 0, { 0, 0 }, { 143, 42, 38, 255}}},
	{{{ -15, 5, -15 }, 0, { 0, 0 }, { 143, 42, 218, 255}}},
	{{{ -17, -33, -21 }, 0, { 0, 0 }, { 137, 227, 225, 255}}},
	{{{ -2, 5, -31 }, 0, { 0, 0 }, { 202, 50, 154, 255}}},
	{{{ -5, -36, -43 }, 0, { 0, 0 }, { 189, 228, 153, 255}}},
	{{{ 0, 28, -15 }, 0, { 0, 0 }, { 186, 91, 204, 255}}},
	{{{ 18, 34, -15 }, 0, { 0, 0 }, { 65, 91, 198, 255}}},
	{{{ 19, 5, -31 }, 0, { 0, 0 }, { 64, 43, 157, 255}}},
	{{{ 0, -59, -21 }, 0, { 0, 0 }, { 183, 161, 217, 255}}},
	{{{ 20, -66, -21 }, 0, { 0, 0 }, { 66, 161, 206, 255}}},
	{{{ 20, -37, -43 }, 0, { 0, 0 }, { 72, 235, 154, 255}}},
};

Vtx VB_wiggler_head_geo_0x500cad8[] = {
	{{{ 20, -37, 43 }, 0, { 0, 0 }, { 72, 235, 102, 255}}},
	{{{ -5, -36, 43 }, 0, { 0, 0 }, { 189, 228, 103, 0}}},
	{{{ 0, -59, 21 }, 0, { 0, 0 }, { 183, 161, 39, 0}}},
	{{{ 20, -66, 21 }, 0, { 0, 0 }, { 66, 161, 50, 255}}},
	{{{ -15, 5, 15 }, 0, { 0, 0 }, { 143, 42, 38, 255}}},
	{{{ -17, -33, 21 }, 0, { 0, 0 }, { 137, 227, 31, 255}}},
	{{{ -2, 5, 31 }, 0, { 0, 0 }, { 202, 50, 102, 255}}},
	{{{ 18, 34, 15 }, 0, { 0, 0 }, { 65, 91, 58, 255}}},
	{{{ 19, 5, 31 }, 0, { 0, 0 }, { 64, 43, 99, 255}}},
	{{{ 0, 28, 15 }, 0, { 0, 0 }, { 186, 91, 52, 255}}},
	{{{ 20, -66, -21 }, 0, { 0, 0 }, { 127, 2, 0, 255}}},
	{{{ 20, -37, -43 }, 0, { 0, 0 }, { 61, 237, 147, 255}}},
	{{{ 19, 5, -31 }, 0, { 0, 0 }, { 27, 50, 143, 255}}},
	{{{ 18, 34, -15 }, 0, { 0, 0 }, { 127, 2, 0, 255}}},
	{{{ 18, 34, 15 }, 0, { 0, 0 }, { 6, 110, 62, 255}}},
	{{{ 19, 5, 31 }, 0, { 0, 0 }, { 57, 43, 104, 255}}},
};

Vtx VB_wiggler_head_geo_0x500cbd8[] = {
	{{{ 20, -66, -21 }, 0, { 0, 0 }, { 127, 2, 0, 255}}},
	{{{ 19, 5, 31 }, 0, { 0, 0 }, { 57, 43, 104, 0}}},
	{{{ 20, -37, 43 }, 0, { 0, 0 }, { 27, 231, 121, 0}}},
	{{{ 20, -66, 21 }, 0, { 0, 0 }, { 127, 2, 0, 255}}},
};

Vtx VB_wiggler_head_geo_0x500cc18[] = {
	{{{ 53, -2, -13 }, 0, { 0, 0 }, { 0, 216, 136, 0}}},
	{{{ 53, -11, 0 }, 0, { 0, 0 }, { 1, 129, 1, 0}}},
	{{{ -3, -12, 0 }, 0, { 0, 0 }, { 1, 129, 1, 0}}},
	{{{ -3, -2, -13 }, 0, { 0, 0 }, { 0, 216, 136, 255}}},
	{{{ 53, -1, 13 }, 0, { 0, 0 }, { 0, 218, 121, 255}}},
	{{{ 53, 13, 8 }, 0, { 0, 0 }, { 255, 103, 73, 255}}},
	{{{ -4, 13, 8 }, 0, { 0, 0 }, { 255, 103, 73, 255}}},
	{{{ -3, -2, 13 }, 0, { 0, 0 }, { 0, 218, 121, 255}}},
	{{{ 53, 13, -8 }, 0, { 0, 0 }, { 255, 102, 181, 255}}},
	{{{ -4, 13, -8 }, 0, { 0, 0 }, { 255, 102, 181, 255}}},
	{{{ -3, -2, 13 }, 0, { 0, 0 }, { 129, 255, 0, 255}}},
	{{{ -4, 13, 8 }, 0, { 0, 0 }, { 129, 255, 0, 255}}},
	{{{ -4, 13, -8 }, 0, { 0, 0 }, { 208, 107, 211, 255}}},
	{{{ -3, -2, -13 }, 0, { 0, 0 }, { 210, 246, 139, 255}}},
	{{{ -3, -12, 0 }, 0, { 0, 0 }, { 211, 141, 230, 255}}},
};

Vtx VB_wiggler_head_geo_0x500cd08[] = {
	{{{ 42, -2, -13 }, 0, { 0, 0 }, { 0, 216, 136, 0}}},
	{{{ 42, -12, 0 }, 0, { 0, 0 }, { 0, 129, 1, 0}}},
	{{{ -6, -12, 0 }, 0, { 0, 0 }, { 0, 129, 1, 0}}},
	{{{ -6, -2, -13 }, 0, { 0, 0 }, { 0, 216, 136, 255}}},
	{{{ 42, -2, 13 }, 0, { 0, 0 }, { 0, 218, 121, 255}}},
	{{{ 42, 13, 8 }, 0, { 0, 0 }, { 0, 103, 73, 255}}},
	{{{ -6, 13, 8 }, 0, { 0, 0 }, { 0, 103, 73, 255}}},
	{{{ -6, -2, 13 }, 0, { 0, 0 }, { 0, 218, 121, 255}}},
	{{{ 42, 13, -8 }, 0, { 0, 0 }, { 0, 102, 181, 255}}},
	{{{ -6, 13, -8 }, 0, { 0, 0 }, { 0, 102, 181, 255}}},
	{{{ 42, 13, -8 }, 0, { 0, 0 }, { 47, 75, 166, 255}}},
	{{{ 42, 13, 8 }, 0, { 0, 0 }, { 47, 109, 44, 255}}},
	{{{ 42, -2, 13 }, 0, { 0, 0 }, { 47, 248, 117, 255}}},
	{{{ 42, -12, 0 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
	{{{ 42, -2, -13 }, 0, { 0, 0 }, { 47, 194, 157, 255}}},
};

Vtx VB_wiggler_head_geo_0x500cdf8[] = {
	{{{ -2, 5, 31 }, 0, { 0, 0 }, { 202, 50, 102, 0}}},
	{{{ -5, -36, 43 }, 0, { 0, 0 }, { 189, 228, 103, 0}}},
	{{{ 20, -37, 43 }, 0, { 0, 0 }, { 72, 235, 102, 0}}},
	{{{ 19, 5, 31 }, 0, { 0, 0 }, { 64, 43, 99, 255}}},
	{{{ 0, -59, 21 }, 0, { 0, 0 }, { 183, 161, 39, 255}}},
	{{{ 0, -59, -21 }, 0, { 0, 0 }, { 183, 161, 217, 255}}},
	{{{ 20, -66, -21 }, 0, { 0, 0 }, { 66, 161, 206, 255}}},
	{{{ 20, -66, 21 }, 0, { 0, 0 }, { 66, 161, 50, 255}}},
	{{{ -5, -36, -43 }, 0, { 0, 0 }, { 189, 228, 153, 255}}},
	{{{ -2, 5, -31 }, 0, { 0, 0 }, { 202, 50, 154, 255}}},
	{{{ 19, 5, -31 }, 0, { 0, 0 }, { 64, 43, 157, 255}}},
	{{{ 20, -37, -43 }, 0, { 0, 0 }, { 72, 235, 154, 255}}},
	{{{ 0, 28, -15 }, 0, { 0, 0 }, { 186, 91, 204, 255}}},
	{{{ 0, 28, 15 }, 0, { 0, 0 }, { 186, 91, 52, 255}}},
	{{{ 18, 34, 15 }, 0, { 0, 0 }, { 65, 91, 58, 255}}},
	{{{ 18, 34, -15 }, 0, { 0, 0 }, { 65, 91, 198, 255}}},
};

Vtx VB_wiggler_head_geo_0x500cef8[] = {
	{{{ -17, -33, -21 }, 0, { 0, 0 }, { 137, 227, 225, 255}}},
	{{{ -5, -36, -43 }, 0, { 0, 0 }, { 189, 228, 153, 0}}},
	{{{ 0, -59, -21 }, 0, { 0, 0 }, { 183, 161, 217, 0}}},
	{{{ -15, 5, -15 }, 0, { 0, 0 }, { 143, 42, 218, 255}}},
	{{{ 0, 28, -15 }, 0, { 0, 0 }, { 186, 91, 204, 255}}},
	{{{ -2, 5, -31 }, 0, { 0, 0 }, { 202, 50, 154, 255}}},
	{{{ -17, -33, 21 }, 0, { 0, 0 }, { 137, 227, 31, 255}}},
	{{{ -15, 5, 15 }, 0, { 0, 0 }, { 143, 42, 38, 255}}},
	{{{ -5, -36, 43 }, 0, { 0, 0 }, { 189, 228, 103, 255}}},
	{{{ -2, 5, 31 }, 0, { 0, 0 }, { 202, 50, 102, 255}}},
	{{{ 19, 5, 31 }, 0, { 0, 0 }, { 64, 43, 99, 255}}},
	{{{ 18, 34, 15 }, 0, { 0, 0 }, { 65, 91, 58, 255}}},
	{{{ 0, 28, 15 }, 0, { 0, 0 }, { 186, 91, 52, 255}}},
	{{{ 0, -59, 21 }, 0, { 0, 0 }, { 183, 161, 39, 255}}},
	{{{ 20, -37, 43 }, 0, { 0, 0 }, { 72, 235, 102, 255}}},
	{{{ 20, -66, 21 }, 0, { 0, 0 }, { 66, 161, 50, 255}}},
};

Vtx VB_wiggler_head_geo_0x500cff8[] = {
	{{{ 20, -66, -21 }, 0, { 0, 0 }, { 66, 161, 206, 255}}},
	{{{ 0, -59, -21 }, 0, { 0, 0 }, { 183, 161, 217, 0}}},
	{{{ -5, -36, -43 }, 0, { 0, 0 }, { 189, 228, 153, 0}}},
	{{{ 20, -37, -43 }, 0, { 0, 0 }, { 72, 235, 154, 255}}},
	{{{ -2, 5, -31 }, 0, { 0, 0 }, { 202, 50, 154, 255}}},
	{{{ -17, -33, -21 }, 0, { 0, 0 }, { 137, 227, 225, 255}}},
	{{{ -15, 5, -15 }, 0, { 0, 0 }, { 143, 42, 218, 255}}},
	{{{ 19, 5, -31 }, 0, { 0, 0 }, { 64, 43, 157, 255}}},
	{{{ 0, 28, -15 }, 0, { 0, 0 }, { 186, 91, 204, 255}}},
	{{{ 18, 34, -15 }, 0, { 0, 0 }, { 65, 91, 198, 255}}},
	{{{ 20, -37, 43 }, 0, { 0, 0 }, { 27, 231, 121, 255}}},
	{{{ 20, -66, 21 }, 0, { 0, 0 }, { 127, 2, 0, 255}}},
	{{{ 20, -66, -21 }, 0, { 0, 0 }, { 127, 2, 0, 255}}},
	{{{ 20, -37, -43 }, 0, { 0, 0 }, { 61, 237, 147, 255}}},
	{{{ 19, 5, -31 }, 0, { 0, 0 }, { 27, 50, 143, 255}}},
	{{{ 18, 34, -15 }, 0, { 0, 0 }, { 127, 2, 0, 255}}},
};

Vtx VB_wiggler_head_geo_0x500d0f8[] = {
	{{{ 20, -37, 43 }, 0, { 0, 0 }, { 27, 231, 121, 255}}},
	{{{ 18, 34, -15 }, 0, { 0, 0 }, { 127, 2, 0, 0}}},
	{{{ 18, 34, 15 }, 0, { 0, 0 }, { 6, 110, 62, 0}}},
	{{{ 19, 5, 31 }, 0, { 0, 0 }, { 57, 43, 104, 255}}},
};

Vtx VB_wiggler_head_geo_0x500d138[] = {
	{{{ -3, -2, 13 }, 0, { 0, 0 }, { 0, 216, 120, 0}}},
	{{{ -3, -12, 0 }, 0, { 0, 0 }, { 1, 129, 255, 0}}},
	{{{ 53, -11, 0 }, 0, { 0, 0 }, { 1, 129, 255, 0}}},
	{{{ 53, -2, 13 }, 0, { 0, 0 }, { 0, 216, 120, 255}}},
	{{{ -3, -2, -13 }, 0, { 0, 0 }, { 0, 218, 135, 255}}},
	{{{ -4, 13, -8 }, 0, { 0, 0 }, { 255, 103, 183, 255}}},
	{{{ 53, 13, -8 }, 0, { 0, 0 }, { 255, 103, 183, 255}}},
	{{{ 53, -1, -13 }, 0, { 0, 0 }, { 0, 218, 135, 255}}},
	{{{ -4, 13, 8 }, 0, { 0, 0 }, { 255, 102, 75, 255}}},
	{{{ 53, 13, 8 }, 0, { 0, 0 }, { 255, 102, 75, 255}}},
	{{{ -3, -2, -13 }, 0, { 0, 0 }, { 129, 255, 0, 255}}},
	{{{ -3, -12, 0 }, 0, { 0, 0 }, { 129, 255, 0, 255}}},
	{{{ -3, -2, 13 }, 0, { 0, 0 }, { 210, 193, 99, 255}}},
	{{{ -4, 13, 8 }, 0, { 0, 0 }, { 208, 75, 90, 255}}},
	{{{ -4, 13, -8 }, 0, { 0, 0 }, { 208, 108, 213, 255}}},
};

Vtx VB_wiggler_head_geo_0x500d228[] = {
	{{{ -6, -2, 13 }, 0, { 0, 0 }, { 0, 216, 120, 0}}},
	{{{ -6, -12, 0 }, 0, { 0, 0 }, { 0, 129, 255, 0}}},
	{{{ 42, -12, 0 }, 0, { 0, 0 }, { 0, 129, 255, 0}}},
	{{{ 42, -2, 13 }, 0, { 0, 0 }, { 0, 216, 120, 255}}},
	{{{ -6, -2, -13 }, 0, { 0, 0 }, { 0, 218, 135, 255}}},
	{{{ -6, 13, -8 }, 0, { 0, 0 }, { 0, 103, 183, 255}}},
	{{{ 42, 13, -8 }, 0, { 0, 0 }, { 0, 103, 183, 255}}},
	{{{ 42, -2, -13 }, 0, { 0, 0 }, { 0, 218, 135, 255}}},
	{{{ -6, 13, 8 }, 0, { 0, 0 }, { 0, 102, 75, 255}}},
	{{{ 42, 13, 8 }, 0, { 0, 0 }, { 0, 102, 75, 255}}},
	{{{ 42, 13, -8 }, 0, { 0, 0 }, { 47, 77, 167, 255}}},
	{{{ 42, 13, 8 }, 0, { 0, 0 }, { 47, 108, 45, 255}}},
	{{{ 42, -2, 13 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
	{{{ 42, -12, 0 }, 0, { 0, 0 }, { 127, 0, 0, 255}}},
	{{{ 42, -2, -13 }, 0, { 0, 0 }, { 47, 196, 156, 255}}},
};

Vtx VB_wiggler_head_geo_0x500e0e8[] = {
	{{{ 0, 15, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ -15, -15, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
	{{{ 0, -15, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
	{{{ -15, 15, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_wiggler_head_geo_0x500e128[] = {
	{{{ 15, 15, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ 0, -15, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
	{{{ 15, -15, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
	{{{ 0, 15, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_wiggler_head_geo_0x500e250[] = {
	{{{ 58, 87, 0 }, 0, { 478, 990 }, { 255, 255, 255, 255}}},
	{{{ 84, 50, 23 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ 88, 54, 0 }, 0, { 478, 0 }, { 255, 255, 255, 255}}},
	{{{ 54, 83, -21 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 84, 50, -21 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ 54, 83, 23 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_wiggler_head_geo_0x500e368[] = {
	{{{ 58, -82, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ 88, -35, -43 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 94, -40, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
	{{{ 51, -77, -43 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ 94, -40, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 51, -77, 44 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ 58, -82, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ 88, -35, 44 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_wiggler_head_geo_0x500e4a0[] = {
	{{{ -77, -98, 2 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
	{{{ 8, -83, 94 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ -74, -53, 79 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 6, -128, 16 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_wiggler_head_geo_0x500e588[] = {
	{{{ 0, 26, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ -26, -26, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
	{{{ 0, -26, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
	{{{ -26, 26, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_wiggler_head_geo_0x500e5c8[] = {
	{{{ 26, 26, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ 0, -26, 0 }, 0, { 0, 2012 }, { 255, 255, 255, 255}}},
	{{{ 26, -26, 0 }, 0, { 990, 2012 }, { 255, 255, 255, 255}}},
	{{{ 0, 26, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Gfx DL_wiggler_head_geo_0x500c278[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPDisplayList(DL_wiggler_head_geo_0x500c208),
	gsSPDisplayList(DL_wiggler_head_geo_0x500c240),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500c208[] = {
	gsDPSetTextureImage(0, 2, 1, wiggler_head_geo__texture_05005A30),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsSPVertex(VB_wiggler_head_geo_0x500c188, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500c240[] = {
	gsDPSetTextureImage(0, 2, 1, wiggler_head_geo__texture_05006A30),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsSPVertex(VB_wiggler_head_geo_0x500c1c8, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e678[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPDisplayList(DL_wiggler_head_geo_0x500e608),
	gsSPDisplayList(DL_wiggler_head_geo_0x500e640),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e608[] = {
	gsDPSetTextureImage(0, 2, 1, wiggler_head_geo__texture_05005A30),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsSPVertex(VB_wiggler_head_geo_0x500e588, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e640[] = {
	gsDPSetTextureImage(0, 2, 1, wiggler_head_geo__texture_05006A30),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsSPVertex(VB_wiggler_head_geo_0x500e5c8, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e1d8[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 6, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPDisplayList(DL_wiggler_head_geo_0x500e168),
	gsSPDisplayList(DL_wiggler_head_geo_0x500e1a0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e168[] = {
	gsDPSetTextureImage(0, 2, 1, wiggler_head_geo__texture_05009230),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsSPVertex(VB_wiggler_head_geo_0x500e0e8, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e1a0[] = {
	gsDPSetTextureImage(0, 2, 1, wiggler_head_geo__texture_0500A230),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 2047, 256),
	gsSPVertex(VB_wiggler_head_geo_0x500e128, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e518[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_wiggler_head_geo_0x500e4e0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e4e0[] = {
	gsDPSetTextureImage(0, 2, 1, wiggler_head_geo__texture_05008230),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_wiggler_head_geo_0x500e4a0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e430[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_wiggler_head_geo_0x500e3e8),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e3e8[] = {
	gsDPSetTextureImage(0, 2, 1, wiggler_head_geo__texture_05007A30),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_wiggler_head_geo_0x500e368, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e2f8[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_wiggler_head_geo_0x500e2b0),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e2b0[] = {
	gsDPSetTextureImage(0, 2, 1, wiggler_head_geo__texture_05008A30),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_wiggler_head_geo_0x500e250, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
	gsSP2Triangles(2, 4, 3, 0, 0, 5, 1, 0),
	gsSPEndDisplayList(),
};

Light_t Light_wiggler_head_geo_0x500c898 = {
	{ 231, 71, 0}, 0, { 231, 71, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_wiggler_head_geo_0x500c890 = {
	{57, 17, 0}, 0, {57, 17, 0}, 0
};

Gfx DL_wiggler_head_geo_0x500ddf8[] = {
	gsSPLight(&Light_wiggler_head_geo_0x500c898.col, 1),
	gsSPLight(&Light_wiggler_head_geo_0x500c890.col, 2),
	gsSPVertex(VB_wiggler_head_geo_0x500cd08, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 0, 3, 0, 8, 3, 9, 0),
	gsSP2Triangles(1, 4, 7, 0, 1, 7, 2, 0),
	gsSP2Triangles(5, 8, 9, 0, 5, 9, 6, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP1Triangle(10, 13, 14, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500dd70[] = {
	gsSPLight(&Light_wiggler_head_geo_0x500c898.col, 1),
	gsSPLight(&Light_wiggler_head_geo_0x500c890.col, 2),
	gsSPVertex(VB_wiggler_head_geo_0x500cc18, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 0, 3, 0, 8, 3, 9, 0),
	gsSP2Triangles(1, 4, 7, 0, 1, 7, 2, 0),
	gsSP2Triangles(5, 8, 9, 0, 5, 9, 6, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP1Triangle(10, 13, 14, 0),
	gsSPEndDisplayList(),
};

Light_t Light_wiggler_head_geo_0x500c880 = {
	{ 223, 0, 0}, 0, { 223, 0, 0}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_wiggler_head_geo_0x500c878 = {
	{55, 0, 0}, 0, {55, 0, 0}, 0
};

Gfx DL_wiggler_head_geo_0x500dc18[] = {
	gsSPLight(&Light_wiggler_head_geo_0x500c880.col, 1),
	gsSPLight(&Light_wiggler_head_geo_0x500c878.col, 2),
	gsSPVertex(VB_wiggler_head_geo_0x500c8d8, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSPVertex(VB_wiggler_head_geo_0x500c9d8, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 2, 0, 6, 2, 5, 0),
	gsSP2Triangles(7, 6, 8, 0, 7, 8, 9, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 8, 0),
	gsSP2Triangles(9, 13, 7, 0, 10, 8, 6, 0),
	gsSP2Triangles(14, 13, 9, 0, 14, 9, 15, 0),
	gsSP2Triangles(2, 7, 13, 0, 2, 13, 0, 0),
	gsSP2Triangles(6, 4, 10, 0, 6, 5, 4, 0),
	gsSPVertex(VB_wiggler_head_geo_0x500cad8, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 1, 0, 4, 1, 6, 0),
	gsSP2Triangles(7, 6, 8, 0, 7, 9, 6, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP2Triangles(10, 13, 14, 0, 10, 14, 15, 0),
	gsSPVertex(VB_wiggler_head_geo_0x500cbd8, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500e060[] = {
	gsSPLight(&Light_wiggler_head_geo_0x500c898.col, 1),
	gsSPLight(&Light_wiggler_head_geo_0x500c890.col, 2),
	gsSPVertex(VB_wiggler_head_geo_0x500d228, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 0, 3, 0, 8, 3, 9, 0),
	gsSP2Triangles(1, 4, 7, 0, 1, 7, 2, 0),
	gsSP2Triangles(5, 8, 9, 0, 5, 9, 6, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP1Triangle(10, 13, 14, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500dfd8[] = {
	gsSPLight(&Light_wiggler_head_geo_0x500c898.col, 1),
	gsSPLight(&Light_wiggler_head_geo_0x500c890.col, 2),
	gsSPVertex(VB_wiggler_head_geo_0x500d138, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 0, 3, 0, 8, 3, 9, 0),
	gsSP2Triangles(1, 4, 7, 0, 1, 7, 2, 0),
	gsSP2Triangles(5, 8, 9, 0, 5, 9, 6, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP1Triangle(10, 13, 14, 0),
	gsSPEndDisplayList(),
};

Gfx DL_wiggler_head_geo_0x500de80[] = {
	gsSPLight(&Light_wiggler_head_geo_0x500c880.col, 1),
	gsSPLight(&Light_wiggler_head_geo_0x500c878.col, 2),
	gsSPVertex(VB_wiggler_head_geo_0x500cdf8, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSPVertex(VB_wiggler_head_geo_0x500cef8, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 0, 6, 0, 3, 6, 7, 0),
	gsSP2Triangles(8, 9, 7, 0, 8, 7, 6, 0),
	gsSP2Triangles(9, 10, 11, 0, 9, 11, 12, 0),
	gsSP2Triangles(6, 13, 8, 0, 7, 9, 12, 0),
	gsSP2Triangles(14, 8, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(2, 13, 6, 0, 2, 6, 0, 0),
	gsSP2Triangles(12, 3, 7, 0, 12, 4, 3, 0),
	gsSPVertex(VB_wiggler_head_geo_0x500cff8, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 2, 5, 0, 4, 5, 6, 0),
	gsSP2Triangles(7, 8, 9, 0, 7, 4, 8, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP2Triangles(10, 13, 14, 0, 10, 14, 15, 0),
	gsSPVertex(VB_wiggler_head_geo_0x500d0f8, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

