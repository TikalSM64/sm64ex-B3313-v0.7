#ifndef lll_sinking_rectangular_platform_model_HEADER_H
#define lll_sinking_rectangular_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000BC8_0x7019a98[];
extern Vtx VB_lll_geo_000BC8_0x7019b18[];
extern u8 lll_geo_000BC8__texture_09004000[];
extern u8 lll_geo_000BC8__texture_09006000[];
extern Light_t Light_lll_geo_000BC8_0x700fc08;
extern Ambient_t Light_lll_geo_000BC8_0x700fc00;
extern Gfx DL_lll_geo_000BC8_0x7019c08[];
extern Gfx DL_lll_geo_000BC8_0x7019b78[];
extern Gfx DL_lll_geo_000BC8_0x7019bd0[];
#endif