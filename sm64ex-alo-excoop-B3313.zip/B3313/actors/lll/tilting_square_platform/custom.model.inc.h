#ifndef lll_tilting_square_platform_model_HEADER_H
#define lll_tilting_square_platform_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000BF8_0x701a080[];
extern Vtx VB_lll_geo_000BF8_0x701a120[];
extern u8 lll_geo_000BF8__texture_09001800[];
extern u8 lll_geo_000BF8__texture_09004000[];
extern Light_t Light_lll_geo_000BF8_0x700fc08;
extern Ambient_t Light_lll_geo_000BF8_0x700fc00;
extern Gfx DL_lll_geo_000BF8_0x701a1f0[];
extern Gfx DL_lll_geo_000BF8_0x701a160[];
extern Gfx DL_lll_geo_000BF8_0x701a1a8[];
#endif