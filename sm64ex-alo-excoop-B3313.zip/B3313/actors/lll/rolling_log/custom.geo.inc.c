#include "custom.model.inc.h"
const GeoLayout lll_geo_000DE8[]= {
GEO_CULLING_RADIUS(1300),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000DE8_0x701ad70),
GEO_CLOSE_NODE(),
GEO_END(),
};
