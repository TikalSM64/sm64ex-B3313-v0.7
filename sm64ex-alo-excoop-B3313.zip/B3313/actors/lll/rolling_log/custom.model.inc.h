#ifndef lll_rolling_log_model_HEADER_H
#define lll_rolling_log_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000DE8_0x701a900[];
extern Vtx VB_lll_geo_000DE8_0x701a9f0[];
extern Vtx VB_lll_geo_000DE8_0x701aae0[];
extern Vtx VB_lll_geo_000DE8_0x701ab20[];
extern u8 lll_geo_000DE8__texture_0900A800[];
extern u8 lll_geo_000DE8__texture_0900B000[];
extern Light_t Light_lll_geo_000DE8_0x701a8f0;
extern Ambient_t Light_lll_geo_000DE8_0x701a8e8;
extern Gfx DL_lll_geo_000DE8_0x701ad70[];
extern Gfx DL_lll_geo_000DE8_0x701ac20[];
extern Gfx DL_lll_geo_000DE8_0x701ace8[];
#endif