#include "custom.model.inc.h"
const GeoLayout lll_geo_000BB0[]= {
GEO_CULLING_RADIUS(2100),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000BB0_0x7019a08),
GEO_CLOSE_NODE(),
GEO_END(),
};
