#ifndef lll_5_model_HEADER_H
#define lll_5_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_0009F8_0x7013db8[];
extern Vtx VB_lll_geo_0009F8_0x7013ea8[];
extern Vtx VB_lll_geo_0009F8_0x7013f98[];
extern Vtx VB_lll_geo_0009F8_0x7014088[];
extern Vtx VB_lll_geo_0009F8_0x7014178[];
extern Vtx VB_lll_geo_0009F8_0x7014278[];
extern Vtx VB_lll_geo_0009F8_0x7014378[];
extern Vtx VB_lll_geo_0009F8_0x7014478[];
extern u8 lll_geo_0009F8__texture_09007800[];
extern u8 lll_geo_0009F8__texture_09007000[];
extern Light_t Light_lll_geo_0009F8_0x700fc08;
extern Ambient_t Light_lll_geo_0009F8_0x700fc00;
extern Gfx DL_lll_geo_0009F8_0x7014788[];
extern Gfx DL_lll_geo_0009F8_0x70144f8[];
extern Gfx DL_lll_geo_0009F8_0x70146b8[];
#endif