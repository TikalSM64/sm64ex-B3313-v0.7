#ifndef lll_10_model_HEADER_H
#define lll_10_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000A78_0x70162e0[];
extern Vtx VB_lll_geo_000A78_0x7016340[];
extern Vtx VB_lll_geo_000A78_0x7016430[];
extern u8 lll_geo_000A78__texture_07005800[];
extern u8 lll_geo_000A78__texture_09007800[];
extern Light_t Light_lll_geo_000A78_0x700fc08;
extern Ambient_t Light_lll_geo_000A78_0x700fc00;
extern Gfx DL_lll_geo_000A78_0x70165c8[];
extern Gfx DL_lll_geo_000A78_0x70164e0[];
extern Gfx DL_lll_geo_000A78_0x7016538[];
#endif