#ifndef lll_12_model_HEADER_H
#define lll_12_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000AA8_0x7016b70[];
extern Vtx VB_lll_geo_000AA8_0x7016bf0[];
extern Vtx VB_lll_geo_000AA8_0x7016ce0[];
extern Vtx VB_lll_geo_000AA8_0x7016dd0[];
extern Vtx VB_lll_geo_000AA8_0x7016ec0[];
extern Vtx VB_lll_geo_000AA8_0x7016fb0[];
extern Vtx VB_lll_geo_000AA8_0x70170a0[];
extern Vtx VB_lll_geo_000AA8_0x7017190[];
extern u8 lll_geo_000AA8__texture_09004800[];
extern u8 lll_geo_000AA8__texture_07002000[];
extern u8 lll_geo_000AA8__texture_09007800[];
extern Light_t Light_lll_geo_000AA8_0x700fc08;
extern Ambient_t Light_lll_geo_000AA8_0x700fc00;
extern Gfx DL_lll_geo_000AA8_0x70174e0[];
extern Gfx DL_lll_geo_000AA8_0x7017250[];
extern Gfx DL_lll_geo_000AA8_0x7017358[];
extern Gfx DL_lll_geo_000AA8_0x70172b8[];
#endif