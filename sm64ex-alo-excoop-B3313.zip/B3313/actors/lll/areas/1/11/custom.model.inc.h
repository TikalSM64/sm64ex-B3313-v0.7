#ifndef lll_11_model_HEADER_H
#define lll_11_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000A90_0x7016670[];
extern Vtx VB_lll_geo_000A90_0x7016770[];
extern Vtx VB_lll_geo_000A90_0x70167f0[];
extern Vtx VB_lll_geo_000A90_0x7016850[];
extern u8 lll_geo_000A90__texture_09003000[];
extern u8 lll_geo_000A90__texture_09009000[];
extern u8 lll_geo_000A90__texture_09009800[];
extern Light_t Light_lll_geo_000A90_0x7016660;
extern Ambient_t Light_lll_geo_000A90_0x7016658;
extern Gfx DL_lll_geo_000A90_0x7016b00[];
extern Gfx DL_lll_geo_000A90_0x7016930[];
extern Gfx DL_lll_geo_000A90_0x7016a30[];
extern Gfx DL_lll_geo_000A90_0x7016a78[];
#endif