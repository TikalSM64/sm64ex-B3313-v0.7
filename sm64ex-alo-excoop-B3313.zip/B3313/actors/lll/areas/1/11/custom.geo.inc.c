#include "custom.model.inc.h"
const GeoLayout lll_geo_000A90[]= {
GEO_CULLING_RADIUS(1000),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000A90_0x7016b00),
GEO_CLOSE_NODE(),
GEO_END(),
};
