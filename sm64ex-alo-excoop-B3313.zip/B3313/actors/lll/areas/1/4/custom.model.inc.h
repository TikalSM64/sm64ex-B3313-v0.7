#ifndef lll_4_model_HEADER_H
#define lll_4_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_0009E0_0x7013968[];
extern Vtx VB_lll_geo_0009E0_0x70139e8[];
extern Vtx VB_lll_geo_0009E0_0x7013ad8[];
extern Vtx VB_lll_geo_0009E0_0x7013bc8[];
extern u8 lll_geo_0009E0__texture_0900A800[];
extern u8 lll_geo_0009E0__texture_09007800[];
extern Light_t Light_lll_geo_0009E0_0x700fc08;
extern Ambient_t Light_lll_geo_0009E0_0x700fc00;
extern Gfx DL_lll_geo_0009E0_0x7013d28[];
extern Gfx DL_lll_geo_0009E0_0x7013c08[];
extern Gfx DL_lll_geo_0009E0_0x7013c70[];
#endif