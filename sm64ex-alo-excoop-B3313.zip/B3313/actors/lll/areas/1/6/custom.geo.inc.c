#include "custom.model.inc.h"
const GeoLayout lll_geo_000A10[]= {
GEO_CULLING_RADIUS(1200),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000A10_0x7014bd8),
GEO_CLOSE_NODE(),
GEO_END(),
};
