#ifndef lll_6_model_HEADER_H
#define lll_6_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000A10_0x7014818[];
extern Vtx VB_lll_geo_000A10_0x7014908[];
extern Vtx VB_lll_geo_000A10_0x70149f8[];
extern Vtx VB_lll_geo_000A10_0x7014a38[];
extern u8 lll_geo_000A10__texture_09007800[];
extern u8 lll_geo_000A10__texture_07002800[];
extern Light_t Light_lll_geo_000A10_0x700fc08;
extern Ambient_t Light_lll_geo_000A10_0x700fc00;
extern Gfx DL_lll_geo_000A10_0x7014bd8[];
extern Gfx DL_lll_geo_000A10_0x7014ab8[];
extern Gfx DL_lll_geo_000A10_0x7014b80[];
#endif