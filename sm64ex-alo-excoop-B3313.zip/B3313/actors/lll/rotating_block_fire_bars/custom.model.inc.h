#ifndef lll_rotating_block_fire_bars_model_HEADER_H
#define lll_rotating_block_fire_bars_model_HEADER_H
#include "types.h"
extern Vtx VB_lll_geo_000B38_0x7018708[];
extern Vtx VB_lll_geo_000B38_0x7018808[];
extern Vtx VB_lll_geo_000B38_0x7018908[];
extern u8 lll_geo_000B38__texture_07004000[];
extern Light_t Light_lll_geo_000B38_0x700fc08;
extern Ambient_t Light_lll_geo_000B38_0x700fc00;
extern Gfx DL_lll_geo_000B38_0x7018a30[];
extern Gfx DL_lll_geo_000B38_0x7018968[];
#endif