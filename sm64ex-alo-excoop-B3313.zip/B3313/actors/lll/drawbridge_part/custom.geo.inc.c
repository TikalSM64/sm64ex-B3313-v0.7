#include "custom.model.inc.h"
const GeoLayout lll_geo_000B20[]= {
GEO_CULLING_RADIUS(850),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_lll_geo_000B20_0x7018680),
GEO_CLOSE_NODE(),
GEO_END(),
};
