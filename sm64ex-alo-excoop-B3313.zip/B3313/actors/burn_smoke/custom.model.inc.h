#ifndef burn_smoke_burn_smoke_model_HEADER_H
#define burn_smoke_burn_smoke_model_HEADER_H
#include "types.h"
extern Vtx VB_burn_smoke_geo_0x40217c0[];
extern u8 burn_smoke_geo__texture_04021800[];
extern Gfx DL_burn_smoke_geo_0x4022070[];
extern Gfx DL_burn_smoke_geo_0x4022000[];
extern Gfx DL_burn_smoke_geo_0x4022028[];
extern Gfx DL_burn_smoke_geo_0x4022048[];
#endif