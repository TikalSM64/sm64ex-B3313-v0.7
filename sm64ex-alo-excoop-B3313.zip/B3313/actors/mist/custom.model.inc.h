#ifndef mist_mist_model_HEADER_H
#define mist_mist_model_HEADER_H
#include "types.h"
extern Vtx VB_mist_geo_0x3000000[];
extern u8 mist_geo__texture_03000080[];
extern Gfx DL_mist_geo_0x3000880[];
#endif