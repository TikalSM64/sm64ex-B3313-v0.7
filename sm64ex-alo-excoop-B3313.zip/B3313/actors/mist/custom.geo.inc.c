#include "custom.model.inc.h"
const GeoLayout mist_geo[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_ASM(0, geo_update_layer_transparency),
GEO_DISPLAY_LIST(5,DL_mist_geo_0x3000880),
GEO_CLOSE_NODE(),
GEO_END(),
};
