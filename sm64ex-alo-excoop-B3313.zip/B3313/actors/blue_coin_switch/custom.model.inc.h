#ifndef blue_coin_switch_blue_coin_switch_model_HEADER_H
#define blue_coin_switch_blue_coin_switch_model_HEADER_H
#include "types.h"
extern Vtx VB_blue_coin_switch_geo_0x8000c18[];
extern Vtx VB_blue_coin_switch_geo_0x8000d18[];
extern u8 blue_coin_switch_geo__texture_08000018[];
extern u8 blue_coin_switch_geo__texture_08000418[];
extern Light_t Light_blue_coin_switch_geo_0x8000008;
extern Ambient_t Light_blue_coin_switch_geo_0x8000000;
extern Gfx DL_blue_coin_switch_geo_0x8000e08[];
extern Gfx DL_blue_coin_switch_geo_0x8000d58[];
extern Gfx DL_blue_coin_switch_geo_0x8000dd0[];
#endif