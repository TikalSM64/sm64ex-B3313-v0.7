#ifndef exclamation_box_exclamation_box_model_HEADER_H
#define exclamation_box_exclamation_box_model_HEADER_H
#include "types.h"
extern Vtx VB_exclamation_box_geo_0x8018e28[];
extern Vtx VB_exclamation_box_geo_0x8018f28[];
extern Vtx VB_exclamation_box_geo_0x80190a0[];
extern Vtx VB_exclamation_box_geo_0x80191a0[];
extern u8 exclamation_box_geo__texture_08015E28[];
extern u8 exclamation_box_geo__texture_08016628[];
extern Light_t Light_exclamation_box_geo_0x8012e18;
extern Ambient_t Light_exclamation_box_geo_0x8012e10;
extern Gfx DL_exclamation_box_geo_0x8019318[];
extern Gfx DL_exclamation_box_geo_0x8019058[];
extern Gfx DL_exclamation_box_geo_0x8018fa8[];
extern Gfx DL_exclamation_box_geo_0x8019008[];
extern u8 exclamation_box_geo__texture_08014628[];
extern u8 exclamation_box_geo__texture_08014E28[];
extern Gfx DL_exclamation_box_geo_0x8019378[];
extern Gfx DL_exclamation_box_geo_0x80192d0[];
extern Gfx DL_exclamation_box_geo_0x8019220[];
extern Gfx DL_exclamation_box_geo_0x8019280[];
extern u8 exclamation_box_geo__texture_08012E28[];
extern u8 exclamation_box_geo__texture_08013628[];
extern Gfx DL_exclamation_box_geo_0x80193d8[];
extern u8 exclamation_box_geo__texture_08017628[];
extern u8 exclamation_box_geo__texture_08017E28[];
extern Gfx DL_exclamation_box_geo_0x8019438[];
#endif