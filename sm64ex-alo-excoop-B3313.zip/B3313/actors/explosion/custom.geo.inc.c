#include "custom.model.inc.h"
const GeoLayout explosion_geo[]= {
GEO_NODE_START(),
GEO_OPEN_NODE(),
GEO_SWITCH_CASE(9, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(5,DL_explosion_geo_0x3004298),
GEO_DISPLAY_LIST(5,DL_explosion_geo_0x3004298),
GEO_DISPLAY_LIST(5,DL_explosion_geo_0x30042b0),
GEO_DISPLAY_LIST(5,DL_explosion_geo_0x30042b0),
GEO_DISPLAY_LIST(5,DL_explosion_geo_0x30042c8),
GEO_DISPLAY_LIST(5,DL_explosion_geo_0x30042e0),
GEO_DISPLAY_LIST(5,DL_explosion_geo_0x30042f8),
GEO_DISPLAY_LIST(5,DL_explosion_geo_0x3004310),
GEO_DISPLAY_LIST(5,DL_explosion_geo_0x3004328),
GEO_CLOSE_NODE(),
GEO_CLOSE_NODE(),
GEO_END(),
};
