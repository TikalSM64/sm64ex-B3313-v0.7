#include "custom.model.inc.h"
const GeoLayout water_splash_geo[]= {
GEO_SWITCH_CASE(8, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(4,DL_water_splash_geo_0x4032640),
GEO_DISPLAY_LIST(4,DL_water_splash_geo_0x4032658),
GEO_DISPLAY_LIST(4,DL_water_splash_geo_0x4032670),
GEO_DISPLAY_LIST(4,DL_water_splash_geo_0x4032688),
GEO_DISPLAY_LIST(4,DL_water_splash_geo_0x40326a0),
GEO_DISPLAY_LIST(4,DL_water_splash_geo_0x40326b8),
GEO_DISPLAY_LIST(4,DL_water_splash_geo_0x40326d0),
GEO_DISPLAY_LIST(4,DL_water_splash_geo_0x40326e8),
GEO_CLOSE_NODE(),
GEO_END(),
};
