ALIGNED8 u8 water_splash_geo__texture_0402A5C8[] = {
#include "actors/water_splash/water_splash_geo_0x402a5c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 water_splash_geo__texture_0402B5C8[] = {
#include "actors/water_splash/water_splash_geo_0x402b5c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 water_splash_geo__texture_0402C5C8[] = {
#include "actors/water_splash/water_splash_geo_0x402c5c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 water_splash_geo__texture_0402D5C8[] = {
#include "actors/water_splash/water_splash_geo_0x402d5c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 water_splash_geo__texture_0402E5C8[] = {
#include "actors/water_splash/water_splash_geo_0x402e5c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 water_splash_geo__texture_0402F5C8[] = {
#include "actors/water_splash/water_splash_geo_0x402f5c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 water_splash_geo__texture_040305C8[] = {
#include "actors/water_splash/water_splash_geo_0x40305c8_custom.rgba16.inc.c"
};
ALIGNED8 u8 water_splash_geo__texture_040315C8[] = {
#include "actors/water_splash/water_splash_geo_0x40315c8_custom.rgba16.inc.c"
};
