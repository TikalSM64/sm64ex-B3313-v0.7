#ifndef water_splash_water_splash_model_HEADER_H
#define water_splash_water_splash_model_HEADER_H
#include "types.h"
extern Vtx VB_water_splash_geo_0x402a588[];
extern u8 water_splash_geo__texture_0402A5C8[];
extern Gfx DL_water_splash_geo_0x4032640[];
extern Gfx DL_water_splash_geo_0x40325c8[];
extern u8 water_splash_geo__texture_0402B5C8[];
extern Gfx DL_water_splash_geo_0x4032658[];
extern u8 water_splash_geo__texture_0402C5C8[];
extern Gfx DL_water_splash_geo_0x4032670[];
extern u8 water_splash_geo__texture_0402D5C8[];
extern Gfx DL_water_splash_geo_0x4032688[];
extern u8 water_splash_geo__texture_0402E5C8[];
extern Gfx DL_water_splash_geo_0x40326a0[];
extern u8 water_splash_geo__texture_0402F5C8[];
extern Gfx DL_water_splash_geo_0x40326b8[];
extern u8 water_splash_geo__texture_040305C8[];
extern Gfx DL_water_splash_geo_0x40326d0[];
extern u8 water_splash_geo__texture_040315C8[];
extern Gfx DL_water_splash_geo_0x40326e8[];
#endif