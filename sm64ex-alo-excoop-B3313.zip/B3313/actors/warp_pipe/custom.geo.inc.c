#include "custom.model.inc.h"
const GeoLayout warp_pipe_geo[]= {
GEO_CULLING_RADIUS(350),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_warp_pipe_geo_0x3008f98),
GEO_DISPLAY_LIST(1,DL_warp_pipe_geo_0x3009a50),
GEO_CLOSE_NODE(),
GEO_END(),
};
