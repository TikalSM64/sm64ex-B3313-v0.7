#ifndef swoop_swoop_model_HEADER_H
#define swoop_swoop_model_HEADER_H
#include "types.h"
extern Vtx VB_swoop_geo_0x6006288[];
extern Vtx VB_swoop_geo_0x6006368[];
extern Vtx VB_swoop_geo_0x6006468[];
extern Vtx VB_swoop_geo_0x6006518[];
extern Vtx VB_swoop_geo_0x6006808[];
extern Vtx VB_swoop_geo_0x6006950[];
extern Vtx VB_swoop_geo_0x60069d0[];
extern Vtx VB_swoop_geo_0x6006b58[];
extern Vtx VB_swoop_geo_0x6006c88[];
extern u8 swoop_geo__texture_06004270[];
extern Gfx DL_swoop_geo_0x6006880[];
extern Gfx DL_swoop_geo_0x6006848[];
extern u8 swoop_geo__texture_06004A70[];
extern u8 swoop_geo__texture_06005270[];
extern Light_t Light_swoop_geo_0x6006278;
extern Ambient_t Light_swoop_geo_0x6006270;
extern Gfx DL_swoop_geo_0x6006758[];
extern Gfx DL_swoop_geo_0x60065b8[];
extern Gfx DL_swoop_geo_0x60066f8[];
extern Light_t Light_swoop_geo_0x6006940;
extern Ambient_t Light_swoop_geo_0x6006938;
extern Gfx DL_swoop_geo_0x6006a88[];
extern Gfx DL_swoop_geo_0x6006a10[];
extern Gfx DL_swoop_geo_0x6006a68[];
extern u8 swoop_geo__texture_06005A70[];
extern Gfx DL_swoop_geo_0x6006bd0[];
extern Gfx DL_swoop_geo_0x6006b98[];
extern Gfx DL_swoop_geo_0x6006d00[];
extern Gfx DL_swoop_geo_0x6006cc8[];
#endif