ALIGNED8 u8 swoop_geo__texture_06004270[] = {
#include "actors/swoop/swoop_geo_0x6004270_custom.rgba16.inc.c"
};
ALIGNED8 u8 swoop_geo__texture_06004A70[] = {
#include "actors/swoop/swoop_geo_0x6004a70_custom.rgba16.inc.c"
};
ALIGNED8 u8 swoop_geo__texture_06005270[] = {
#include "actors/swoop/swoop_geo_0x6005270_custom.rgba16.inc.c"
};
ALIGNED8 u8 swoop_geo__texture_06005A70[] = {
#include "actors/swoop/swoop_geo_0x6005a70_custom.rgba16.inc.c"
};
