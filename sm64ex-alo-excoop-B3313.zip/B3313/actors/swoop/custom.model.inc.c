#include "custom.model.inc.h"
Vtx VB_swoop_geo_0x6006288[] = {
	{{{ 80, 38, -44 }, 0, { 40, 86 }, { 63, 48, 158, 255}}},
	{{{ 65, 77, -24 }, 0, { 1108, 796 }, { 68, 89, 198, 255}}},
	{{{ 112, 54, 0 }, 0, { 768, -454 }, { 105, 70, 0, 255}}},
	{{{ -14, 57, 28 }, 0, { 622, 254 }, { 150, 49, 48, 255}}},
	{{{ -11, -13, 0 }, 0, { 536, 234 }, { 141, 204, 0, 255}}},
	{{{ 17, -18, 89 }, 0, { 804, 76 }, { 204, 237, 114, 255}}},
	{{{ 29, 71, 45 }, 0, { 668, -2 }, { 5, 68, 106, 255}}},
	{{{ -14, 57, -27 }, 0, { 450, 246 }, { 150, 49, 208, 255}}},
	{{{ 17, -18, -88 }, 0, { 254, 54 }, { 229, 223, 137, 255}}},
	{{{ 29, 71, -44 }, 0, { 386, -14 }, { 5, 68, 149, 255}}},
	{{{ 82, 4, -52 }, 0, { -728, -328 }, { 63, 254, 147, 255}}},
	{{{ 17, -18, -88 }, 0, { -1332, 810 }, { 229, 223, 137, 255}}},
	{{{ 29, 71, -44 }, 0, { 878, 1484 }, { 5, 68, 149, 255}}},
	{{{ 114, 5, -24 }, 0, { -496, -1006 }, { 113, 231, 206, 255}}},
};

Vtx VB_swoop_geo_0x6006368[] = {
	{{{ 82, 4, 53 }, 0, { 758, 1078 }, { 64, 241, 108, 255}}},
	{{{ 83, -37, 25 }, 0, { 628, 1076 }, { 84, 171, 39, 255}}},
	{{{ 114, 5, 25 }, 0, { 626, 928 }, { 111, 244, 60, 255}}},
	{{{ 29, 71, 45 }, 0, { 386, 1344 }, { 5, 68, 106, 255}}},
	{{{ 80, 38, 45 }, 0, { 184, 100 }, { 64, 49, 98, 255}}},
	{{{ 65, 77, 25 }, 0, { 1194, 792 }, { 68, 89, 58, 255}}},
	{{{ 112, 54, 0 }, 0, { 1590, -282 }, { 105, 70, 0, 255}}},
	{{{ 17, -18, 89 }, 0, { -2258, 574 }, { 204, 237, 114, 255}}},
	{{{ 82, 4, 53 }, 0, { -608, -318 }, { 64, 241, 108, 255}}},
	{{{ 112, 54, 0 }, 0, { 514, 940 }, { 105, 70, 0, 255}}},
	{{{ 80, 38, 45 }, 0, { 722, 1090 }, { 64, 49, 98, 255}}},
	{{{ 34, -55, 44 }, 0, { 722, 1312 }, { 6, 138, 44, 255}}},
	{{{ 17, -18, 89 }, 0, { 928, 1394 }, { 204, 237, 114, 255}}},
	{{{ 83, -37, -24 }, 0, { 402, 1080 }, { 72, 164, 209, 255}}},
	{{{ 82, 4, -52 }, 0, { 272, 1086 }, { 63, 254, 147, 255}}},
	{{{ 114, 5, -24 }, 0, { 400, 932 }, { 113, 231, 206, 255}}},
};

Vtx VB_swoop_geo_0x6006468[] = {
	{{{ 34, -55, 44 }, 0, { 722, 1312 }, { 6, 138, 44, 255}}},
	{{{ 34, -55, -43 }, 0, { 314, 1318 }, { 230, 138, 220, 255}}},
	{{{ 83, -37, -24 }, 0, { 402, 1080 }, { 72, 164, 209, 255}}},
	{{{ 83, -37, 25 }, 0, { 628, 1076 }, { 84, 171, 39, 255}}},
	{{{ 114, 5, -24 }, 0, { 400, 932 }, { 113, 231, 206, 255}}},
	{{{ 114, 5, 25 }, 0, { 626, 928 }, { 111, 244, 60, 255}}},
	{{{ 112, 54, 0 }, 0, { 514, 940 }, { 105, 70, 0, 255}}},
	{{{ -11, -13, 0 }, 0, { 522, 1540 }, { 141, 204, 0, 255}}},
	{{{ 17, -18, 89 }, 0, { 928, 1394 }, { 204, 237, 114, 255}}},
	{{{ 17, -18, -88 }, 0, { 112, 1406 }, { 229, 223, 137, 255}}},
	{{{ 82, 4, -52 }, 0, { 272, 1086 }, { 63, 254, 147, 255}}},
};

Vtx VB_swoop_geo_0x6006518[] = {
	{{{ 112, 54, 0 }, 0, { 702, 6 }, { 105, 70, 0, 255}}},
	{{{ 65, 77, -24 }, 0, { 382, 266 }, { 68, 89, 198, 255}}},
	{{{ 65, 77, 25 }, 0, { 878, 288 }, { 68, 89, 58, 255}}},
	{{{ 40, 113, 0 }, 0, { 478, 480 }, { 249, 126, 0, 255}}},
	{{{ 65, 77, 25 }, 0, { 726, 230 }, { 68, 89, 58, 255}}},
	{{{ 65, 77, -24 }, 0, { 232, 230 }, { 68, 89, 198, 255}}},
	{{{ 29, 71, 45 }, 0, { 932, 586 }, { 5, 68, 106, 255}}},
	{{{ 29, 71, -44 }, 0, { 26, 586 }, { 5, 68, 149, 255}}},
	{{{ -14, 57, 28 }, 0, { 756, 1022 }, { 150, 49, 48, 255}}},
	{{{ -14, 57, -27 }, 0, { 202, 1022 }, { 150, 49, 208, 255}}},
};

Vtx VB_swoop_geo_0x6006808[] = {
	{{{ 15, 15, 0 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ -14, 15, 0 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ -14, -14, 0 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 15, -14, 0 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
};

Vtx VB_swoop_geo_0x6006950[] = {
	{{{ 187, 48, -55 }, 0, { 426, 722 }, { 198, 107, 223, 255}}},
	{{{ 194, 32, -119 }, 0, { 334, 706 }, { 223, 122, 5, 255}}},
	{{{ 80, -3, -32 }, 0, { 458, 990 }, { 223, 122, 5, 255}}},
	{{{ 116, 34, -130 }, 0, { 318, 900 }, { 253, 119, 43, 255}}},
	{{{ 80, -3, 33 }, 0, { 552, 990 }, { 223, 122, 251, 255}}},
	{{{ 194, 32, 120 }, 0, { 676, 706 }, { 223, 122, 251, 255}}},
	{{{ 187, 48, 56 }, 0, { 584, 722 }, { 198, 107, 33, 255}}},
	{{{ 116, 34, 131 }, 0, { 692, 900 }, { 253, 119, 213, 255}}},
};

Vtx VB_swoop_geo_0x60069d0[] = {
	{{{ 13, 79, -15 }, 0, { 0, 0 }, { 236, 125, 0, 255}}},
	{{{ -17, 74, -8 }, 0, { 0, 0 }, { 236, 125, 0, 255}}},
	{{{ -17, 74, 9 }, 0, { 0, 0 }, { 236, 125, 0, 255}}},
	{{{ 13, 79, 16 }, 0, { 0, 0 }, { 236, 125, 0, 255}}},
};

Vtx VB_swoop_geo_0x6006b58[] = {
	{{{ 0, 1, 133 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
	{{{ 0, 1, -133 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 265, 1, -133 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
	{{{ 265, 1, 133 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
};

Vtx VB_swoop_geo_0x6006c88[] = {
	{{{ 265, 1, -132 }, 0, { 990, 0 }, { 255, 255, 255, 255}}},
	{{{ 265, 1, 134 }, 0, { 990, 990 }, { 255, 255, 255, 255}}},
	{{{ 0, 1, 134 }, 0, { 0, 990 }, { 255, 255, 255, 255}}},
	{{{ 0, 1, -132 }, 0, { 0, 0 }, { 255, 255, 255, 255}}},
};

Gfx DL_swoop_geo_0x6006880[] = {
	gsDPPipeSync(),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
	gsDPSetDepthSource(0),
	gsDPSetFogColor(0, 0, 0, 255),
	gsMoveWd(G_MW_FOG, 0, 209777792),
	gsSPGeometryMode(0, G_FOG),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, COMBINED, 0, 0, 0, COMBINED),
	gsSPGeometryMode(G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_swoop_geo_0x6006848),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsDPSetRenderMode(0, 4468856),
	gsSPGeometryMode(G_FOG, 0),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_swoop_geo_0x6006848[] = {
	gsDPSetTextureImage(0, 2, 1, swoop_geo__texture_06004270),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_swoop_geo_0x6006808, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Light_t Light_swoop_geo_0x6006278 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_swoop_geo_0x6006270 = {
	{121, 121, 121}, 0, {121, 121, 121}, 0
};

Gfx DL_swoop_geo_0x6006758[] = {
	gsDPPipeSync(),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
	gsDPSetDepthSource(0),
	gsDPSetFogColor(0, 0, 0, 255),
	gsMoveWd(G_MW_FOG, 0, 209777792),
	gsSPGeometryMode(0, G_FOG),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, 0, 0, 0, COMBINED, 0, 0, 0, COMBINED),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_swoop_geo_0x60065b8),
	gsSPDisplayList(DL_swoop_geo_0x60066f8),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsDPSetRenderMode(0, 4464760),
	gsSPGeometryMode(G_FOG, 0),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPEndDisplayList(),
};

Gfx DL_swoop_geo_0x60065b8[] = {
	gsDPSetTextureImage(0, 2, 1, swoop_geo__texture_06004A70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_swoop_geo_0x6006278.col, 1),
	gsSPLight(&Light_swoop_geo_0x6006270.col, 2),
	gsSPVertex(VB_swoop_geo_0x6006288, 14, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(5, 6, 3, 0, 3, 7, 4, 0),
	gsSP2Triangles(8, 4, 7, 0, 7, 9, 8, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 0, 0),
	gsSP2Triangles(0, 2, 13, 0, 0, 13, 10, 0),
	gsSP1Triangle(1, 0, 12, 0),
	gsSPVertex(VB_swoop_geo_0x6006368, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(5, 4, 6, 0, 3, 7, 8, 0),
	gsSP2Triangles(3, 8, 4, 0, 2, 9, 10, 0),
	gsSP2Triangles(2, 10, 0, 0, 11, 1, 0, 0),
	gsSP2Triangles(11, 0, 12, 0, 13, 14, 15, 0),
	gsSPVertex(VB_swoop_geo_0x6006468, 11, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 3, 0, 4, 3, 2, 0),
	gsSP2Triangles(4, 6, 5, 0, 7, 1, 0, 0),
	gsSP2Triangles(0, 8, 7, 0, 9, 1, 7, 0),
	gsSP2Triangles(2, 1, 9, 0, 2, 9, 10, 0),
	gsSPEndDisplayList(),
};

Gfx DL_swoop_geo_0x60066f8[] = {
	gsDPSetTextureImage(0, 2, 1, swoop_geo__texture_06005270),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_swoop_geo_0x6006518, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(4, 3, 6, 0, 7, 3, 5, 0),
	gsSP2Triangles(6, 3, 8, 0, 3, 9, 8, 0),
	gsSP1Triangle(7, 9, 3, 0),
	gsSPEndDisplayList(),
};

Light_t Light_swoop_geo_0x6006940 = {
	{ 255, 255, 255}, 0, { 255, 255, 255}, 0, { 40, 40, 40}, 0
};

Ambient_t Light_swoop_geo_0x6006938 = {
	{121, 121, 121}, 0, {121, 121, 121}, 0
};

Gfx DL_swoop_geo_0x6006a88[] = {
	gsDPPipeSync(),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),
	gsDPSetDepthSource(0),
	gsDPSetFogColor(0, 0, 0, 255),
	gsMoveWd(G_MW_FOG, 0, 209777792),
	gsSPGeometryMode(0, G_FOG),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, SHADE, 0, 0, 0, COMBINED, 0, 0, 0, COMBINED),
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_swoop_geo_0x6006a10),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, COMBINED, 0, 0, 0, COMBINED),
	gsSPDisplayList(DL_swoop_geo_0x6006a68),
	gsDPPipeSync(),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsDPSetRenderMode(0, 4464760),
	gsSPGeometryMode(G_FOG, 0),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_CULL_BACK),
	gsSPEndDisplayList(),
};

Gfx DL_swoop_geo_0x6006a10[] = {
	gsDPSetTextureImage(0, 2, 1, swoop_geo__texture_06005270),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPLight(&Light_swoop_geo_0x6006940.col, 1),
	gsSPLight(&Light_swoop_geo_0x6006938.col, 2),
	gsSPVertex(VB_swoop_geo_0x6006950, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSPEndDisplayList(),
};

Gfx DL_swoop_geo_0x6006a68[] = {
	gsSPVertex(VB_swoop_geo_0x60069d0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Gfx DL_swoop_geo_0x6006bd0[] = {
	gsDPPipeSync(),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
	gsDPSetDepthSource(0),
	gsDPSetFogColor(0, 0, 0, 255),
	gsMoveWd(G_MW_FOG, 0, 209777792),
	gsSPGeometryMode(0, G_FOG),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, COMBINED, 0, 0, 0, COMBINED),
	gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_swoop_geo_0x6006b98),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsDPSetRenderMode(0, 4468856),
	gsSPGeometryMode(G_FOG, 0),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_swoop_geo_0x6006b98[] = {
	gsDPSetTextureImage(0, 2, 1, swoop_geo__texture_06005A70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_swoop_geo_0x6006b58, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Gfx DL_swoop_geo_0x6006d00[] = {
	gsDPPipeSync(),
	gsDPSetCycleType(G_CYC_2CYCLE),
	gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_TEX_EDGE2),
	gsDPSetDepthSource(0),
	gsDPSetFogColor(0, 0, 0, 255),
	gsMoveWd(G_MW_FOG, 0, 209777792),
	gsSPGeometryMode(0, G_FOG),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, COMBINED, 0, 0, 0, COMBINED),
	gsSPGeometryMode(G_CULL_BACK|G_LIGHTING, 0),
	gsDPSetTile(0, 2, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPTileSync(),
	gsDPSetTile(0, 2, 8, 0, 0, 0, 2, 5, 0, 2, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPDisplayList(DL_swoop_geo_0x6006cc8),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPPipeSync(),
	gsDPSetCycleType(G_CYC_1CYCLE),
	gsDPSetRenderMode(0, 4468856),
	gsSPGeometryMode(G_FOG, 0),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE, 0, 0, 0, SHADE),
	gsSPGeometryMode(0, G_CULL_BACK|G_LIGHTING),
	gsSPEndDisplayList(),
};

Gfx DL_swoop_geo_0x6006cc8[] = {
	gsDPSetTextureImage(0, 2, 1, swoop_geo__texture_06005A70),
	gsDPLoadSync(),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsSPVertex(VB_swoop_geo_0x6006c88, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

