E_MODEL_MARIO = smlua_model_util_get_id("mario_player_geo")
E_MODEL_LUIGI = smlua_model_util_get_id("luigi_player_geo")

function mario_on_set_action(m)
	if m.action == ACT_LONG_JUMP then
		m.vel.y = m.vel.y + 3
	elseif m.action == ACT_EMERGE_FROM_PIPE then
		m.vel.y = m.vel.y + 10
    end
	if m.action == ACT_JUMP or m.action == ACT_DOUBLE_JUMP or m.action == ACT_TRIPLE_JUMP or m.action == ACT_BACKFLIP or m.action == ACT_SIDE_FLIP or m.action == ACT_WALL_KICK_AIR then
        m.vel.y = m.vel.y + 4
    end
end

function mario_update(m)
	if m.action == ACT_JUMP or m.action == ACT_DOUBLE_JUMP or m.action == ACT_TRIPLE_JUMP or m.action == ACT_BACKFLIP or m.action == ACT_SIDE_FLIP or m.action == ACT_DIVE or m.action == ACT_JUMP_KICK or m.action == ACT_BACKWARD_ROLLOUT or m.action == ACT_FORWARD_ROLLOUT or m.action == ACT_WATER_JUMP or m.action == ACT_WALL_KICK_AIR then
        m.vel.y = m.vel.y + 0.4
    end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_SET_MARIO_ACTION, mario_on_set_action)
